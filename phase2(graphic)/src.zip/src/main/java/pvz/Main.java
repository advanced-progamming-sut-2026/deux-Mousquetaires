package pvz;

import pvz.controller.GameApp;

public final class Main {

    static void main() {new GameApp().run();}
}
