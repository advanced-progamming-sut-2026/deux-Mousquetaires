package pvz.gfx;

import com.badlogic.gdx.backends.lwjgl3.Lwjgl3Application;
import com.badlogic.gdx.backends.lwjgl3.Lwjgl3ApplicationConfiguration;

public final class DesktopLauncher {

    private DesktopLauncher() {
    }

    public static void main(String[] args) {
        Lwjgl3ApplicationConfiguration config = new Lwjgl3ApplicationConfiguration();
        config.setTitle("Plants vs. Zombies 2");
        config.setWindowedMode(1280, 720);
        config.setWindowSizeLimits(800, 450, -1, -1);
        config.useVsync(true);
        config.setForegroundFPS(60);

        config.setBackBufferConfig(8, 8, 8, 8, 16, 0, 4);

        new Lwjgl3Application(new PvzGame(), config);
    }
}
