package pvz.gfx;

import pvz.model.session.GameSession;

public final class Layout {

    private Layout() {
    }

    public static final float WORLD_W = 1280f;
    public static final float WORLD_H = 720f;

    public static final int ROWS = GameSession.ROWS;
    public static final int COLS = GameSession.COLS;

    public static final float LAWN_X = 214f;
    public static final float LAWN_Y = 70f;

    public static final float SEED_COLUMN_W = 150f;

    public static final float CELL_W = 98f;
    public static final float CELL_H = 106f;

    public static final float LAWN_W = COLS * CELL_W;
    public static final float LAWN_H = ROWS * CELL_H;

    public static final float MOWER_W = 56f;

    public static final float HUD_H = 96f;

    public static float cellX(float col) {
        return LAWN_X + (col - 1f) * CELL_W;
    }

    public static float cellY(float row) {
        return LAWN_Y + (ROWS - row) * CELL_H;
    }

    public static float cellCenterX(float col) {
        return cellX(col) + CELL_W / 2f;
    }

    public static float cellCenterY(float row) {
        return cellY(row) + CELL_H / 2f;
    }

    public static int colAt(float worldX) {
        int col = (int) Math.floor((worldX - LAWN_X) / CELL_W) + 1;
        return (col < 1 || col > COLS) ? 0 : col;
    }

    public static int rowAt(float worldY) {
        int fromBottom = (int) Math.floor((worldY - LAWN_Y) / CELL_H);
        int row = ROWS - fromBottom;
        return (row < 1 || row > ROWS) ? 0 : row;
    }

    public static boolean onLawn(int col, int row) {
        return col >= 1 && col <= COLS && row >= 1 && row <= ROWS;
    }

    public static float depth(float row, float col) {
        return row * 1000f + col;
    }
}
