package pvz.gfx;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import pvz.gfx.art.Art;
import pvz.gfx.art.PamCatalog;
import pvz.gfx.screens.LoginScreen;
import pvz.gfx.screens.MainMenuScreen;
import pvz.model.auth.AuthService;
import pvz.model.auth.Collection;
import pvz.model.auth.User;
import pvz.model.enums.Gender;
import pvz.model.enums.PlantType;
import pvz.model.news.NewsManager;
import pvz.model.persist.UpdaterPerSecond;
import pvz.model.shop.QuestManager;
import pvz.gfx.audio.MusicManager;
import pvz.model.shop.ShopService;
import pvz.network.GameClient;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class PvzGame extends Game {

    public static final int SEED_SLOTS = 8;

    private static final String DEFAULT_USERNAME = "player";

    private static final String DEFAULT_PASSWORD = "Pvz!2345";

    private Art art;
    private PamCatalog pam;
    private SpriteBatch batch;

    private AuthService auth;
    private User currentUser;

    private NewsManager news;
    private QuestManager quests;
    private ShopService shop;
    private GameClient netClient;
    private MusicManager music;

    private int gameSpeed = 1;
    private boolean showGrid = false;
    private boolean debugMode = false;

    @Override
    public void create() {
        art = new Art();
        pam = new PamCatalog();
        batch = new SpriteBatch();

        auth = new AuthService();
        news = new NewsManager();
        quests = new QuestManager();
        shop = new ShopService();
        netClient = new GameClient();
        music = new MusicManager();

        try {
            UpdaterPerSecond.loadAll(auth);
        } catch (Exception e) {
            Gdx.app.log("PvzGame", "No existing save to load: " + e.getMessage());
        }

        setScreen(new LoginScreen(this));
    }

    public void onUserLoggedIn(User user) {
        if (user == null) return;

        Collection collection = user.getCollection();
        for (PlantType type : starterPlants()) {
            if (!collection.isPlantUnlocked(type)) collection.unlockPlantQuietly(type);
        }

        currentUser = user;
        save();
    }

    private void loadOrCreateUser() {
        try {
            UpdaterPerSecond.loadAll(auth);
        } catch (Exception e) {
            Gdx.app.log("PvzGame", "No existing save to load: " + e.getMessage());
        }

        User user = auth.findByUsername(DEFAULT_USERNAME);

        if (user == null) {
            try {
                auth.register(DEFAULT_USERNAME, DEFAULT_PASSWORD, DEFAULT_PASSWORD,
                        "Player", "player@localhost", Gender.PREFER_NOT_TO_SAY);
                user = auth.findByUsername(DEFAULT_USERNAME);
            } catch (Exception e) {
                Gdx.app.log("PvzGame", "Register failed, building profile directly: " + e.getMessage());
            }
        }

        if (user == null) {
            user = new User(DEFAULT_USERNAME, auth.hashPassword(DEFAULT_PASSWORD),
                    "player@localhost", "Player", Gender.PREFER_NOT_TO_SAY);
            auth.restoreUser(user);
        }

        Collection collection = user.getCollection();
        for (PlantType type : starterPlants()) {
            if (!collection.isPlantUnlocked(type)) collection.unlockPlantQuietly(type);
        }

        currentUser = user;
    }

    public Art art() {
        return art;
    }

    public PamCatalog pam() {
        return pam;
    }

    public SpriteBatch batch() {
        return batch;
    }

    public Skin skin() {
        return art.skin();
    }

    public AuthService auth() {
        return auth;
    }

    public NewsManager news() {
        return news;
    }

    public QuestManager quests() {
        return quests;
    }

    public ShopService shop() {
        return shop;
    }

    public GameClient netClient() {
        return netClient;
    }

    public MusicManager music() {
        return music;
    }

    public User user() {
        return currentUser;
    }

    public void setUser(User user) {
        this.currentUser = user;
    }

    public int gameSpeed() {
        return gameSpeed;
    }

    public void setGameSpeed(int gameSpeed) {
        this.gameSpeed = Math.max(1, Math.min(3, gameSpeed));
    }

    public boolean showGrid() {
        return showGrid;
    }

    public void setShowGrid(boolean showGrid) {
        this.showGrid = showGrid;
    }

    public boolean debugMode() {
        return debugMode;
    }

    public void setDebugMode(boolean debugMode) {
        this.debugMode = debugMode;
    }

    public Set<PlantType> boostedPlants() {
        Set<PlantType> boosted = new HashSet<>();
        if (currentUser == null) return boosted;

        Map<PlantType, Integer> stored = currentUser.getStoredBoostMap();
        if (stored == null) return boosted;

        for (Map.Entry<PlantType, Integer> entry : stored.entrySet()) {
            if (entry.getValue() != null && entry.getValue() > 0) boosted.add(entry.getKey());
        }
        return boosted;
    }

    public void consumeBoostsFor(List<PlantType> chosen) {
        if (currentUser == null || chosen == null) return;
        Set<PlantType> available = boostedPlants();
        for (PlantType type : chosen) {
            if (available.contains(type)) currentUser.useStoredBoost(type);
        }
    }

    public static List<PlantType> starterPlants() {
        List<PlantType> plants = new ArrayList<>();
        String[] wanted = {
                "SUNFLOWER", "PEASHOOTER", "WALL_NUT", "POTATO_MINE",
                "SNOW_PEA", "REPEATER", "CABBAGE_PULT", "CHERRY_BOMB"
        };
        for (String name : wanted) {
            PlantType type = byName(name);
            if (type != null && !plants.contains(type)) plants.add(type);
        }
        if (plants.isEmpty()) {

            PlantType[] all = PlantType.values();
            for (int i = 0; i < Math.min(SEED_SLOTS, all.length); i++) plants.add(all[i]);
        }
        return plants;
    }

    public static PlantType byName(String name) {
        try {
            return PlantType.valueOf(name);
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    public List<PlantType> defaultSeedChoice() {
        List<PlantType> plants = starterPlants();
        return plants.size() > SEED_SLOTS ? new ArrayList<>(plants.subList(0, SEED_SLOTS)) : plants;
    }

    public void save() {
        if (currentUser == null) return;
        try {
            UpdaterPerSecond.saveAll(auth, currentUser);
        } catch (Exception e) {
            Gdx.app.error("PvzGame", "Save failed: " + e.getMessage());
        }
    }

    @Override
    public void dispose() {
        save();
        if (getScreen() != null) getScreen().dispose();
        if (batch != null) batch.dispose();
        if (art != null) art.dispose();
    }
}
