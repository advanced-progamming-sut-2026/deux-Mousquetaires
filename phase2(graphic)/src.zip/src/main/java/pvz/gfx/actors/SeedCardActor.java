package pvz.gfx.actors;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.scenes.scene2d.Touchable;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.Scaling;
import pvz.gfx.art.Art;
import pvz.gfx.art.PamCatalog;
import pvz.model.entity.plant.PlantCatalog;
import pvz.model.enums.PlantType;

public class SeedCardActor extends Table {

    public enum Mode {
        COLLECTION,
        SELECT,
        IN_GAME
    }

    public static final float CARD_W = 68f;
    public static final float CARD_H = 88f;

    private static final float ICON_H = 46f;

    private static final Color GOLD = new Color(0.98f, 0.80f, 0.25f, 1f);
    private static final Color PLAIN = new Color(0.36f, 0.27f, 0.16f, 1f);
    private static final Color EMPTY = new Color(0.20f, 0.18f, 0.14f, 0.75f);
    private static final Color SELECTED = new Color(1f, 1f, 0.6f, 1f);

    private final Art art;
    private final PamCatalog pamCatalog;
    private final Mode mode;

    private float animTime;
    private boolean rigDrawn;

    private PlantType type;
    private int sunCost;

    private boolean boosted;
    private boolean selected;
    private boolean locked;
    private boolean affordable = true;
    private float recharge = 1f;
    private int level;

    private final Image icon;
    private final Label costLabel;
    private final Label levelLabel;

    public SeedCardActor(Art art, Skin skin, PlantType type, Mode mode) {
        this(art, null, skin, type, mode);
    }

    public SeedCardActor(Art art, PamCatalog pamCatalog, Skin skin, PlantType type, Mode mode) {
        this.art = art;
        this.pamCatalog = pamCatalog;
        this.mode = mode;

        setSize(CARD_W, CARD_H);
        pad(4f);
        setTouchable(Touchable.enabled);

        icon = new Image();
        icon.setScaling(Scaling.fit);
        costLabel = new Label("", skin, "default");
        levelLabel = new Label("", skin, "default");
        levelLabel.setFontScale(0.75f);

        add(icon).size(52f, 52f).padTop(2f).row();
        add(costLabel).padTop(1f).row();
        add(levelLabel).padBottom(1f);

        setPlant(type);
    }

    public SeedCardActor setPlant(PlantType type) {
        this.type = type;
        if (type == null) {
            sunCost = 0;
            icon.setDrawable(null);
            costLabel.setText("");
            levelLabel.setText("");
            return this;
        }

        PlantCatalog.Stats stats = PlantCatalog.of(type);
        sunCost = stats == null ? 0 : stats.sunCost;
        rigDrawn = false;

        icon.setDrawable(new TextureRegionDrawable(art.placeholder(type.name(), 52, 52, false)));
        costLabel.setText(String.valueOf(sunCost));
        refreshLevelLabel();
        return this;
    }

    private void refreshLevelLabel() {
        if (mode == Mode.COLLECTION && level > 0) {
            levelLabel.setText("Lv " + level);
        } else {
            levelLabel.setText("");
        }
    }

    @Override
    public void act(float delta) {
        super.act(delta);
        animTime += delta;
    }

    @Override
    public void draw(Batch batch, float parentAlpha) {
        float x = getX();
        float y = getY();
        float w = getWidth();
        float h = getHeight();

        Color previous = batch.getColor().cpy();
        float alpha = parentAlpha * getColor().a;

        Color base = type == null ? EMPTY : (boosted ? GOLD : PLAIN);
        batch.setColor(base.r, base.g, base.b, base.a * alpha);
        batch.draw(art.pixel(), x, y, w, h);

        batch.setColor(base.r * 0.7f, base.g * 0.7f, base.b * 0.7f, base.a * alpha);
        batch.draw(art.pixel(), x + 3f, y + 3f, w - 6f, h - 6f);

        batch.setColor(previous);
        super.draw(batch, parentAlpha);
        previous = batch.getColor().cpy();

        if (type != null && pamCatalog != null && art.usingRealAssets()) {
            batch.setColor(1f, 1f, 1f, alpha);
            String pam = pamCatalog.plantPam(type);
            String clip = pamCatalog.plantClip(type, PamCatalog.Clip.IDLE);
            float footX = x + w / 2f;
            float footY = y + h - ICON_H - 8f;
            if (art.drawFitted(batch, pam, clip, animTime, footX, footY, ICON_H, true, null)
                    && !rigDrawn) {
                rigDrawn = true;
                icon.setDrawable(null);
            }
            batch.setColor(previous);
        }

        if (recharge < 1f) {
            float covered = h * (1f - recharge);
            batch.setColor(0f, 0f, 0f, 0.55f * alpha);
            batch.draw(art.pixel(), x, y, w, covered);
        }

        if (locked || (!affordable && mode == Mode.IN_GAME)) {
            batch.setColor(0f, 0f, 0f, (locked ? 0.62f : 0.45f) * alpha);
            batch.draw(art.pixel(), x, y, w, h);
        }

        if (selected) {
            batch.setColor(SELECTED.r, SELECTED.g, SELECTED.b, alpha);
            float t = 2f;
            batch.draw(art.pixel(), x, y, w, t);
            batch.draw(art.pixel(), x, y + h - t, w, t);
            batch.draw(art.pixel(), x, y, t, h);
            batch.draw(art.pixel(), x + w - t, y, t, h);
        }

        batch.setColor(previous);
    }

    public PlantType getPlant() {
        return type;
    }

    public int getSunCost() {
        return sunCost;
    }

    public boolean isEmptySlot() {
        return type == null;
    }

    public boolean isPlayable() {
        return type != null && !locked && affordable && recharge >= 1f;
    }

    public SeedCardActor setBoosted(boolean boosted) {
        this.boosted = boosted;
        return this;
    }

    public boolean isBoosted() {
        return boosted;
    }

    public SeedCardActor setSelected(boolean selected) {
        this.selected = selected;
        return this;
    }

    public boolean isSelected() {
        return selected;
    }

    public SeedCardActor setLocked(boolean locked) {
        this.locked = locked;
        return this;
    }

    public SeedCardActor setAffordable(boolean affordable) {
        this.affordable = affordable;
        return this;
    }

    public SeedCardActor setRecharge(float recharge) {
        this.recharge = Math.max(0f, Math.min(1f, recharge));
        return this;
    }

    public SeedCardActor setLevel(int level) {
        this.level = level;
        refreshLevelLabel();
        return this;
    }
}
