package pvz.gfx.art;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.files.FileHandle;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Pixmap;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Matrix4;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.Disposable;
import com.badlogic.gdx.utils.ObjectMap;
import pvz.libpvz.pam.ClipRef;
import pvz.libpvz.pam.PamPlayer;
import pvz.libpvz.textures.TextureBank;
import pvz.skin.PvzSkin;

import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public final class Art implements Disposable {

    public static final String RESOLUTION = "768";

    private final Skin skin;
    private final boolean realAssets;

    private TextureBank textures;
    private PamPlayer player;

    private final ObjectMap<String, TextureRegion> generated = new ObjectMap<>();
    private final Array<Texture> owned = new Array<>();

    private final Set<String> broken = new HashSet<>();

    private final ObjectMap<String, ClipRef> clipCache = new ObjectMap<>();

    private final ObjectMap<String, String> clipNames = new ObjectMap<>();

    private final ObjectMap<String, Rectangle> boundsCache = new ObjectMap<>();

    private final Matrix4 savedTransform = new Matrix4();
    private final Matrix4 scaledTransform = new Matrix4();

    public Art() {
        this.skin = PvzSkin.get();
        ensureStyles(this.skin);

        FileHandle root = resolveAssetRoot();
        if (root != null) {
            this.textures = new TextureBank(RESOLUTION, root);
            this.player = new PamPlayer(textures, root);
            this.realAssets = true;
            Gdx.app.log("Art", "Using PVZ2 assets at " + root.path());
        } else {
            this.realAssets = false;
            Gdx.app.log("Art", "No PVZ2 assets configured; falling back to placeholder art. "
                    + "Pass -Ppvz.assets=/path/to/Base Assets to enable real animations.");
        }
    }

    private void ensureStyles(Skin skin) {
        BitmapFont font = findFont(skin);

        if (!skin.has("default", com.badlogic.gdx.scenes.scene2d.ui.Label.LabelStyle.class)) {
            skin.add("default", new com.badlogic.gdx.scenes.scene2d.ui.Label.LabelStyle(font, Color.WHITE));
        }
        com.badlogic.gdx.scenes.scene2d.ui.Label.LabelStyle baseLabel =
                skin.get("default", com.badlogic.gdx.scenes.scene2d.ui.Label.LabelStyle.class);
        BitmapFont labelFont = baseLabel.font != null ? baseLabel.font : font;
        Color labelColor = baseLabel.fontColor != null ? baseLabel.fontColor : Color.WHITE;

        for (String name : new String[]{"medium", "big", "small", "title", "header"}) {
            if (!skin.has(name, com.badlogic.gdx.scenes.scene2d.ui.Label.LabelStyle.class)) {
                skin.add(name, new com.badlogic.gdx.scenes.scene2d.ui.Label.LabelStyle(labelFont, labelColor));
            }
        }

        if (!skin.has("default", com.badlogic.gdx.scenes.scene2d.ui.ScrollPane.ScrollPaneStyle.class)) {

            skin.add("default", new com.badlogic.gdx.scenes.scene2d.ui.ScrollPane.ScrollPaneStyle());
        }

        if (!skin.has("default", com.badlogic.gdx.scenes.scene2d.ui.List.ListStyle.class)) {
            com.badlogic.gdx.scenes.scene2d.ui.List.ListStyle ls =
                    new com.badlogic.gdx.scenes.scene2d.ui.List.ListStyle();
            ls.font = labelFont;
            ls.fontColorSelected = Color.WHITE;
            ls.fontColorUnselected = new Color(0.85f, 0.85f, 0.85f, 1f);
            ls.selection = solid(new Color(0.20f, 0.45f, 0.20f, 1f), 0f, 0f);
            skin.add("default", ls);
        }

        if (!skin.has("default", com.badlogic.gdx.scenes.scene2d.ui.SelectBox.SelectBoxStyle.class)) {
            com.badlogic.gdx.scenes.scene2d.ui.SelectBox.SelectBoxStyle sb =
                    new com.badlogic.gdx.scenes.scene2d.ui.SelectBox.SelectBoxStyle();
            sb.font = labelFont;
            sb.fontColor = Color.WHITE;
            sb.background = solid(new Color(0f, 0f, 0f, 0.55f), 12f, 28f);
            sb.scrollStyle = skin.get("default", com.badlogic.gdx.scenes.scene2d.ui.ScrollPane.ScrollPaneStyle.class);
            sb.listStyle = skin.get("default", com.badlogic.gdx.scenes.scene2d.ui.List.ListStyle.class);
            skin.add("default", sb);
        }

        if (!skin.has("default", com.badlogic.gdx.scenes.scene2d.ui.CheckBox.CheckBoxStyle.class)) {
            com.badlogic.gdx.scenes.scene2d.ui.CheckBox.CheckBoxStyle cb =
                    new com.badlogic.gdx.scenes.scene2d.ui.CheckBox.CheckBoxStyle();
            cb.font = labelFont;
            cb.fontColor = Color.WHITE;
            cb.checkboxOff = solid(new Color(0.16f, 0.16f, 0.16f, 1f), 22f, 22f);
            cb.checkboxOn = solid(new Color(0.30f, 0.75f, 0.30f, 1f), 22f, 22f);
            skin.add("default", cb);
        }
    }

    private BitmapFont findFont(Skin skin) {
        BitmapFont direct = skin.optional("default", BitmapFont.class);
        if (direct != null) return direct;
        for (String n : new String[]{"default", "medium", "big", "small", "title", "header"}) {
            if (skin.has(n, com.badlogic.gdx.scenes.scene2d.ui.Label.LabelStyle.class)) {
                BitmapFont lf = skin.get(n, com.badlogic.gdx.scenes.scene2d.ui.Label.LabelStyle.class).font;
                if (lf != null) return lf;
            }
            if (skin.has(n, com.badlogic.gdx.scenes.scene2d.ui.TextButton.TextButtonStyle.class)) {
                BitmapFont bf = skin.get(n, com.badlogic.gdx.scenes.scene2d.ui.TextButton.TextButtonStyle.class).font;
                if (bf != null) return bf;
            }
        }
        return new BitmapFont();
    }

    private com.badlogic.gdx.scenes.scene2d.utils.Drawable solid(Color color, float minW, float minH) {
        Pixmap pm = new Pixmap(1, 1, Pixmap.Format.RGBA8888);
        pm.setColor(color);
        pm.fill();
        Texture tex = new Texture(pm);
        pm.dispose();
        owned.add(tex);
        com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable d =
                new com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable(new TextureRegion(tex));
        if (minW > 0f) d.setMinWidth(minW);
        if (minH > 0f) d.setMinHeight(minH);
        return d;
    }

    private static FileHandle resolveAssetRoot() {
        String configured = System.getProperty("pvz.assets");
        if (configured == null || configured.trim().isEmpty()) {
            configured = System.getenv("PVZ_ASSETS");
        }

        if (configured != null && !configured.trim().isEmpty()) {
            FileHandle root = Gdx.files.absolute(configured.trim());
            if (!root.exists() || !root.isDirectory()) {
                Gdx.app.error("Art", "pvz.assets does not point at a folder: " + configured);
                return null;
            }
            FileHandle valid = validRoot(root);
            if (valid == null) {
                Gdx.app.error("Art", "pvz.assets has no RESOURCES.json / IMAGES folder: " + configured);
            }
            return valid;
        }

        for (String candidate : new String[]{"pvz-assets", "assets/pvz-assets", "Base Assets"}) {
            FileHandle local = findFile(candidate);
            if (local != null && local.isDirectory()) {
                FileHandle valid = validRoot(local);
                if (valid != null) return valid;
            }
        }

        Gdx.app.log("Art", "No pvz-assets/ folder found. Working directory is "
                + new File("").getAbsolutePath()
                + " -- put the asset folder there, or in any parent folder, or set PVZ_ASSETS.");
        return null;
    }

    public static FileHandle findFile(String relative) {
        FileHandle direct = Gdx.files.local(relative);
        if (direct.exists()) return direct;

        for (File root : searchRoots()) {
            File candidate = new File(root, relative);
            if (candidate.exists()) {
                return Gdx.files.absolute(candidate.getAbsolutePath());
            }
        }
        return null;
    }

    private static List<File> searchRoots() {
        List<File> roots = new ArrayList<>();
        addWithParents(roots, new File("").getAbsoluteFile(), 5);
        addWithParents(roots, codeSourceDir(), 7);
        return roots;
    }

    private static void addWithParents(List<File> roots, File start, int levels) {
        File dir = start;
        for (int depth = 0; dir != null && depth < levels; depth++, dir = dir.getParentFile()) {
            if (!roots.contains(dir)) roots.add(dir);
        }
    }

    private static File codeSourceDir() {
        try {
            java.net.URL location = Art.class.getProtectionDomain().getCodeSource().getLocation();
            File file = new File(location.toURI());
            return file.isDirectory() ? file : file.getParentFile();
        } catch (Exception e) {
            return null;
        }
    }

    private static FileHandle validRoot(FileHandle dir) {
        if (hasResourceIndex(dir)) return dir;

        FileHandle nested = dir.child(dir.name());
        if (nested.exists() && hasResourceIndex(nested)) return nested;

        for (FileHandle child : dir.list()) {
            if (child.isDirectory() && hasResourceIndex(child)) return child;
        }
        return null;
    }

    private static boolean hasResourceIndex(FileHandle dir) {
        boolean index = dir.child("RESOURCES.json").exists()
                || dir.child("resources.json").exists()
                || dir.child("Resources.json").exists();
        boolean images = dir.child("IMAGES").exists() || dir.child("pam").exists();
        return index && images;
    }

    public boolean usingRealAssets() {
        return realAssets;
    }

    public Skin skin() {
        return skin;
    }

    public void update() {
        if (realAssets) textures.update();
    }

    public void preload(String pam) {
        if (!realAssets || pam == null || broken.contains(pam)) return;
        try {
            player.loadSync(pam);
        } catch (Exception e) {
            broken.add(pam);
            Gdx.app.error("Art", "Could not preload PAM " + pam + ": " + e.getMessage());
        }
    }

    public boolean drawClip(Batch batch, String pam, String clip, float time,
                            float x, float y, boolean loop, Map<String, Boolean> visibility) {
        if (!realAssets || pam == null || broken.contains(pam)) return false;

        ClipRef ref = resolveClip(pam, clip);
        if (ref == null) return false;

        try {
            if (visibility == null || visibility.isEmpty()) {
                player.draw(batch, ref, time, x, y, loop);
            } else {
                player.draw(batch, ref, time, x, y, loop, visibility);
            }
            return true;
        } catch (Exception e) {
            broken.add(pam);
            Gdx.app.error("Art", "PAM unavailable, using placeholder for " + pam + ": " + e.getMessage());
            return false;
        }
    }

    private ClipRef resolveClip(String pam, String requested) {
        String key = pam + '#' + requested;
        ClipRef cached = clipCache.get(key);
        if (cached != null) return cached;

        try {
            List<String> available = player.clips(pam);
            if (available == null || available.isEmpty()) {
                broken.add(pam);
                Gdx.app.error("Art", "PAM defines no clips: " + pam);
                return null;
            }

            String chosen = requested;
            if (chosen == null || !available.contains(chosen)) {
                chosen = available.contains("idle") ? "idle" : available.get(0);
                Gdx.app.log("Art", "Clip '" + requested + "' not in " + pam
                        + "; falling back to '" + chosen + "'. Available: " + available);
            }

            ClipRef ref = player.getClip(pam, chosen);
            if (ref == null) return null;

            clipNames.put(key, chosen);
            clipCache.put(key, ref);
            return ref;
        } catch (Exception e) {
            broken.add(pam);
            Gdx.app.error("Art", "Could not load PAM " + pam + ": " + e.getMessage());
            return null;
        }
    }

    public boolean drawFitted(Batch batch, String pam, String clip, float time,
                              float footX, float footY, float targetHeight,
                              boolean loop, Map<String, Boolean> visibility) {
        if (!realAssets || pam == null || broken.contains(pam)) return false;

        ClipRef ref = resolveClip(pam, clip);
        if (ref == null) return false;

        Rectangle rect = boundsOf(pam, clip);
        if (rect == null || rect.width <= 0f || rect.height <= 0f) return false;

        float scale = targetHeight / rect.height;
        float originX = footX - scale * (rect.x + rect.width / 2f);
        float originY = footY + scale * (rect.y + rect.height);

        savedTransform.set(batch.getTransformMatrix());
        scaledTransform.set(savedTransform)
                .translate(originX, originY, 0f)
                .scale(scale, scale, 1f);
        try {
            batch.setTransformMatrix(scaledTransform);
            if (visibility == null || visibility.isEmpty()) {
                player.draw(batch, ref, time, 0f, 0f, loop);
            } else {
                player.draw(batch, ref, time, 0f, 0f, loop, visibility);
            }
            return true;
        } catch (Exception e) {
            broken.add(pam);
            Gdx.app.error("Art", "PAM unavailable, using placeholder for " + pam + ": " + e.getMessage());
            return false;
        } finally {
            batch.setTransformMatrix(savedTransform);
        }
    }

    private Rectangle boundsOf(String pam, String requested) {
        String key = pam + '#' + requested;
        Rectangle cached = boundsCache.get(key);
        if (cached != null) return cached;
        try {
            Rectangle rect = player.bounds(pam, clipNames.get(key));
            if (rect == null) return null;
            boundsCache.put(key, rect);
            return rect;
        } catch (Exception e) {
            Gdx.app.error("Art", "Could not measure PAM " + pam + ": " + e.getMessage());
            return null;
        }
    }

    public TextureRegion region(String imageResourceId) {
        if (!realAssets || imageResourceId == null) return null;
        try {
            return textures.region(imageResourceId);
        } catch (Exception e) {
            return null;
        }
    }

    public TextureRegion placeholder(String key, int width, int height, boolean round) {
        String cacheKey = key + "@" + width + "x" + height + (round ? "c" : "r");
        TextureRegion cached = generated.get(cacheKey);
        if (cached != null) return cached;

        Color fill = colorFor(key);
        Pixmap pixmap = new Pixmap(width, height, Pixmap.Format.RGBA8888);
        pixmap.setBlending(Pixmap.Blending.SourceOver);

        pixmap.setColor(fill);
        if (round) {
            pixmap.fillCircle(width / 2, height / 2, Math.min(width, height) / 2 - 1);
        } else {
            pixmap.fillRectangle(1, 1, width - 2, height - 2);
        }

        pixmap.setColor(fill.r * 0.45f, fill.g * 0.45f, fill.b * 0.45f, 1f);
        if (round) {
            pixmap.drawCircle(width / 2, height / 2, Math.min(width, height) / 2 - 1);
        } else {
            pixmap.drawRectangle(1, 1, width - 2, height - 2);
        }

        Texture texture = new Texture(pixmap);
        texture.setFilter(Texture.TextureFilter.Linear, Texture.TextureFilter.Linear);
        pixmap.dispose();
        owned.add(texture);

        TextureRegion region = new TextureRegion(texture);
        generated.put(cacheKey, region);
        return region;
    }

    public TextureRegion pixel() {
        TextureRegion cached = generated.get("__pixel");
        if (cached != null) return cached;

        Pixmap pixmap = new Pixmap(1, 1, Pixmap.Format.RGBA8888);
        pixmap.setColor(Color.WHITE);
        pixmap.fill();
        Texture texture = new Texture(pixmap);
        pixmap.dispose();
        owned.add(texture);

        TextureRegion region = new TextureRegion(texture);
        generated.put("__pixel", region);
        return region;
    }

    private static Color colorFor(String key) {
        int hash = key == null ? 0 : key.hashCode();
        float hue = Math.abs(hash % 360);
        return hsvToColor(hue, 0.55f, 0.85f);
    }

    private static Color hsvToColor(float h, float s, float v) {
        float c = v * s;
        float hp = h / 60f;
        float x = c * (1 - Math.abs(hp % 2 - 1));
        float r = 0, g = 0, b = 0;
        if (hp < 1) {
            r = c;
            g = x;
        } else if (hp < 2) {
            r = x;
            g = c;
        } else if (hp < 3) {
            g = c;
            b = x;
        } else if (hp < 4) {
            g = x;
            b = c;
        } else if (hp < 5) {
            r = x;
            b = c;
        } else {
            r = c;
            b = x;
        }
        float m = v - c;
        return new Color(r + m, g + m, b + m, 1f);
    }

    @Override
    public void dispose() {
        for (Texture texture : owned) texture.dispose();
        owned.clear();
        generated.clear();
        if (textures != null) textures.dispose();

    }
}
