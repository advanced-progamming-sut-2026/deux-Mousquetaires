package pvz.gfx.art;

import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;

import pvz.model.enums.WorldType;

public final class Backdrops {

    private Backdrops() {
    }
    public static final String GREEN = "IMAGE_BACKGROUNDS_ZEN_GARDEN";
    public static final String LAWN_CENTER = "IMAGE_BACKGROUNDS_FRONTLAWN_TEXTURE";
    public static final String LAWN_LEFT = "IMAGE_BACKGROUNDS_FRONTLAWN_TEXTURE_LEFT";
    public static final String LAWN_RIGHT = "IMAGE_BACKGROUNDS_FRONTLAWN_TEXTURE_RIGHT";

    public static final String EGYPT_CENTER = "IMAGE_BACKGROUNDS_EGYPT_TEXTURE";
    public static final String EGYPT_LEFT = "IMAGE_BACKGROUNDS_EGYPT_TEXTURE_LEFT";
    public static final String EGYPT_RIGHT = "IMAGE_BACKGROUNDS_EGYPT_TEXTURE_RIGHT";

    public static final String BEACH_CENTER = "IMAGE_BACKGROUNDS_BEACH_TEXTURE";
    public static final String BEACH_LEFT = "IMAGE_BACKGROUNDS_BEACH_TEXTURE_LEFT";
    public static final String BEACH_RIGHT = "IMAGE_BACKGROUNDS_BEACH_TEXTURE_RIGHT";

    public static final String DARK_CENTER = "IMAGE_BACKGROUNDS_DARK_TEXTURE";
    public static final String DARK_LEFT = "IMAGE_BACKGROUNDS_DARK_TEXTURE_LEFT";
    public static final String DARK_RIGHT = "IMAGE_BACKGROUNDS_DARK_TEXTURE_RIGHT";

    public static final String MENU_TUTORIAL = "IMAGE_UI_ARCADEMENU_BG_TUTORIAL";
    public static final String MENU_EGYPT = "IMAGE_UI_ARCADEMENU_BG_EGYPT";
    public static final String MENU_PIRATE = "IMAGE_UI_ARCADEMENU_BG_PIRATE";
    public static final String MENU_WEST = "IMAGE_UI_ARCADEMENU_BG_WEST";
    public static final String MENU_BEACH = "IMAGE_UI_ARCADEMENU_BG_BEACH";
    public static final String MENU_DARKAGES = "IMAGE_UI_ARCADEMENU_BG_DARKAGES";
    public static final String MENU_FUTURE = "IMAGE_UI_ARCADEMENU_BG_FUTURE";

    public static final String MOWER = "IMAGE_EFFECTS_CARD_MOWER";

    public static final String VASE = "IMAGE_EGGBREAKER_VASE_EGG_BROWN_VASE_EGG_BROWN_151X198";
    public static final String VASE_ALT = "IMAGE_EGGBREAKER_VASE_EGG_BROWN_VASE_EGG_BROWN_155X188";
    public static final String VASE_BIG = "IMAGE_EGGBREAKER_VASE_EGG_GARGANTUAR_VASE_EGG_GARGANTUAR_122X115";

    public static final String BRAIN = "IMAGE_UI_GAMEOVER_FAIL_SCREEN_BRAIN_ONLY";
    public static final String BRAIN_BIG = "IMAGE_PLANT_BRAINSTEM_BRAINSTEM_205X175";

    public static final String SUN = "IMAGE_UI_HUD_INGAME_SUN_DOWN";
    public static final String SUN_BIG = "IMAGE_EFFECTS_SUN_SUN_166X166";
    public static final String SUN_SMALL = "IMAGE_MISSING_PAM_MISSING_PAM_166X166";

    public static final String COIN = "IMAGE_UI_HUD_INGAME_COIN";
    public static final String GEM = "IMAGE_UI_HUD_INGAME_GEM";
    public static final String PLANT_FOOD = "IMAGE_EFFECTS_PLANTFOOD_PICKUP_PLANTFOOD_PICKUP_79X79";

    public static final String RED_FLAG = "IMAGE_UI_RED_FLAG";
    public static final String PROGRESS_FLAG = "IMAGE_UI_HUD_INGAME_PROGRESS_METER_FLAG_DEFAULT";
    public static final String PROGRESS_METER_BG = "IMAGE_UI_HUD_INGAME_PROGRESS_METER";
    public static final String PROGRESS_METER_FILL = "IMAGE_UI_HUD_INGAME_PROGRESS_METER_FILL";
    public static final String PROGRESS_METER_POLE = "IMAGE_UI_HUD_INGAME_PROGRESS_METER_FLAG_POLE";

    public static final String GRAVE = "IMAGE_GRAVESTONES_TUTORIAL_GRAVESTONE_TUTORIAL_GRAVESTONE_101X158";
    public static final String GRAVE_EGYPT = "IMAGE_GRAVESTONES_EGYPT_HIEROGLYPH_EGYPT_HIEROGLYPH_118X148";

    public static final String ICE_BLOCK_ZOMBIE_PAM = "768/FULL/EFFECTS/FROSTBITE_ICE_BLOCK_ZOMBIE/FROSTBITE_ICE_BLOCK_ZOMBIE.PAM";
    public static final String ICE_BLOCK_PLANT_PAM = "768/FULL/EFFECTS/FROSTBITE_ICE_BLOCK_PLANT/FROSTBITE_ICE_BLOCK_PLANT.PAM";
    public static final String ICE_BLOCK_PARTICLES_PAM = "768/FULL/EFFECTS/FROSTBITE_ICE_BLOCK_PARTICLES/FROSTBITE_ICE_BLOCK_PARTICLES.PAM";
    public static final String ICE_BLOCK_PARTICLES_IMAGE = "IMAGE_EFFECTS_FROSTBITE_ICE_BLOCK_PARTICLES_FROSTBITE_ICE_BLOCK_PARTICLES_103X98";

    public static final String SANDSTORM_REAR_PAM = "768/INITIAL/EFFECTS/SANDSTORM_REAR/SANDSTORM_REAR.PAM";
    public static final String SANDSTORM_TOP_PAM = "768/INITIAL/EFFECTS/SANDSTORM_TOP/SANDSTORM_TOP.PAM";
    public static final String FROSTBITE_CHILL_WIND_PAM = "768/FULL/EFFECTS/FROSTBITE_CHILL_WIND/FROSTBITE_CHILL_WIND.PAM";

    public static final String DAVE_WINNIE_NARRATION_PAM = "768/INITIAL/CRAZYDAVE/DAVEWINNIE_NARRATIONICONS/DAVEWINNIE_NARRATIONICONS.PAM";

    public static final String PROJECTILE_PEA = "IMAGE_PROJECTILEPEA";
    public static final String PROJECTILE_ICE = "IMAGE_EFFECTS_POWER_UP_ICE_PROJECTILE1";
    public static final String PROJECTILE_FIRE = "IMAGE_PLANT_FIREPEASHOOTER_FIREPEASHOOTER_128X107";
    public static final String SNOW_SPLAT = "IMAGE_EFFECTS_SPLAT_SNOW_PEA_SPLAT_SNOW_PEA_104X39";
    public static final String PEA_SPLAT = "IMAGE_EFFECTS_SPLAT_PEA_SPLAT_PEA_150X88";
    public static final String FROST_HEAT = "IMAGE_EFFECTS_FROSTBITE_HEAT_PLANT_FROSTBITE_HEAT_PLANT_191X191";
    public static final String SPACE_DUST = "IMAGE_SPACE_SPIRAL_SPACE_DUST";

    public static final String EXPLOSION_REAR = "IMAGE_EFFECTS_CHERRYBOMB_EXPLOSION_REAR_CHERRYBOMB_EXPLOSION_REAR_206X194";
    public static final String EXPLOSION_TOP = "IMAGE_EFFECTS_CHERRYBOMB_EXPLOSION_TOP_CHERRYBOMB_EXPLOSION_TOP_236X223";

    public static final String SHOVEL_BUTTON = "IMAGE_UI_HUD_INGAME_SHOVEL_BUTTON";
    public static final String SHOVEL_BUTTON_DOWN = "IMAGE_UI_HUD_INGAME_SHOVEL_BUTTON_DOWN";
    public static final String PAUSE_BUTTON = "IMAGE_UI_HUD_INGAME_PAUSE_BUTTON";
    public static final String PAUSE_BUTTON_DOWN = "IMAGE_UI_HUD_INGAME_PAUSE_BUTTON_DOWN";

    public static final String HOURGLASS_CURSOR = "IMAGE_UI_HOURGLASS_CURSOR";

    public static final String WAVE_METER_HEAD = "IMAGE_UI_WAVE_METER_HEAD";

    public static final String SHOP_POT = "IMAGE_UI_HUD_EVENTBUTTON_EVENT_ICON_TRIGGER_UP";
    public static final String SHOP_SEED_BUNDLE = "IMAGE_UI_STOREMULTI_SEEDPACKETICON";

    public static final String SETTINGS_ICON = "IMAGE_UI_MAINMENU_MM_SETTINGS";
    public static final String PROFILE_ICON = "IMAGE_UI_MAINMENU_DAVE_WAIST_CROP";

    public static final String CONVEYOR_BELT = "IMAGE_UI_CONVEYOR_CONVEYOR_BELT";
    public static final String CONVEYOR_TOP = "IMAGE_UI_CONVEYOR_CONVEYOR_TOP";
    public static final String CONVEYOR_SIDE = "IMAGE_UI_CONVEYOR_CONVEYOR_SIDE";

    public static final String SEED_PLATE = "IMAGE_UI_CHOOSER_SEEDPACKET9SLICE_BKGD";
    public static final String SEED_ICON = "IMAGE_UI_STOREMULTI_SEEDPACKETICON";

    public static TextureRegion first(Art art, String... ids) {
        if (art == null) return null;
        for (String id : ids) {
            TextureRegion region = art.region(id);
            if (region != null) return region;
        }
        return null;
    }

    public static boolean drawCover(Batch batch, Art art, float x, float y, float width, float height,
                                    String centerId, String leftId, String rightId) {
        TextureRegion center = art == null ? null : art.region(centerId);
        if (center == null) return false;

        TextureRegion left = leftId == null ? null : art.region(leftId);
        TextureRegion right = rightId == null ? null : art.region(rightId);

        float leftW = left == null ? 0f : width * 0.18f;
        float rightW = right == null ? 0f : width * 0.18f;

        if (left != null) batch.draw(left, x, y, leftW, height);
        batch.draw(center, x + leftW, y, width - leftW - rightW, height);
        if (right != null) batch.draw(right, x + width - rightW, y, rightW, height);
        return true;
    }

    public static String worldCenter(WorldType world) {
        if (world == null) return LAWN_CENTER;
        switch (world) {
            case ANCIENT_EGYPT: return EGYPT_CENTER;
            case BIG_WAVE_BEACH: return BEACH_CENTER;
            case DARK_AGES: return DARK_CENTER;
            default: return LAWN_CENTER;
        }
    }

    public static String worldLeft(WorldType world) {
        if (world == null) return LAWN_LEFT;
        switch (world) {
            case ANCIENT_EGYPT: return EGYPT_LEFT;
            case BIG_WAVE_BEACH: return BEACH_LEFT;
            case DARK_AGES: return DARK_LEFT;
            default: return LAWN_LEFT;
        }
    }

    public static String worldRight(WorldType world) {
        if (world == null) return LAWN_RIGHT;
        switch (world) {
            case ANCIENT_EGYPT: return EGYPT_RIGHT;
            case BIG_WAVE_BEACH: return BEACH_RIGHT;
            case DARK_AGES: return DARK_RIGHT;
            default: return LAWN_RIGHT;
        }
    }
}
