package pvz.gfx.art;

import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import pvz.model.enums.ZombieType;

public final class CompositeZombies {

    private CompositeZombies() {
    }

    public static final String BODY_PAM = "768/INITIAL/ZOMBIE/ZOMBIE_TUTORIAL/ZOMBIE_TUTORIAL.PAM";

    private static final java.util.Map<ZombieType, String> HEAD_PLANT = new java.util.HashMap<>();
    static {
        HEAD_PLANT.put(ZombieType.PEASHOOTER_ZOMBIE, "768/INITIAL/PLANT/PEASHOOTER/PEASHOOTER.PAM");
        HEAD_PLANT.put(ZombieType.WALLNUT_ZOMBIE, "768/INITIAL/PLANT/WALLNUT/WALLNUT.PAM");
        HEAD_PLANT.put(ZombieType.JALAPENO_ZOMBIE, "768/INITIAL/PLANT/JALAPENO/JALAPENO.PAM");
        HEAD_PLANT.put(ZombieType.SQUASH_ZOMBIE, "768/INITIAL/PLANT/SQUASH/SQUASH.PAM");
        HEAD_PLANT.put(ZombieType.SUN_PRODUCER_ZOMBIE, "768/INITIAL/PLANT/SUNFLOWER/SUNFLOWER.PAM");
    }

    // Real pvz-assets image ids used for head accessories (no placeholder boxes anymore)
    private static final java.util.Map<ZombieType, String> HEAD_IMAGE = new java.util.HashMap<>();
    static {
        HEAD_IMAGE.put(ZombieType.BUCKETHEAD, "IMAGE_ZOMBIE_ZOMBIE_PIRATE_BASIC_BRICK_ZOMBIE_PIRATE_BASIC_BRICK_89X86");
        HEAD_IMAGE.put(ZombieType.CONEHEAD, "IMAGE_ZOMBIE_ZOMBIE_MODERN_NEWSPAPER_ZOMBIE_MODERN_NEWSPAPER_80X83");
        HEAD_IMAGE.put(ZombieType.ALL_STAR, "IMAGE_UI_ALMANAC_PACKETS_ZOMBIES_FOOTBALL_MECH");
    }

    public static boolean isComposite(ZombieType type) {
        if (type == null) return false;
        return HEAD_PLANT.containsKey(type) || HEAD_IMAGE.containsKey(type);
    }

    public static void draw(Art art, PamCatalog pam, Batch batch, ZombieType type, String bodyClip,
                            float time, float footX, float footY, float height) {
        if (art == null || batch == null || type == null) return;
        boolean fitted = art.drawFitted(batch, BODY_PAM, bodyClip, time,
                footX, footY, height, true, null);
        if (!fitted) {
            art.drawFitted(batch, BODY_PAM, "idle", time, footX, footY, height, true, null);
        }

        String headPam = HEAD_PLANT.get(type);
        float headSize = height * 0.42f;
        float headX = footX;
        float headY = footY + height * 0.66f;

        if (headPam != null) {
            boolean headFitted = art.drawFitted(batch, headPam, "idle", time,
                    headX, headY, headSize, true, null);
            if (!headFitted) {
                art.drawFitted(batch, headPam, "intro", time, headX, headY, headSize, true, null);
            }
        } else {
            String headImageId = HEAD_IMAGE.get(type);
            if (headImageId != null) {
                TextureRegion accessory = art.region(headImageId);
                if (accessory != null) {
                    float aspect = accessory.getRegionHeight() > 0
                            ? (float) accessory.getRegionWidth() / (float) accessory.getRegionHeight() : 1f;
                    float drawW = headSize * aspect;
                    batch.draw(accessory, headX - drawW / 2f, headY, drawW, headSize);
                }
            }
        }
    }
}