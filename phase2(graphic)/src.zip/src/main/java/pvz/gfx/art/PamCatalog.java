package pvz.gfx.art;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.files.FileHandle;
import com.badlogic.gdx.utils.JsonReader;
import com.badlogic.gdx.utils.JsonValue;
import pvz.model.enums.PlantType;
import pvz.model.enums.ZombieType;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

public final class PamCatalog {

    public enum Clip {
        IDLE("idle"),
        ATTACK("attack"),
        PRODUCE("produce"),
        WALK("walk"),
        EAT("eat"),
        INTRO("intro"),
        CHARGE("charge"),
        DEATH("death");

        public final String key;

        Clip(String key) {
            this.key = key;
        }
    }

    private static final String MAPPING_FILE = "assets/pam/mapping.json";

    private final Map<String, Entry> plants = new HashMap<>();
    private final Map<String, Entry> zombies = new HashMap<>();

    private String plantPamPattern = "PLANTS/%s/%s.PAM";
    private String zombiePamPattern = "ZOMBIES/%s/%s.PAM";
    private final Map<String, String> defaultClips = new HashMap<>();

    private static final class Entry {
        String pam;
        final Map<String, String> clips = new HashMap<>();
    }

    public PamCatalog() {
        defaultClips.put(Clip.IDLE.key, "idle");
        defaultClips.put(Clip.ATTACK.key, "shooting");
        defaultClips.put(Clip.PRODUCE.key, "idle");
        defaultClips.put(Clip.WALK.key, "walk");
        defaultClips.put(Clip.EAT.key, "eat");
        defaultClips.put(Clip.INTRO.key, "intro");
        defaultClips.put(Clip.CHARGE.key, "idle");

        defaultClips.put(Clip.DEATH.key, "idle");

        load();
    }

    private void load() {

        FileHandle file = Art.findFile(MAPPING_FILE);
        if (file == null) {
            FileHandle bundled = Gdx.files.classpath("pam/mapping.json");
            if (bundled.exists()) {
                file = bundled;
            } else {
                Gdx.app.log("PamCatalog", MAPPING_FILE + " not found from working directory "
                        + new File("").getAbsolutePath() + "; using name-based PAM guesses.");
                return;
            }
        }
        try {
            JsonValue root = new JsonReader().parse(file);

            JsonValue defaults = root.get("defaults");
            if (defaults != null) {
                plantPamPattern = defaults.getString("plantPam", plantPamPattern);
                zombiePamPattern = defaults.getString("zombiePam", zombiePamPattern);
                JsonValue clips = defaults.get("clips");
                if (clips != null) {
                    for (JsonValue c = clips.child; c != null; c = c.next) {
                        defaultClips.put(c.name, c.asString());
                    }
                }
            }

            readSection(root.get("plants"), plants);
            readSection(root.get("zombies"), zombies);

            Gdx.app.log("PamCatalog", "Loaded " + plants.size() + " plant and "
                    + zombies.size() + " zombie PAM overrides.");
        } catch (Exception e) {
            Gdx.app.error("PamCatalog", "Could not read " + MAPPING_FILE + ": " + e.getMessage());
        }
    }

    private static void readSection(JsonValue section, Map<String, Entry> target) {
        if (section == null) return;
        for (JsonValue node = section.child; node != null; node = node.next) {
            if (!node.isObject()) continue;
            Entry entry = new Entry();
            entry.pam = node.getString("pam", null);
            JsonValue clips = node.get("clips");
            if (clips != null) {
                for (JsonValue c = clips.child; c != null; c = c.next) {
                    entry.clips.put(c.name, c.asString());
                }
            }
            target.put(node.name.toUpperCase(), entry);
        }
    }

    public String plantPam(PlantType type) {
        if (type == null) return null;
        Entry entry = plants.get(type.name());
        if (entry != null && entry.pam != null) return entry.pam;
        return String.format(plantPamPattern, type.name(), type.name());
    }

    public String zombiePam(ZombieType type) {
        if (type == null) return null;
        Entry entry = zombies.get(type.name());
        if (entry != null && entry.pam != null) return entry.pam;
        return String.format(zombiePamPattern, type.name(), type.name());
    }

    public String plantClip(PlantType type, Clip clip) {
        return clipFor(plants, type == null ? null : type.name(), clip);
    }

    public String zombieClip(ZombieType type, Clip clip) {
        return clipFor(zombies, type == null ? null : type.name(), clip);
    }

    private String clipFor(Map<String, Entry> source, String name, Clip clip) {
        if (name != null) {
            Entry entry = source.get(name);
            if (entry != null) {
                String override = entry.clips.get(clip.key);
                if (override != null) return override;
            }
        }
        String fallback = defaultClips.get(clip.key);
        return fallback != null ? fallback : clip.key;
    }
}
