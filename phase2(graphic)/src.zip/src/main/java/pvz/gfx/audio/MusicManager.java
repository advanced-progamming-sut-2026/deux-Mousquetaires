package pvz.gfx.audio;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.files.FileHandle;
import pvz.gfx.art.Art;

public class MusicManager {

    private static final String[] EXTENSIONS = {"mp3", "ogg", "wav"};

    private Music current;
    private String currentKey;

    public void play(String key, boolean musicOn) {
        if (key == null) return;
        if (key.equals(currentKey) && current != null) {
            setEnabled(musicOn);
            return;
        }
        stop();
        currentKey = key;
        FileHandle handle = findTrack(key);
        if (handle == null) return;
        try {
            current = Gdx.audio.newMusic(handle);
            current.setLooping(true);
            current.setVolume(0.6f);
            if (musicOn) current.play();
        } catch (Exception e) {
            Gdx.app.error("MusicManager", "Could not load music for " + key + ": " + e.getMessage());
            current = null;
        }
    }

    public void setEnabled(boolean enabled) {
        if (current == null) return;
        if (enabled) {
            if (!current.isPlaying()) current.play();
        } else {
            current.pause();
        }
    }

    public void stop() {
        if (current != null) {
            current.stop();
            current.dispose();
            current = null;
        }
        currentKey = null;
    }

    private FileHandle findTrack(String key) {
        for (String ext : EXTENSIONS) {
            FileHandle handle = Art.findFile("assets/music/" + key + "." + ext);
            if (handle != null && handle.exists()) return handle;
        }
        return null;
    }
}
