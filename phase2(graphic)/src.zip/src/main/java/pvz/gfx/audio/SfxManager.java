package pvz.gfx.audio;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.files.FileHandle;
import pvz.gfx.art.Art;

import java.util.HashMap;
import java.util.Map;

public class SfxManager {

    private static final String[] EXTENSIONS = {"mp3", "ogg", "wav"};

    private final Map<String, Sound> cache = new HashMap<>();

    public void play(String key, boolean sfxOn) {
        if (!sfxOn || key == null) return;
        Sound sound = load(key);
        if (sound != null) sound.play(0.7f);
    }

    private Sound load(String key) {
        if (cache.containsKey(key)) return cache.get(key);
        Sound sound = null;
        FileHandle handle = findTrack(key);
        if (handle != null) {
            try {
                sound = Gdx.audio.newSound(handle);
            } catch (Exception e) {
                Gdx.app.error("SfxManager", "Could not load sfx for " + key + ": " + e.getMessage());
            }
        }
        cache.put(key, sound);
        return sound;
    }

    private FileHandle findTrack(String key) {
        for (String ext : EXTENSIONS) {
            FileHandle handle = Art.findFile("assets/sfx/" + key + "." + ext);
            if (handle != null && handle.exists()) return handle;
        }
        return null;
    }

    public void dispose() {
        for (Sound sound : cache.values()) {
            if (sound != null) sound.dispose();
        }
        cache.clear();
    }
}