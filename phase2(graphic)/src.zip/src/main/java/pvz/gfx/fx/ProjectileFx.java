package pvz.gfx.fx;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.utils.Array;
import pvz.gfx.Layout;
import pvz.gfx.art.Art;
import pvz.gfx.art.Backdrops;
import pvz.model.entity.plant.PlantCatalog;
import pvz.model.enums.PlantType;
import pvz.model.session.ActiveZombie;
import pvz.model.session.GameSession;
import pvz.model.session.PlantedUnit;
import pvz.gfx.audio.SfxManager;

import java.util.HashMap;
import java.util.Map;

public class ProjectileFx {

    public enum Kind {
        STRAIGHT,
        LOB
    }

    private static final float LOB_FLIGHT_SECONDS = 0.85f;
    private static final float STRAIGHT_SPEED = 420f;
    private static final float LOB_PEAK = 120f;
    private static final int SHOT_SIZE = 18;

    private static final Color PEA = new Color(0.42f, 0.85f, 0.25f, 1f);
    private static final Color ICE = new Color(0.55f, 0.85f, 1f, 1f);
    private static final Color FIRE = new Color(1f, 0.52f, 0.16f, 1f);
    private static final Color MELON = new Color(0.35f, 0.72f, 0.30f, 1f);
    private static final Color SPORE = new Color(0.72f, 0.58f, 0.90f, 1f);

    private static final class Shot {
        float startX, startY, endX, endY;
        float elapsed, duration;
        Kind kind;
        Color color;
        String key;
    }

    private final Art art;
    private final SfxManager sfx = new SfxManager();
    private boolean sfxOn = true;

    public void setSfxOn(boolean sfxOn) {
        this.sfxOn = sfxOn;
    }
    private final Array<Shot> shots = new Array<>();

    private final Map<PlantedUnit, Float> timers = new HashMap<>();

    public ProjectileFx(Art art) {
        this.art = art;
    }

    public void update(float delta, GameSession session) {
        if (session == null) return;

        java.util.List<PlantedUnit> onLawn = session.getPlantsOnLawn();
        timers.keySet().retainAll(onLawn);

        for (PlantedUnit unit : onLawn) {
            PlantType type = unit.getType();
            if (type == null) continue;

            PlantCatalog.Stats stats = PlantCatalog.of(type);
            if (stats == null || !isShooter(type, stats)) continue;

            if (unit.isFrozen() || unit.isDisabled()) continue;

            float interval = stats.actionIntervalTicks / (float) GameSession.TICKS_PER_SECOND;
            if (interval <= 0f) interval = 1.4f;

            Float stored = timers.get(unit);
            float remaining = (stored == null ? interval * 0.35f : stored) - delta;
            if (remaining <= 0f) {
                ActiveZombie target = nearestTargetInLane(session, unit, stats.range);
                if (target != null) {
                    spawn(unit, target, type);
                    remaining = interval;
                } else {

                    remaining = 0.2f;
                }
            }
            timers.put(unit, remaining);
        }

        for (int i = shots.size - 1; i >= 0; i--) {
            Shot shot = shots.get(i);
            shot.elapsed += delta;
            if (shot.elapsed >= shot.duration) shots.removeIndex(i);
        }
    }

    private void spawn(PlantedUnit unit, ActiveZombie target, PlantType type) {
        sfx.play("plant_shoot", sfxOn);
        Shot shot = new Shot();
        shot.kind = isLobber(type) ? Kind.LOB : Kind.STRAIGHT;
        shot.color = colorFor(type);
        shot.key = type.name();

        shot.startX = Layout.cellCenterX(unit.getCol()) + 14f;
        shot.startY = Layout.cellCenterY(unit.getRow()) + (shot.kind == Kind.LOB ? 22f : 8f);
        shot.endX = Layout.cellCenterX((float) target.getCol());
        shot.endY = Layout.cellCenterY(target.getRow()) - 6f;

        if (shot.kind == Kind.LOB) {
            shot.duration = LOB_FLIGHT_SECONDS;
        } else {
            float distance = Math.max(1f, Math.abs(shot.endX - shot.startX));
            shot.duration = distance / STRAIGHT_SPEED;
        }
        shots.add(shot);
    }

    private ActiveZombie nearestTargetInLane(GameSession session, PlantedUnit unit, float rangeCells) {
        float range = rangeCells <= 0f ? GameSession.COLS : rangeCells;
        ActiveZombie best = null;
        double bestCol = Double.MAX_VALUE;

        for (ActiveZombie zombie : session.getZombiesOnLawn()) {
            if (zombie.getRow() != unit.getRow()) continue;
            double col = zombie.getCol();
            if (col < unit.getCol()) continue;
            if (col - unit.getCol() > range) continue;
            if (col < bestCol) {
                bestCol = col;
                best = zombie;
            }
        }
        return best;
    }

    public void draw(Batch batch) {
        Color previous = batch.getColor().cpy();
        for (Shot shot : shots) {
            float t = shot.duration <= 0f ? 1f : Math.min(1f, shot.elapsed / shot.duration);
            float x = shot.startX + (shot.endX - shot.startX) * t;
            float y = shot.startY + (shot.endY - shot.startY) * t;

            if (shot.kind == Kind.LOB) {

                y += LOB_PEAK * 4f * t * (1f - t);
            }

            TextureRegion region = art.region(regionFor(shot));
            if (region != null) {
                batch.setColor(Color.WHITE);
                float w = SHOT_SIZE + 8f;
                float h = w * region.getRegionHeight() / (float) Math.max(1, region.getRegionWidth());
                batch.draw(region, x - w / 2f, y - h / 2f, w, h);
            } else {
                batch.setColor(shot.color);
                batch.draw(art.placeholder(shot.key + "_shot", SHOT_SIZE, SHOT_SIZE, true),
                        x - SHOT_SIZE / 2f, y - SHOT_SIZE / 2f, SHOT_SIZE, SHOT_SIZE);
            }
        }
        batch.setColor(previous);
    }

    private String regionFor(Shot shot) {
        if (shot.color == ICE) return Backdrops.PROJECTILE_ICE;
        if (shot.color == FIRE) return Backdrops.PROJECTILE_FIRE;
        return Backdrops.PROJECTILE_PEA;
    }

    public void clear() {
        shots.clear();
        timers.clear();
    }
    public void dispose() {
        sfx.dispose();
    }

    private static boolean isShooter(PlantType type, PlantCatalog.Stats stats) {
        if (stats.damage <= 0 || stats.actionIntervalTicks <= 0) return false;
        if (stats.range <= 0f) return false;

        String name = type.name();

        if (name.contains("SUNFLOWER") || name.contains("SUN_SHROOM") || name.contains("GOLD_BLOOM")) return false;
        if (name.contains("WALL_NUT") || name.contains("TALL_NUT") || name.contains("GARLIC")) return false;
        if (name.contains("POTATO_MINE") || name.contains("CHERRY_BOMB") || name.contains("JALAPENO")) return false;
        if (name.contains("SQUASH") || name.contains("CHOMPER") || name.contains("BONK_CHOY")) return false;
        if (name.contains("ICEBERG") || name.contains("LILY_PAD") || name.contains("PUMPKIN")) return false;
        return true;
    }

    private static boolean isLobber(PlantType type) {
        String name = type.name();
        return name.contains("PULT") || name.contains("MELON") || name.contains("BLOOMERANG");
    }

    private static Color colorFor(PlantType type) {
        String name = type.name();
        if (name.contains("SNOW") || name.contains("ICE") || name.contains("WINTER")) return ICE;
        if (name.contains("FIRE") || name.contains("PEPPER") || name.contains("TORCH")) return FIRE;
        if (name.contains("MELON") || name.contains("CABBAGE") || name.contains("KERNEL")) return MELON;
        if (name.contains("SHROOM") || name.contains("FUME")) return SPORE;
        return PEA;
    }
}
