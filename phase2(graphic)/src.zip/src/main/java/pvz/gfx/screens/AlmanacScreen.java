package pvz.gfx.screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.Touchable;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.ScrollPane;
import com.badlogic.gdx.scenes.scene2d.ui.Stack;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.Align;
import com.badlogic.gdx.utils.Scaling;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import pvz.gfx.Layout;
import pvz.gfx.PvzGame;
import pvz.gfx.actors.SeedCardActor;
import pvz.gfx.art.Backdrops;
import pvz.gfx.art.CompositeZombies;
import pvz.gfx.art.PamCatalog;
import pvz.model.auth.Collection;
import pvz.model.entity.plant.PlantCatalog;
import pvz.model.entity.zombie.ZombieCatalog;
import pvz.model.enums.PlantFamily;
import pvz.model.enums.PlantTag;
import pvz.model.enums.PlantType;
import pvz.model.enums.ZombieType;

public class AlmanacScreen implements Screen {

    private enum Tab { PLANTS, ZOMBIES }

    private static final int[] PACKETS_TO_UPGRADE = {0, 10, 25, 50, 100};

    private static final String[] STATUS_NAMES = {"All", "Unlocked", "Locked", "Upgradeable"};

    private final PvzGame game;

    private Viewport viewport;
    private Stage stage;
    private Table root;

    private Tab tab = Tab.PLANTS;
    private PlantType selectedPlant = PlantType.values()[0];
    private ZombieType selectedZombie = ZombieType.values()[0];

    private PlantFamily familyFilter = null;
    private int statusFilter = 0;

    private String message = "";

    public AlmanacScreen(PvzGame game) {
        this.game = game;
    }

    @Override
    public void show() {
        viewport = new FitViewport(Layout.WORLD_W, Layout.WORLD_H);
        stage = new Stage(viewport, game.batch());
        Gdx.input.setInputProcessor(stage);

        addBackground();

        root = new Table();
        root.setFillParent(true);
        root.pad(20f).top();
        stage.addActor(root);

        rebuild();
    }

    private void addBackground() {
        TextureRegion region = Backdrops.first(game.art(), Backdrops.MENU_TUTORIAL,
                Backdrops.MENU_EGYPT, Backdrops.MENU_WEST, Backdrops.MENU_PIRATE, Backdrops.MENU_BEACH);
        if (region != null) {
            Image image = new Image(new TextureRegionDrawable(region));
            image.setFillParent(true);
            image.setScaling(Scaling.fill);
            stage.addActor(image);
        }
        TextureRegion pixel = game.art().pixel();
        if (pixel != null) {
            Image shade = new Image(new TextureRegionDrawable(pixel));
            shade.setFillParent(true);
            shade.setColor(0f, 0f, 0f, region != null ? 0.5f : 0.72f);
            stage.addActor(shade);
        }
    }

    private void rebuild() {
        root.clear();

        Label heading = new Label("Collection", game.skin(), "big");
        Label wallet = new Label(walletText(), game.skin(), "default");
        wallet.setAlignment(Align.right);
        Table header = new Table();
        header.add(heading).left().expandX();
        header.add(wallet).right();
        root.add(header).growX().padBottom(10f).row();

        Table tabs = new Table();
        tabs.left();
        tabs.add(tabButton("Plants", Tab.PLANTS)).width(160f).padRight(8f);
        tabs.add(tabButton("Zombies", Tab.ZOMBIES)).width(160f);
        root.add(tabs).left().padBottom(8f).row();

        if (tab == Tab.PLANTS) {
            Table filters = new Table();
            filters.left();
            filters.add(new Label("Filter:", game.skin(), "default")).padRight(8f);
            filters.add(familyButton()).width(230f).padRight(8f);
            filters.add(statusButton()).width(210f);
            root.add(filters).left().padBottom(8f).row();
        }

        Table main = new Table();
        main.top();
        ScrollPane listPane = new ScrollPane(buildList(), game.skin());
        listPane.setFadeScrollBars(false);
        listPane.setScrollingDisabled(true, false);
        main.add(listPane).width(720f).height(430f).top().padRight(14f);
        main.add(buildDetail()).width(440f).height(430f).top();
        root.add(main).expand().fill().row();

        Label status = new Label(message == null ? "" : message, game.skin(), "default");
        status.setWrap(true);
        status.setColor(1f, 0.93f, 0.6f, 1f);
        root.add(status).growX().padTop(8f).row();

        TextButton back = new TextButton("Back to menu", game.skin(), "brown");
        back.addListener(click(new Runnable() {
            @Override public void run() {
                game.save();
                game.setScreen(new MainMenuScreen(game));
            }
        }));
        root.add(back).width(240f).padTop(8f).row();
    }

    private TextButton tabButton(String text, final Tab which) {
        TextButton button = new TextButton(text, game.skin(), tab == which ? "green" : "purple");
        button.addListener(click(new Runnable() {
            @Override public void run() {
                tab = which;
                message = "";
                rebuild();
            }
        }));
        return button;
    }

    private TextButton familyButton() {
        String text = "Family: " + (familyFilter == null ? "All" : pretty(familyFilter.name()));
        TextButton button = new TextButton(text, game.skin(), "brown");
        button.addListener(click(new Runnable() {
            @Override public void run() {
                familyFilter = nextFamily(familyFilter);
                rebuild();
            }
        }));
        return button;
    }

    private TextButton statusButton() {
        TextButton button = new TextButton("Show: " + STATUS_NAMES[statusFilter], game.skin(), "brown");
        button.addListener(click(new Runnable() {
            @Override public void run() {
                statusFilter = (statusFilter + 1) % STATUS_NAMES.length;
                rebuild();
            }
        }));
        return button;
    }

    private Table buildList() {
        Table grid = new Table();
        grid.top().left();
        Collection collection = game.user().getCollection();

        if (tab == Tab.PLANTS) {
            int column = 0;
            for (PlantType type : PlantType.values()) {
                if (!passesFilter(type, collection)) continue;
                grid.add(plantCard(type, collection)).pad(6f).top();
                if (++column % 5 == 0) grid.row();
            }
            if (column == 0) {
                grid.add(new Label("No plants match this filter.", game.skin(), "default")).pad(12f);
            }
        } else {
            int column = 0;
            for (ZombieType type : ZombieType.values()) {
                grid.add(zombieCard(type, collection)).pad(6f).top();
                if (++column % 6 == 0) grid.row();
            }
        }
        return grid;
    }

    private Table plantCard(final PlantType type, Collection collection) {
        boolean unlocked = collection.isPlantUnlocked(type);

        SeedCardActor actor = new SeedCardActor(game.art(), game.pam(), game.skin(), type,
                SeedCardActor.Mode.COLLECTION);
        actor.setLocked(!unlocked);
        actor.setLevel(unlocked ? collection.getPlantLevel(type) : 0);
        actor.setBoosted(game.boostedPlants().contains(type));

        Table card = new Table();
        card.add(actor).size(SeedCardActor.CARD_W, SeedCardActor.CARD_H).row();

        String caption;
        if (!unlocked) {
            caption = "Locked";
        } else {
            int level = collection.getPlantLevel(type);
            int need = packetsToUpgrade(level);
            int have = game.user().getSeedPackets(type);
            caption = "Lv " + level + (need > 0 ? "  " + have + "/" + need : "  MAX");
        }
        Label cap = new Label(caption, game.skin(), "default");
        cap.setFontScale(0.72f);
        if (selectedPlant == type) cap.setColor(1f, 1f, 0.5f, 1f);
        card.add(cap).padTop(2f);

        card.setTouchable(Touchable.enabled);
        card.addListener(click(new Runnable() {
            @Override public void run() {
                selectedPlant = type;
                message = "";
                rebuild();
            }
        }));
        return card;
    }

    private Table zombieCard(final ZombieType type, Collection collection) {
        boolean seen = collection.isZombieUnlocked(type);

        Stack stack = new Stack();
        Image bg = new Image(new TextureRegionDrawable(game.art().pixel()));
        bg.setColor(seen ? new Color(0.16f, 0.14f, 0.10f, 1f) : new Color(0.07f, 0.07f, 0.07f, 1f));
        stack.add(bg);
        if (seen) {
            if (CompositeZombies.isComposite(type)) {
                stack.add(new RigActor(game.art(), game.pam(), type, type.name()));
            } else {
                stack.add(new RigActor(game.art(), game.pam().zombiePam(type),
                        game.pam().zombieClip(type, PamCatalog.Clip.IDLE), null, type.name()));
            }
        } else {
            Label q = new Label("?", game.skin(), "big");
            q.setAlignment(Align.center);
            Table wrap = new Table();
            wrap.add(q).expand().center();
            stack.add(wrap);
        }

        Table card = new Table();
        card.add(stack).size(80f, 100f).row();
        Label name = new Label(seen ? pretty(type.name()) : "???", game.skin(), "default");
        name.setFontScale(0.7f);
        if (selectedZombie == type) name.setColor(1f, 1f, 0.5f, 1f);
        card.add(name).padTop(2f);

        card.setTouchable(Touchable.enabled);
        card.addListener(click(new Runnable() {
            @Override public void run() {
                selectedZombie = type;
                message = "";
                rebuild();
            }
        }));
        return card;
    }

    private Table buildDetail() {
        return tab == Tab.PLANTS ? plantDetail() : zombieDetail();
    }

    private Table plantDetail() {
        final PlantType type = selectedPlant;
        Collection collection = game.user().getCollection();
        boolean unlocked = collection.isPlantUnlocked(type);
        PlantCatalog.Stats stats = PlantCatalog.of(type);

        Table detail = new Table();
        detail.top().left();

        Table top = new Table();
        top.top().left();
        top.add(new RigActor(game.art(), game.pam().plantPam(type),
                game.pam().plantClip(type, PamCatalog.Clip.IDLE), null, type.name()))
                .size(120f, 150f).padRight(12f);

        Table info = new Table();
        info.top().left();
        info.add(new Label(pretty(type.name()), game.skin(), "big")).left().row();
        info.add(statLine("Family", pretty(stats.family.name()))).left().row();
        info.add(statLine("Health", String.valueOf(stats.hp))).left().row();
        info.add(statLine("Sun cost", String.valueOf(stats.sunCost))).left().row();
        if (stats.damage > 0 && stats.damage < 99999) {
            info.add(statLine("Damage", String.valueOf(stats.damage))).left().row();
        }
        info.add(statLine("Recharge", seconds(stats.rechargeTicks))).left().row();
        info.add(statLine(unlocked ? "Level" : "Status",
                unlocked ? collection.getPlantLevel(type) + "/" + Collection.MAX_PLANT_LEVEL : "Locked"))
                .left().row();
        top.add(info).top().left();
        detail.add(top).left().padBottom(8f).row();

        detail.add(wrapped("Tags: " + tagList(stats.tags))).left().width(430f).row();
        detail.add(wrapped(stats.description)).left().width(430f).padTop(6f).row();
        Label food = wrapped("Plant Food: " + stats.plantFoodEffect);
        food.setColor(0.7f, 1f, 0.7f, 1f);
        detail.add(food).left().width(430f).padTop(6f).row();
        detail.add(wrapped("Upgrades: " + upgradesText(stats.upgrades))).left().width(430f).padTop(6f).row();

        if (unlocked) {
            int level = collection.getPlantLevel(type);
            int need = packetsToUpgrade(level);
            int have = game.user().getSeedPackets(type);
            if (need > 0) {
                detail.add(new Label("Seed packets: " + have + " / " + need + " for next level",
                        game.skin(), "default")).left().padTop(10f).row();
                TextButton upgrade = new TextButton("Upgrade (needs " + need + " packets)",
                        game.skin(), "green");
                upgrade.addListener(click(new Runnable() {
                    @Override public void run() { upgradePlant(type); }
                }));
                detail.add(upgrade).left().padTop(6f).row();
            } else {
                detail.add(new Label("Fully upgraded (max level).", game.skin(), "default"))
                        .left().padTop(10f).row();
            }
        } else {
            final int cost = unlockCost(stats);
            detail.add(new Label("Unlock cost: " + cost + " coins", game.skin(), "default"))
                    .left().padTop(10f).row();
            TextButton buy = new TextButton("Buy plant (" + cost + " coins)", game.skin(), "green");
            buy.addListener(click(new Runnable() {
                @Override public void run() { buyPlant(type, cost); }
            }));
            detail.add(buy).left().padTop(6f).row();
        }
        return detail;
    }

    private Table zombieDetail() {
        ZombieType type = selectedZombie;
        Collection collection = game.user().getCollection();
        boolean seen = collection.isZombieUnlocked(type);

        Table detail = new Table();
        detail.top().left();

        if (!seen) {
            detail.add(new Label("???", game.skin(), "big")).left().row();
            detail.add(wrapped("You haven't encountered this zombie yet. Face it in a level to "
                    + "add it to your Almanac.")).left().width(430f).padTop(8f).row();
            return detail;
        }

        ZombieCatalog.Stats stats = ZombieCatalog.of(type);

        Table top = new Table();
        top.top().left();
        if (CompositeZombies.isComposite(type)) {
            top.add(new RigActor(game.art(), game.pam(), type, type.name()))
                    .size(120f, 150f).padRight(12f);
        } else {
            top.add(new RigActor(game.art(), game.pam().zombiePam(type),
                    game.pam().zombieClip(type, PamCatalog.Clip.IDLE), null, type.name()))
                    .size(120f, 150f).padRight(12f);
        }

        Table info = new Table();
        info.top().left();
        info.add(new Label(pretty(type.name()), game.skin(), "big")).left().row();
        info.add(statLine("Health", String.valueOf(stats.hp))).left().row();
        if (stats.armorHp > 0) info.add(statLine("Armor", String.valueOf(stats.armorHp))).left().row();
        info.add(statLine("Speed", speedText(stats.cellsPerSecond))).left().row();
        info.add(statLine("Damage", String.valueOf(stats.damagePerSecond))).left().row();
        top.add(info).top().left();
        detail.add(top).left().padBottom(8f).row();

        detail.add(wrapped(stats.description)).left().width(430f).padTop(6f).row();
        return detail;
    }

    private void buyPlant(PlantType type, int cost) {
        Collection collection = game.user().getCollection();
        if (collection.isPlantUnlocked(type)) {
            message = pretty(type.name()) + " is already unlocked.";
            rebuild();
            return;
        }
        if (!game.user().spendCoins(cost)) {
            message = "Not enough coins to buy " + pretty(type.name()) + " (need " + cost
                    + ", you have " + game.user().getCoins() + ").";
            rebuild();
            return;
        }
        collection.unlockPlant(type);
        game.save();
        message = pretty(type.name()) + " unlocked!";
        rebuild();
    }

    private void upgradePlant(PlantType type) {
        Collection collection = game.user().getCollection();
        int level = collection.getPlantLevel(type);
        int need = packetsToUpgrade(level);
        if (need <= 0) {
            message = pretty(type.name()) + " is already at max level.";
            rebuild();
            return;
        }
        int have = game.user().getSeedPackets(type);
        if (have < need) {
            message = "Not enough seed packets to upgrade " + pretty(type.name())
                    + " (" + have + "/" + need + ").";
            rebuild();
            return;
        }
        game.user().spendSeedPackets(type, need);
        collection.upgradePlant(type);
        game.save();
        message = pretty(type.name()) + " upgraded to level " + collection.getPlantLevel(type) + "!";
        rebuild();
    }

    private boolean passesFilter(PlantType type, Collection collection) {
        if (familyFilter != null && PlantCatalog.of(type).family != familyFilter) return false;
        boolean unlocked = collection.isPlantUnlocked(type);
        switch (statusFilter) {
            case 1: return unlocked;
            case 2: return !unlocked;
            case 3:
                if (!unlocked) return false;
                int level = collection.getPlantLevel(type);
                int need = packetsToUpgrade(level);
                return need > 0 && game.user().getSeedPackets(type) >= need;
            default: return true;
        }
    }

    private int packetsToUpgrade(int level) {
        if (level < 1 || level >= Collection.MAX_PLANT_LEVEL) return 0;
        return PACKETS_TO_UPGRADE[level];
    }

    private int unlockCost(PlantCatalog.Stats stats) {
        return Math.max(1000, stats.sunCost * 20);
    }

    private PlantFamily nextFamily(PlantFamily current) {
        PlantFamily[] all = PlantFamily.values();
        if (current == null) return all[0];
        int next = current.ordinal() + 1;
        return next >= all.length ? null : all[next];
    }

    private Table statLine(String key, String value) {
        Table line = new Table();
        line.left();
        Label k = new Label(key + ":  ", game.skin(), "default");
        k.setColor(0.8f, 0.85f, 0.92f, 1f);
        line.add(k).left();
        line.add(new Label(value, game.skin(), "default")).left();
        return line;
    }

    private Label wrapped(String text) {
        Label label = new Label(text, game.skin(), "default");
        label.setWrap(true);
        label.setWidth(430f);
        return label;
    }

    private String tagList(java.util.Set<PlantTag> tags) {
        if (tags == null || tags.isEmpty()) return "-";
        StringBuilder builder = new StringBuilder();
        for (PlantTag tag : tags) {
            if (builder.length() > 0) builder.append(", ");
            builder.append(pretty(tag.name()));
        }
        return builder.toString();
    }

    private String upgradesText(String[] upgrades) {
        if (upgrades == null || upgrades.length == 0) return "-";
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < upgrades.length; i++) {
            String value = upgrades[i];
            if (value == null || value.isEmpty() || "-".equals(value)) continue;
            if (builder.length() > 0) builder.append("   ");
            builder.append("Lv").append(i + 2).append(": ").append(value);
        }
        return builder.length() == 0 ? "-" : builder.toString();
    }

    private String seconds(int ticks) {
        double value = ticks / 10.0;
        return (value == Math.rint(value) ? String.valueOf((long) value) : String.valueOf(value)) + "s";
    }

    private String speedText(float cellsPerSecond) {
        String word;
        if (cellsPerSecond <= 0.0f) word = "Stationary";
        else if (cellsPerSecond < 0.15f) word = "Slow";
        else if (cellsPerSecond < 0.20f) word = "Basic";
        else if (cellsPerSecond < 0.26f) word = "Speedy";
        else word = "Fast";
        return word + " (" + cellsPerSecond + "/s)";
    }

    private static String pretty(String constant) {
        StringBuilder builder = new StringBuilder();
        for (String word : constant.split("_")) {
            if (word.isEmpty()) continue;
            if (builder.length() > 0) builder.append(' ');
            builder.append(Character.toUpperCase(word.charAt(0)))
                    .append(word.substring(1).toLowerCase());
        }
        return builder.toString();
    }

    private String walletText() {
        return "Coins " + game.user().getCoins() + "   Gems " + game.user().getGems();
    }

    private ClickListener click(final Runnable action) {
        return new ClickListener() {
            @Override public void clicked(InputEvent event, float x, float y) {
                action.run();
            }
        };
    }

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(0.07f, 0.13f, 0.09f, 1f);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        game.art().update();
        stage.act(delta);
        stage.draw();
    }

    @Override
    public void resize(int width, int height) {
        viewport.update(width, height, true);
    }

    @Override
    public void pause() {
    }

    @Override
    public void resume() {
    }

    @Override
    public void hide() {
        Gdx.input.setInputProcessor(null);
    }

    @Override
    public void dispose() {
        if (stage != null) stage.dispose();
    }
}
