package pvz.gfx.screens;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import pvz.gfx.PvzGame;
import pvz.gfx.art.Backdrops;
import pvz.model.enums.MiniGameType;
import pvz.model.enums.PlantType;
import pvz.model.minigame.Beghouled;

public class BeghouledScreen extends MiniGameScreen {

    private static final float TILE_X = 300f;
    private static final float TILE_Y = 150f;
    private static final float TILE_W = 84f;
    private static final float TILE_H = 96f;

    private final Beghouled board;

    private int selectedRow = -1;
    private int selectedCol = -1;

    public BeghouledScreen(PvzGame game, int level) {
        this(game, level, new Beghouled(level));
    }

    private BeghouledScreen(PvzGame game, int level, Beghouled board) {
        super(game, MiniGameType.BEGHOULED, level, board);
        this.board = board;
    }

    @Override
    protected String gameTitle() {
        return "Beghouled";
    }

    @Override
    protected String statusLine() {
        return "Sun " + board.getSun() + " / " + board.getTarget() + "     Swaps " + board.getSwaps();
    }

    @Override
    protected String[] backdrops() {
        return new String[]{Backdrops.MENU_TUTORIAL, Backdrops.LAWN_CENTER, Backdrops.EGYPT_CENTER};
    }

    private PlantType plantFor(char symbol) {
        switch (symbol) {
            case 'P':
                return PvzGame.byName("PEASHOOTER");
            case 'R':
                return PvzGame.byName("REPEATER");
            case 'G':
                return PvzGame.byName("GATLING_PEA");
            case 'W':
                return PvzGame.byName("WALL_NUT");
            case 'T':
                return PvzGame.byName("TALL_NUT");
            case 'F':
                return PvzGame.byName("PUFF_SHROOM");
            case 'U':
                return PvzGame.byName("FUME_SHROOM");
            case 'C':
                return PvzGame.byName("CABBAGE_PULT");
            case 'M':
                return PvzGame.byName("MELON_PULT");
            case 'I':
                return PvzGame.byName("WINTER_MELON");
            case 'S':
                return PvzGame.byName("SUNFLOWER");
            default:
                return null;
        }
    }

    private float tileX(int col) {
        return TILE_X + col * TILE_W;
    }

    private float tileY(int row) {
        return TILE_Y + (board.getRows() - 1 - row) * TILE_H;
    }

    @Override
    protected void drawBoard(float delta) {
        SpriteBatch batch = game.batch();
        char[][] view = board.getBoardView();
        int rows = board.getRows();
        int cols = board.getCols();

        float plateW = cols * TILE_W + 24f;
        float plateH = rows * TILE_H + 24f;
        fill(batch, TILE_X - 12f, TILE_Y - 12f, plateW, plateH, 0.05f, 0.16f, 0.06f, 0.72f);

        for (int row = 0; row < rows; row++) {
            for (int col = 0; col < cols; col++) {
                float x = tileX(col);
                float y = tileY(row);
                boolean selected = (row == selectedRow && col == selectedCol);

                fill(batch, x + 2f, y + 2f, TILE_W - 4f, TILE_H - 4f,
                        selected ? 0.95f : 0.20f,
                        selected ? 0.85f : 0.42f,
                        selected ? 0.35f : 0.20f,
                        selected ? 0.55f : 0.35f);

                char symbol = view[row][col];
                if (symbol == '#') {
                    int timer = board.getCraterTimer(row, col);
                    fill(batch, x + 12f, y + 12f, TILE_W - 24f, TILE_H - 34f, 0.12f, 0.07f, 0.04f, 0.95f);
                    drawRegion(batch, Backdrops.SUN, x + TILE_W - 26f, y + TILE_H - 26f, 18f, 18f);
                    caption("crater " + timer, x, y + 4f, TILE_W);
                } else {
                    drawPlant(batch, plantFor(symbol), x + TILE_W / 2f, y + 8f, TILE_H - 16f);
                }
            }
        }

        float meterX = TILE_X + cols * TILE_W + 40f;
        float meterH = rows * TILE_H;
        fill(batch, meterX, TILE_Y, 34f, meterH, 0f, 0f, 0f, 0.5f);
        float ratio = board.getTarget() <= 0 ? 0f
                : Math.min(1f, board.getSun() / (float) board.getTarget());
        fill(batch, meterX + 4f, TILE_Y + 4f, 26f, (meterH - 8f) * ratio, 1f, 0.85f, 0.25f, 0.95f);
        drawRegion(batch, Backdrops.SUN, meterX - 6f, TILE_Y + meterH + 8f, 46f, 46f);
    }

    @Override
    protected void buildControls(Table controls) {
        int rows = board.getRows();
        int cols = board.getCols();

        for (int row = 0; row < rows; row++) {
            for (int col = 0; col < cols; col++) {
                final int r = row;
                final int c = col;
                clickZone(tileX(col), tileY(row), TILE_W, TILE_H, new Runnable() {
                    @Override
                    public void run() {
                        tap(r, c);
                    }
                });
            }
        }

        Table upgrades = new Table();
        upgrades.add(upgradeButton("Repeater  500", "repeater")).padRight(6f);
        upgrades.add(upgradeButton("Gatling  1500", "gatling")).padRight(6f);
        upgrades.add(upgradeButton("Tall-nut  500", "tallnut")).padRight(6f);
        upgrades.row();
        upgrades.add(upgradeButton("Fume  250", "fume")).padRight(6f).padTop(6f);
        upgrades.add(upgradeButton("Melon  1000", "melon")).padRight(6f).padTop(6f);
        upgrades.add(upgradeButton("Winter  750", "winter")).padTop(6f);

        controls.add(upgrades).left();
    }

    private com.badlogic.gdx.scenes.scene2d.ui.TextButton upgradeButton(String text, final String command) {
        return controlButton(text, "green_small", new Runnable() {
            @Override
            public void run() {
                send("upgrade " + command);
            }
        });
    }

    private void tap(int row, int col) {
        if (selectedRow < 0) {
            selectedRow = row;
            selectedCol = col;
            return;
        }
        if (selectedRow == row && selectedCol == col) {
            selectedRow = -1;
            selectedCol = -1;
            return;
        }

        int distance = Math.abs(selectedRow - row) + Math.abs(selectedCol - col);
        if (distance != 1) {
            selectedRow = row;
            selectedCol = col;
            return;
        }

        String command = "swap (" + (selectedCol + 1) + ", " + (selectedRow + 1) + ") ("
                + (col + 1) + ", " + (row + 1) + ")";
        selectedRow = -1;
        selectedCol = -1;
        send(command);
    }
}
