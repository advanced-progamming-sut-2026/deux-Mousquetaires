package pvz.gfx.screens;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import pvz.gfx.PvzGame;
import pvz.gfx.art.Backdrops;
import pvz.model.enums.MiniGameType;
import pvz.model.enums.PlantType;
import pvz.model.enums.ZombieType;
import pvz.model.minigame.WallnutBowling;

import java.util.List;

public class BowlingScreen extends MiniGameScreen {

    private static final float BELT_X = 60f;
    private static final float BELT_Y = 150f;
    private static final float BELT_W = 120f;
    private static final float BELT_H = 460f;

    private final WallnutBowling bowling;

    public BowlingScreen(PvzGame game, int level) {
        this(game, level, new WallnutBowling(level));
    }

    private BowlingScreen(PvzGame game, int level, WallnutBowling bowling) {
        super(game, MiniGameType.WALLNUT_BOWLING, level, bowling);
        this.bowling = bowling;
    }

    public static ZombieType zombieByName(String... names) {
        ZombieType[] all = ZombieType.values();
        for (String name : names) {
            for (ZombieType type : all) {
                if (type.name().equalsIgnoreCase(name)) return type;
            }
        }
        for (String name : names) {
            for (ZombieType type : all) {
                if (type.name().contains(name.toUpperCase())) return type;
            }
        }
        return all[0];
    }

    @Override
    protected String gameTitle() {
        return "Wall-nut Bowling";
    }

    @Override
    protected String statusLine() {
        return "Kills " + bowling.getKills() + " / " + bowling.getKillTarget()
                + "     Nuts on the belt " + bowling.getBeltView().size();
    }

    @Override
    protected float tickInterval() {
        return 0.9f;
    }

    @Override
    protected String[] backdrops() {
        return new String[]{Backdrops.LAWN_CENTER, Backdrops.EGYPT_CENTER};
    }

    @Override
    protected void drawBoard(float delta) {
        SpriteBatch batch = game.batch();
        drawGrid(batch);

        float lineX = cellX(4) - 3f;
        fill(batch, lineX, BOARD_Y, 6f, ROWS * CELL_H, 0.85f, 0.15f, 0.15f, 0.85f);

        if (game.art().region(Backdrops.CONVEYOR_BELT) != null) {
            drawRegion(batch, Backdrops.CONVEYOR_BELT, BELT_X, BELT_Y, BELT_W, BELT_H);
            drawRegion(batch, Backdrops.CONVEYOR_TOP, BELT_X, BELT_Y + BELT_H - 26f, BELT_W, 30f);
        } else {
            fill(batch, BELT_X, BELT_Y, BELT_W, BELT_H, 0.22f, 0.18f, 0.14f, 0.9f);
        }

        List<PlantType> belt = bowling.getBeltView();
        for (int i = 0; i < belt.size(); i++) {
            float y = BELT_Y + BELT_H - 96f - i * 86f;
            drawPlant(batch, belt.get(i), BELT_X + BELT_W / 2f, y, 74f);
        }

        ZombieType basic = zombieByName("BASIC", "NORMAL");
        for (int[] zombie : bowling.getZombieView()) {
            float x = smoothX(zombie[1]);
            float y = cellY(zombie[0]) + 6f;
            drawZombie(batch, basic, x, y, ZOMBIE_HEIGHT);

            float ratio = Math.max(0f, Math.min(1f, zombie[2] / 200f));
            fill(batch, x - 26f, y + ZOMBIE_HEIGHT + 6f, 52f, 6f, 0f, 0f, 0f, 0.6f);
            fill(batch, x - 25f, y + ZOMBIE_HEIGHT + 7f, 50f * ratio, 4f, 0.9f, 0.25f, 0.25f, 0.95f);
        }
    }

    @Override
    protected void buildControls(Table controls) {

        for (int lane = 1; lane <= ROWS; lane++) {
            final int laneIndex = lane;
            clickZone(BOARD_X, cellY(lane), COLS * CELL_W, CELL_H, new Runnable() {
                @Override
                public void run() {
                    send("bowl " + laneIndex);
                }
            });
            caption("lane " + lane, BOARD_X - 8f, cellCenterY(lane) - 12f, 70f);
        }

        caption("Belt", BELT_X, BELT_Y + BELT_H + 6f, BELT_W);

        Table lanes = new Table();
        for (int lane = 1; lane <= ROWS; lane++) {
            final int laneIndex = lane;
            lanes.add(controlButton("Bowl lane " + lane, "green_small", new Runnable() {
                @Override
                public void run() {
                    send("bowl " + laneIndex);
                }
            })).padRight(6f);
        }
        controls.add(lanes).left().row();
        controls.add(new Label("Click a lane to roll the next nut. Zombies advance on their own.",
                game.skin(), "default")).left().padTop(6f);
    }
}
