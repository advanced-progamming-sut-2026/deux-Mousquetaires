package pvz.gfx.screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Stack;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.Align;
import com.badlogic.gdx.utils.Scaling;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import pvz.gfx.Layout;
import pvz.gfx.PvzGame;
import pvz.gfx.art.Backdrops;
import pvz.gfx.art.PamCatalog;
import pvz.model.auth.GameProgress;
import pvz.model.enums.LevelType;
import pvz.model.enums.PlantType;
import pvz.model.enums.WorldType;
import pvz.model.session.LevelSpec;

public class ChaptersScreen implements Screen {

    private final PvzGame game;

    private Viewport viewport;
    private Stage stage;
    private Table root;
    private Image bgImage;
    private Image bgShade;

    private int selectedChapter = 1;

    public ChaptersScreen(PvzGame game) {
        this.game = game;
    }

    @Override
    public void show() {
        viewport = new FitViewport(Layout.WORLD_W, Layout.WORLD_H);
        stage = new Stage(viewport, game.batch());
        Gdx.input.setInputProcessor(stage);

        bgImage = new Image();
        bgImage.setFillParent(true);
        bgImage.setScaling(Scaling.fill);
        stage.addActor(bgImage);

        bgShade = new Image(new TextureRegionDrawable(game.art().pixel()));
        bgShade.setFillParent(true);
        bgShade.setColor(0f, 0f, 0f, 0.5f);
        stage.addActor(bgShade);

        root = new Table();
        root.setFillParent(true);
        root.pad(22f).top();
        stage.addActor(root);

        selectedChapter = furthestUnlockedChapter();
        rebuild();
    }

    private int furthestUnlockedChapter() {
        GameProgress progress = game.user().getProgress();
        int furthest = 1;
        for (int chapter = 1; chapter <= GameProgress.CHAPTERS; chapter++) {
            if (progress.isLevelUnlocked(chapter + "-1")) furthest = chapter;
        }
        return furthest;
    }

    private void rebuild() {
        root.clear();

        WorldType world = worldOf(selectedChapter);
        applyBackground(world);

        Label heading = new Label("Adventure", game.skin(), "big");
        Label wallet = new Label(walletText(), game.skin(), "default");
        wallet.setAlignment(Align.right);
        Table header = new Table();
        header.add(heading).left().expandX();
        header.add(wallet).right();
        root.add(header).growX().padBottom(12f).row();

        Table tabs = new Table();
        tabs.left();
        GameProgress progress = game.user().getProgress();
        for (int chapter = 1; chapter <= GameProgress.CHAPTERS; chapter++) {
            final int chosen = chapter;
            boolean open = progress.isLevelUnlocked(chapter + "-1");
            String style = chapter == selectedChapter ? "green" : (open ? "purple" : "brown");
            String caption = "Ch " + chapter + "  " + pretty(worldOf(chapter).name())
                    + (open ? "" : "  (locked)");
            TextButton tab = new TextButton(caption, game.skin(), style);
            tab.addListener(click(new Runnable() {
                @Override public void run() {
                    selectedChapter = chosen;
                    rebuild();
                }
            }));
            tabs.add(tab).height(46f).padRight(8f);
        }
        root.add(tabs).left().padBottom(12f).row();

        root.add(worldBanner(world)).growX().padBottom(14f).row();

        Table cards = new Table();
        cards.center();
        for (int level = 1; level <= GameProgress.LEVELS_PER_CHAPTER; level++) {
            cards.add(levelCard(selectedChapter, level)).pad(8f).top();
        }
        root.add(cards).expand().center().row();

        TextButton back = new TextButton("Back to menu", game.skin(), "brown");
        back.addListener(click(new Runnable() {
            @Override public void run() {
                game.save();
                game.setScreen(new MainMenuScreen(game));
            }
        }));
        root.add(back).width(240f).padTop(10f).row();
    }

    private void applyBackground(WorldType world) {
        TextureRegion region = Backdrops.first(game.art(), worldBackdrop(world),
                Backdrops.MENU_TUTORIAL, Backdrops.MENU_EGYPT);
        if (region != null) {
            bgImage.setDrawable(new TextureRegionDrawable(region));
            bgImage.setVisible(true);
            bgShade.setColor(0f, 0f, 0f, 0.5f);
        } else {
            bgImage.setVisible(false);
            bgShade.setColor(0.05f, 0.09f, 0.07f, 0.85f);
        }
    }

    private Table worldBanner(WorldType world) {
        Color accent = worldAccent(world);

        Stack stack = new Stack();
        Image panel = new Image(new TextureRegionDrawable(game.art().pixel()));
        panel.setColor(accent.r * 0.35f, accent.g * 0.35f, accent.b * 0.35f, 0.78f);
        stack.add(panel);

        Table content = new Table();
        content.pad(12f).left();

        TextureRegion thumb = Backdrops.first(game.art(), worldBackdrop(world));
        if (thumb != null) {
            Image image = new Image(new TextureRegionDrawable(thumb));
            image.setScaling(Scaling.fill);
            content.add(image).size(150f, 84f).padRight(16f);
        }

        Table text = new Table();
        text.left();
        Label name = new Label(pretty(world.name()), game.skin(), "big");
        name.setColor(accent);
        text.add(name).left().row();
        text.add(new Label("Chapter " + selectedChapter + " of " + GameProgress.CHAPTERS
                + "     " + clearedCount(selectedChapter) + "/" + GameProgress.LEVELS_PER_CHAPTER
                + " levels cleared", game.skin(), "default")).left();
        content.add(text).left().expandX();

        stack.add(content);
        Table wrap = new Table();
        wrap.add(stack).growX().height(110f);
        return wrap;
    }

    private Stack levelCard(int chapter, int level) {
        final LevelSpec spec = LevelSpec.adventure(chapter, level);
        GameProgress progress = game.user().getProgress();
        final boolean unlocked = spec != null && progress.isLevelUnlocked(spec.getId());
        final boolean cleared = spec != null && progress.isLevelCleared(spec.getId());
        WorldType world = worldOf(chapter);
        Color accent = worldAccent(world);

        Stack stack = new Stack();
        Image panel = new Image(new TextureRegionDrawable(game.art().pixel()));
        if (cleared) panel.setColor(0.12f, 0.28f, 0.14f, 0.9f);
        else if (unlocked) panel.setColor(0.10f, 0.12f, 0.16f, 0.9f);
        else panel.setColor(0.06f, 0.06f, 0.07f, 0.92f);
        stack.add(panel);

        Table card = new Table();
        card.pad(12f).top();

        Label id = new Label(spec == null ? "?" : spec.getId(), game.skin(), "big");
        id.setColor(accent);
        card.add(id).padBottom(6f).row();

        if (spec != null && spec.getRewardPlant() != null) {
            PlantType reward = spec.getRewardPlant();
            RigActor rig = new RigActor(game.art(), game.pam().plantPam(reward),
                    game.pam().plantClip(reward, PamCatalog.Clip.IDLE), null, reward.name());
            if (!unlocked) rig.setColor(0.4f, 0.4f, 0.4f, 1f);
            card.add(rig).size(96f, 116f).row();
            Label rewardName = new Label("Reward: " + pretty(reward.name()), game.skin(), "default");
            rewardName.setFontScale(0.72f);
            rewardName.setColor(0.8f, 1f, 0.8f, 1f);
            card.add(rewardName).padTop(2f).row();
        }

        if (spec != null) {
            Label type = new Label(pretty(spec.getLevelType().name()), game.skin(), "default");
            type.setColor(1f, 0.9f, 0.5f, 1f);
            card.add(type).padTop(6f).row();
            Label stats = new Label("Waves " + spec.getWaveCount() + "    Sun " + spec.getBaseBudget()
                    + "    Foes " + spec.getAllowedZombies().size(), game.skin(), "default");
            stats.setFontScale(0.72f);
            card.add(stats).padTop(2f).row();
        }

        Label badge = new Label(cleared ? "Cleared" : (unlocked ? "Ready" : "Locked"),
                game.skin(), "default");
        badge.setColor(cleared ? new Color(1f, 0.85f, 0.3f, 1f)
                : (unlocked ? new Color(0.6f, 1f, 0.6f, 1f) : new Color(0.7f, 0.7f, 0.7f, 1f)));
        card.add(badge).padTop(8f).row();

        TextButton play = new TextButton(cleared ? "Replay" : "Play", game.skin(),
                unlocked ? "green" : "brown");
        play.setDisabled(!unlocked);
        if (unlocked) {
            play.addListener(click(new Runnable() {
                @Override public void run() {
                    game.setScreen(new PlantSelectScreen(game, spec));
                }
            }));
        }
        card.add(play).width(150f).height(48f).padTop(8f).row();

        stack.add(card);

        Table sized = new Table();
        sized.add(stack).width(238f).height(344f);
        Stack outer = new Stack();
        outer.add(sized);
        return outer;
    }

    private int clearedCount(int chapter) {
        GameProgress progress = game.user().getProgress();
        int count = 0;
        for (int level = 1; level <= GameProgress.LEVELS_PER_CHAPTER; level++) {
            LevelSpec spec = LevelSpec.adventure(chapter, level);
            if (spec != null && progress.isLevelCleared(spec.getId())) count++;
        }
        return count;
    }

    private WorldType worldOf(int chapter) {
        LevelSpec spec = LevelSpec.adventure(chapter, 1);
        if (spec != null && spec.getWorld() != null) return spec.getWorld();
        switch (chapter) {
            case 1: return WorldType.ANCIENT_EGYPT;
            case 2: return WorldType.FROSTBITE_CAVES;
            case 3: return WorldType.BIG_WAVE_BEACH;
            default: return WorldType.DARK_AGES;
        }
    }

    private String worldBackdrop(WorldType world) {
        switch (world) {
            case ANCIENT_EGYPT: return Backdrops.MENU_EGYPT;
            case BIG_WAVE_BEACH: return Backdrops.MENU_BEACH;
            case DARK_AGES: return Backdrops.MENU_DARKAGES;
            case PIRATE_SEAS: return Backdrops.MENU_PIRATE;
            case WILD_WEST: return Backdrops.MENU_WEST;
            case FAR_FUTURE: return Backdrops.MENU_FUTURE;
            case FROSTBITE_CAVES:
            case LOST_CITY:
            default: return Backdrops.MENU_TUTORIAL;
        }
    }

    private Color worldAccent(WorldType world) {
        switch (world) {
            case ANCIENT_EGYPT: return new Color(1f, 0.85f, 0.35f, 1f);
            case FROSTBITE_CAVES: return new Color(0.6f, 0.85f, 1f, 1f);
            case BIG_WAVE_BEACH: return new Color(0.4f, 0.9f, 0.95f, 1f);
            case DARK_AGES: return new Color(0.75f, 0.6f, 0.95f, 1f);
            case PIRATE_SEAS: return new Color(0.85f, 0.7f, 0.45f, 1f);
            case WILD_WEST: return new Color(0.95f, 0.65f, 0.4f, 1f);
            case FAR_FUTURE: return new Color(0.6f, 0.95f, 0.8f, 1f);
            default: return new Color(0.9f, 0.9f, 0.9f, 1f);
        }
    }

    private String walletText() {
        return "Coins " + game.user().getCoins() + "   Gems " + game.user().getGems();
    }

    private static String pretty(String constant) {
        StringBuilder builder = new StringBuilder();
        for (String word : constant.split("_")) {
            if (word.isEmpty()) continue;
            if (builder.length() > 0) builder.append(' ');
            builder.append(Character.toUpperCase(word.charAt(0)))
                    .append(word.substring(1).toLowerCase());
        }
        return builder.toString();
    }

    private ClickListener click(final Runnable action) {
        return new ClickListener() {
            @Override public void clicked(InputEvent event, float x, float y) {
                action.run();
            }
        };
    }

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(0.06f, 0.11f, 0.08f, 1f);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        game.art().update();
        stage.act(delta);
        stage.draw();
    }

    @Override
    public void resize(int width, int height) {
        viewport.update(width, height, true);
    }

    @Override
    public void pause() {
    }

    @Override
    public void resume() {
    }

    @Override
    public void hide() {
        Gdx.input.setInputProcessor(null);
    }

    @Override
    public void dispose() {
        if (stage != null) stage.dispose();
    }
}
