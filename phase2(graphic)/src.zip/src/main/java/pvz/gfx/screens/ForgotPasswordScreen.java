package pvz.gfx.screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.ui.TextField;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import pvz.gfx.Layout;
import pvz.gfx.PvzGame;
import pvz.model.auth.User;

public class ForgotPasswordScreen implements Screen {

    private final PvzGame game;

    private Viewport viewport;
    private Stage stage;
    private Label message;
    private User pendingUser;

    public ForgotPasswordScreen(PvzGame game) {
        this.game = game;
    }

    @Override
    public void show() {
        viewport = new FitViewport(Layout.WORLD_W, Layout.WORLD_H);
        stage = new Stage(viewport, game.batch());
        Gdx.input.setInputProcessor(stage);

        message = new Label("", game.skin(), "default");
        message.setColor(1f, 0.7f, 0.4f, 1f);

        buildUsernameStep();
    }

    private void buildUsernameStep() {
        stage.clear();
        pendingUser = null;
        message.setText("");

        final TextField userField = new TextField("", game.skin());
        userField.setMessageText("username");

        Table root = new Table();
        root.setFillParent(true);
        root.pad(24f);
        stage.addActor(root);

        Label title = new Label("Forgot password", game.skin(), "big");
        Label subtitle = new Label("Enter your username to find your security question", game.skin(), "default");
        subtitle.setWrap(true);

        TextButton nextButton = new TextButton("Next", game.skin(), "green");
        nextButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                String username = userField.getText().trim();
                if (username.isEmpty()) {
                    message.setText("Enter your username.");
                    return;
                }
                User user = game.auth().findByUsername(username);
                if (user == null) {
                    message.setText("No account with that username.");
                    return;
                }
                String question = game.auth().securityQuestionFor(user);
                if (question == null) {
                    message.setText("No security question is on file for this account.");
                    return;
                }
                pendingUser = user;
                buildResetStep(question);
            }
        });

        TextButton backButton = new TextButton("Back to login", game.skin(), "brown");
        backButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                game.setScreen(new LoginScreen(game));
            }
        });

        root.add(title).padBottom(6f).row();
        root.add(subtitle).width(400f).padBottom(18f).row();
        root.add(userField).width(400f).height(44f).padBottom(12f).row();
        root.add(nextButton).width(400f).height(46f).padBottom(10f).row();
        root.add(backButton).width(400f).height(40f).padBottom(12f).row();
        root.add(message).width(400f).row();
    }

    private void buildResetStep(String question) {
        stage.clear();
        message.setText("");

        final TextField answerField = new TextField("", game.skin());
        answerField.setMessageText("answer");
        final TextField newPassField = new TextField("", game.skin());
        newPassField.setMessageText("new password (min 8 chars)");
        newPassField.setPasswordMode(true);
        newPassField.setPasswordCharacter('*');
        final TextField confirmPassField = new TextField("", game.skin());
        confirmPassField.setMessageText("confirm new password");
        confirmPassField.setPasswordMode(true);
        confirmPassField.setPasswordCharacter('*');

        Table root = new Table();
        root.setFillParent(true);
        root.pad(24f);
        stage.addActor(root);

        Label title = new Label("Forgot password", game.skin(), "big");
        Label questionLabel = new Label(question, game.skin(), "medium");
        questionLabel.setWrap(true);

        TextButton resetButton = new TextButton("Reset password", game.skin(), "green");
        resetButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                if (!game.auth().verifySecurityAnswer(pendingUser, answerField.getText())) {
                    message.setText("That answer doesn't match our records.");
                    return;
                }
                try {
                    game.auth().resetPassword(pendingUser, newPassField.getText(), confirmPassField.getText());
                    game.save();
                    game.setScreen(new LoginScreen(game));
                } catch (IllegalArgumentException ex) {
                    message.setText(ex.getMessage());
                }
            }
        });

        TextButton backButton = new TextButton("Back to login", game.skin(), "brown");
        backButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                game.setScreen(new LoginScreen(game));
            }
        });

        root.add(title).padBottom(6f).row();
        root.add(questionLabel).width(400f).padBottom(16f).row();
        root.add(answerField).width(400f).height(44f).padBottom(10f).row();
        root.add(newPassField).width(400f).height(44f).padBottom(10f).row();
        root.add(confirmPassField).width(400f).height(44f).padBottom(10f).row();
        root.add(resetButton).width(400f).height(46f).padBottom(10f).row();
        root.add(backButton).width(400f).height(40f).padBottom(12f).row();
        root.add(message).width(400f).row();
    }

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(0.10f, 0.16f, 0.10f, 1f);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        game.art().update();
        stage.act(delta);
        stage.draw();
    }

    @Override
    public void resize(int width, int height) {
        viewport.update(width, height, true);
    }

    @Override
    public void pause() {
    }

    @Override
    public void resume() {
    }

    @Override
    public void hide() {
        Gdx.input.setInputProcessor(null);
    }

    @Override
    public void dispose() {
        if (stage != null) stage.dispose();
    }
}
