package pvz.gfx.screens;

import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import pvz.gfx.PvzGame;
import pvz.gfx.actors.SeedCardActor;
import pvz.gfx.art.Backdrops;
import pvz.model.auth.User;
import pvz.model.enums.PlantType;
import pvz.model.greenhouse.Greenhouse;
import pvz.model.greenhouse.Pot;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class GreenhouseScreen extends PanelScreen {

    private static final int MARIGOLD_SELL_PRICE = 500;

    private final Random random = new Random();

    public GreenhouseScreen(PvzGame game) {
        super(game);
    }

    @Override
    protected String title() {
        return "Greenhouse";
    }

    @Override
    protected String[] backdrops() {
        return new String[]{Backdrops.GREEN};
    }

    @Override
    protected void build(Table body) {
        User user = game.user();
        if (user == null) return;
        final Greenhouse greenhouse = user.getGreenhouse();

        body.add(sectionLabel("Rows unlocked " + greenhouse.getUnlockedRows() + " / " + Greenhouse.ROWS
                + "     Pots in storage " + user.getPots())).left().padBottom(10f).row();

        Table grid = new Table();
        for (int y = 1; y <= Greenhouse.ROWS; y++) {
            for (int x = 1; x <= Greenhouse.COLUMNS; x++) {
                grid.add(cell(greenhouse, x, y)).size(190f, 210f).pad(6f);
            }
            grid.row();
        }
        body.add(grid).left().row();

        if (greenhouse.getUnlockedRows() < Greenhouse.ROWS) {
            final int cost = greenhouse.nextRowUnlockCost();
            body.add(button("Unlock next row  (" + cost + " coins)", new Runnable() {
                @Override
                public void run() {
                    unlockRow();
                }
            })).width(320f).left().padTop(12f).row();
        }
    }

    private Table cell(Greenhouse greenhouse, final int x, final int y) {
        Table cell = new Table();
        cell.add(new Label("(" + x + ", " + y + ")", game.skin(), "default")).row();

        if (!greenhouse.isRowUnlocked(y)) {
            Label locked = new Label("Locked row", game.skin(), "default");
            locked.setColor(0.7f, 0.7f, 0.7f, 1f);
            cell.add(locked).padTop(50f).row();
            return cell;
        }

        Pot pot = greenhouse.getPot(x, y);
        if (pot == null) {
            cell.add(button("Plant a pot", new Runnable() {
                @Override
                public void run() {
                    plantPot(x, y);
                }
            })).width(160f).padTop(50f).row();
            return cell;
        }

        SeedCardActor card = new SeedCardActor(game.art(), game.pam(), game.skin(),
                pot.getPlantType(), SeedCardActor.Mode.COLLECTION);
        cell.add(card).size(SeedCardActor.CARD_W, SeedCardActor.CARD_H).padTop(4f).row();

        if (pot.isReady()) {
            Label ready = new Label("Ready!", game.skin(), "default");
            ready.setColor(0.6f, 1f, 0.6f, 1f);
            cell.add(ready).row();
            cell.add(button("Collect", new Runnable() {
                @Override
                public void run() {
                    collect(x, y);
                }
            })).width(160f).padTop(4f).row();
        } else {
            cell.add(new Label(pot.remainingMinutes() + " min left", game.skin(), "default")).row();
            final int cost = pot.remainingHoursCeil();
            cell.add(button("Hurry  (" + cost + " gems)", new Runnable() {
                @Override
                public void run() {
                    grow(x, y);
                }
            })).width(160f).padTop(4f).row();
        }
        return cell;
    }

    private void plantPot(int x, int y) {
        User user = game.user();
        Greenhouse greenhouse = user.getGreenhouse();

        if (!greenhouse.isRowUnlocked(y)) {
            say("Row " + y + " is locked. Unlock it for " + greenhouse.nextRowUnlockCost() + " coins.");
            return;
        }
        if (greenhouse.isOccupied(x, y)) {
            say("There is already a pot at (" + x + ", " + y + ").");
            return;
        }
        if (!user.usePot()) {
            say("You have no pots. Zombies sometimes drop them, or buy one in the shop.");
            return;
        }

        List<PlantType> unlocked = new ArrayList<>();
        for (Map.Entry<PlantType, Boolean> entry : user.getCollection().getPlants().entrySet()) {
            if (Boolean.TRUE.equals(entry.getValue())) unlocked.add(entry.getKey());
        }
        PlantType plant = Greenhouse.rollPlant(unlocked, random);
        greenhouse.placePot(x, y, new Pot(plant, LocalDateTime.now()));

        say("A " + plant + " sprout is planted at (" + x + ", " + y + "). Ready in "
                + (plant == PlantType.MARIGOLD ? Pot.MARIGOLD_GROW_HOURS : Pot.OTHER_GROW_HOURS) + " hours.");
        game.save();
        refreshWallet();
        rebuild();
    }

    private void collect(int x, int y) {
        User user = game.user();
        Greenhouse greenhouse = user.getGreenhouse();
        Pot pot = greenhouse.getPot(x, y);
        if (pot == null) {
            say("There is no pot at (" + x + ", " + y + ").");
            return;
        }
        if (!pot.isReady()) {
            say("That plant needs " + pot.remainingMinutes() + " more minutes.");
            return;
        }

        greenhouse.removePot(x, y);
        if (pot.getPlantType() == PlantType.MARIGOLD) {
            user.addCoins(MARIGOLD_SELL_PRICE);
            say("You sold the Marigold for " + MARIGOLD_SELL_PRICE + " coins (now " + user.getCoins() + ").");
        } else {
            user.addStoredBoost(pot.getPlantType());
            say("You harvested a " + pot.getPlantType() + " boost! It is free in the next plant selection.");
        }
        game.save();
        refreshWallet();
        rebuild();
    }

    private void grow(int x, int y) {
        User user = game.user();
        Pot pot = user.getGreenhouse().getPot(x, y);
        if (pot == null) {
            say("There is no pot at (" + x + ", " + y + ").");
            return;
        }
        if (pot.isReady()) {
            say("That plant is already fully grown - collect it!");
            return;
        }

        int cost = pot.remainingHoursCeil();
        if (!user.spendGems(cost)) {
            say("Hurrying this plant costs " + cost + " gems (1 per remaining hour); you have "
                    + user.getGems() + ".");
            return;
        }
        pot.finishNow();
        say("You spent " + cost + " gems - the " + pot.getPlantType() + " is fully grown!");
        game.save();
        refreshWallet();
        rebuild();
    }

    private void unlockRow() {
        User user = game.user();
        Greenhouse greenhouse = user.getGreenhouse();
        if (greenhouse.getUnlockedRows() >= Greenhouse.ROWS) {
            say("All greenhouse rows are already unlocked.");
            return;
        }
        int cost = greenhouse.nextRowUnlockCost();
        if (!user.spendCoins(cost)) {
            say("Unlocking the next row costs " + cost + " coins; you have " + user.getCoins() + ".");
            return;
        }
        greenhouse.unlockNextRow();
        say("Row " + greenhouse.getUnlockedRows() + " unlocked for " + cost + " coins!");
        game.save();
        refreshWallet();
        rebuild();
    }
}
