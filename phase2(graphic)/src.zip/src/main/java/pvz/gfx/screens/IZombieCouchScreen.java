package pvz.gfx.screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import pvz.gfx.Layout;
import pvz.gfx.PvzGame;
import pvz.gfx.art.Backdrops;
import pvz.model.enums.MiniGameType;
import pvz.model.enums.PlantType;
import pvz.model.enums.ZombieType;
import pvz.model.minigame.IZombie;
import pvz.network.ReactionCatalog;

public class IZombieCouchScreen extends MiniGameScreen {

    private final IZombie izombie;
    private int zombieSelected = 0;
    private int zombieLaneCursor = 1;
    private boolean plantShooterMode = true;

    private Label reactionLabel;
    private String activeReactionKind;
    private int activeReactionId;
    private float reactionTimer;

    public IZombieCouchScreen(PvzGame game, int level) {
        this(game, level, new IZombie(level, true));
    }

    private IZombieCouchScreen(PvzGame game, int level, IZombie izombie) {
        super(game, MiniGameType.I_ZOMBIE, level, izombie);
        this.izombie = izombie;
    }

    @Override
    public void show() {
        super.show();
        reactionLabel = new Label("", game.skin(), "big");
        reactionLabel.setVisible(false);
        stage.addActor(reactionLabel);
    }

    @Override
    protected String gameTitle() {
        return "I, Zombie - Couch Play (2P)";
    }

    @Override
    protected String statusLine() {
        int remaining = Math.max(0, izombie.getMatchDurationSeconds() - izombie.getSecondsElapsed());
        String holding = izombie.getRosterSize() > 0 ? izombie.getRosterType(zombieSelected).toString() : "-";
        return "Zombie(kbd): sun " + izombie.getSun() + " horde " + izombie.getZombiesPlaced() + "/" + izombie.getMaxZombies()
                + " holding " + holding + " @ lane " + zombieLaneCursor
                + "     Plant(mouse): sun " + izombie.getPlantSun() + " placing " + (plantShooterMode ? "Shooter" : "Wall-nut")
                + "     Time left " + remaining + "s";
    }

    @Override
    protected float tickInterval() {
        return 1f;
    }

    @Override
    protected String[] backdrops() {
        return new String[]{Backdrops.LAWN_CENTER, Backdrops.EGYPT_CENTER};
    }

    private void pollZombieKeys() {
        if (izombie.isGameover()) return;
        int size = izombie.getRosterSize();
        if (size > 0 && Gdx.input.isKeyJustPressed(Input.Keys.NUM_1)) zombieSelected = 0;
        if (size > 1 && Gdx.input.isKeyJustPressed(Input.Keys.NUM_2)) zombieSelected = 1;
        if (size > 2 && Gdx.input.isKeyJustPressed(Input.Keys.NUM_3)) zombieSelected = 2;
        if (size > 3 && Gdx.input.isKeyJustPressed(Input.Keys.NUM_4)) zombieSelected = 3;
        if (size > 4 && Gdx.input.isKeyJustPressed(Input.Keys.NUM_5)) zombieSelected = 4;
        if (Gdx.input.isKeyJustPressed(Input.Keys.UP) || Gdx.input.isKeyJustPressed(Input.Keys.W)) {
            zombieLaneCursor = Math.max(1, zombieLaneCursor - 1);
        }
        if (Gdx.input.isKeyJustPressed(Input.Keys.DOWN) || Gdx.input.isKeyJustPressed(Input.Keys.S)) {
            zombieLaneCursor = Math.min(ROWS, zombieLaneCursor + 1);
        }
        if (Gdx.input.isKeyJustPressed(Input.Keys.SPACE) || Gdx.input.isKeyJustPressed(Input.Keys.ENTER)) {
            izombie.placeByRosterIndex(zombieSelected, zombieLaneCursor);
        }
    }

    private void triggerReaction(String kind, int id) {
        activeReactionKind = kind;
        activeReactionId = id;
        reactionTimer = ReactionCatalog.KIND_STICKER.equals(kind) ? 4f : 2.5f;
    }

    private void updateReaction(float delta) {
        if (reactionLabel == null) return;
        if (reactionTimer > 0f) {
            reactionTimer -= delta;
            String text;
            if (ReactionCatalog.KIND_TEXT.equals(activeReactionKind)) {
                text = ReactionCatalog.textFor(activeReactionId);
            } else if (ReactionCatalog.KIND_EMOJI.equals(activeReactionKind)) {
                text = ReactionCatalog.emojiGlyphFor(activeReactionId);
            } else {
                text = ReactionCatalog.stickerLabelFor(activeReactionId) + " " + ReactionCatalog.emojiGlyphFor(activeReactionId);
            }
            reactionLabel.setText(text);
            float bounce = (float) Math.sin(reactionTimer * 8f) * 10f;
            reactionLabel.setPosition(Layout.WORLD_W - 300f, Layout.WORLD_H - 90f + bounce);
            reactionLabel.setVisible(true);
        } else {
            reactionLabel.setVisible(false);
        }
    }

    @Override
    protected void drawBoard(float delta) {
        pollZombieKeys();
        updateReaction(delta);

        SpriteBatch batch = game.batch();
        drawGrid(batch);

        for (int col = 1; col <= COLS; col++) {
            fill(batch, cellX(col), cellY(zombieLaneCursor), CELL_W - 2f, CELL_H - 2f, 0.9f, 0.2f, 0.2f, 0.18f);
        }

        for (int lane = 1; lane <= ROWS; lane++) {
            if (izombie.isBrainEaten(lane)) continue;
            float x = BOARD_X - 84f;
            float y = cellY(lane) + 14f;
            if (game.art().region(Backdrops.BRAIN) != null) {
                drawRegion(batch, Backdrops.BRAIN, x, y, 78f, 66f);
            } else {
                fill(batch, x, y, 78f, 66f, 0.85f, 0.5f, 0.6f, 1f);
            }
        }

        PlantType shooter = PvzGame.byName("PEASHOOTER");
        PlantType nut = PvzGame.byName("WALL_NUT");
        for (int[] plant : izombie.getPlantView()) {
            float x = cellCenterX(plant[1]);
            float y = cellY(plant[0]) + 6f;
            drawPlant(batch, plant[3] > 0 ? shooter : nut, x, y, PLANT_HEIGHT);
        }

        for (int[] zombie : izombie.getZombieView()) {
            float x = smoothX(zombie[1]);
            float y = cellY(zombie[0]) + 6f;
            int rosterIndex = zombie[4];

            if (rosterIndex == izombie.getSunProducerMarker()) {
                drawZombie(batch, BowlingScreen.zombieByName("BASIC", "NORMAL"), x, y, ZOMBIE_HEIGHT * 0.9f);
                drawRegion(batch, Backdrops.SUN, x - 18f, y + ZOMBIE_HEIGHT, 36f, 36f);
            } else if (rosterIndex >= 0 && rosterIndex < izombie.getRosterSize()) {
                drawZombie(batch, izombie.getRosterType(rosterIndex), x, y, ZOMBIE_HEIGHT);
            } else {
                drawZombie(batch, BowlingScreen.zombieByName("BASIC", "NORMAL"), x, y, ZOMBIE_HEIGHT);
            }
        }

        int size = izombie.getRosterSize();
        for (int i = 0; i < size; i++) {
            float x = 60f + i * 108f;
            float y = 560f;
            boolean holding = (i == zombieSelected);
            boolean affordable = izombie.getSun() >= izombie.getRosterCost(i);
            fill(batch, x - 4f, y - 4f, 104f, 128f,
                    holding ? 1f : 0f, holding ? 0.9f : 0f, holding ? 0.4f : 0f,
                    holding ? 0.55f : 0.35f);
            if (!affordable) fill(batch, x - 4f, y - 4f, 104f, 128f, 0f, 0f, 0f, 0.45f);
            drawZombie(batch, izombie.getRosterType(i), x + 48f, y + 8f, 104f);
        }

        drawRegion(batch, Backdrops.SUN, 1180f, 660f, 48f, 48f);
    }

    @Override
    protected void buildControls(Table controls) {
        int size = izombie.getRosterSize();
        for (int i = 0; i < size; i++) {
            final int index = i;
            clickZone(60f + i * 108f, 560f, 100f, 124f, new Runnable() {
                @Override
                public void run() {
                    zombieSelected = index;
                }
            });
            caption(izombie.getRosterType(i) + "  " + izombie.getRosterCost(i), 36f + i * 108f, 536f, 148f);
        }

        for (int lane = 1; lane <= ROWS; lane++) {
            for (int col = 1; col <= COLS; col++) {
                final int fLane = lane;
                final int fCol = col;
                clickZone(cellX(col), cellY(lane), CELL_W - 2f, CELL_H - 2f, new Runnable() {
                    @Override
                    public void run() {
                        izombie.plantDefender(fLane, fCol, plantShooterMode);
                    }
                });
            }
        }

        Table row1 = new Table();
        row1.add(new Label("Zombie player: 1-5 pick zombie, W/S or Up/Down pick lane, Space to release.",
                game.skin(), "default")).left().row();
        controls.add(row1).left().row();

        Table row2 = new Table();
        row2.add(controlButton("Plant: Shooter", "green_small", new Runnable() {
            @Override
            public void run() {
                plantShooterMode = true;
            }
        })).padRight(6f);
        row2.add(controlButton("Plant: Wall-nut", "green_small", new Runnable() {
            @Override
            public void run() {
                plantShooterMode = false;
            }
        })).padRight(6f);
        row2.add(new Label("Plant player: click a lawn cell with the mouse to place.",
                game.skin(), "default")).padLeft(10f);
        controls.add(row2).left().padTop(4f).row();

        Table reactions = new Table();
        reactions.add(new Label("Reactions:", game.skin(), "default")).padRight(8f);
        reactions.add(controlButton(ReactionCatalog.TEXT_1, "purple", new Runnable() {
            @Override public void run() { triggerReaction(ReactionCatalog.KIND_TEXT, 1); }
        })).padRight(4f);
        reactions.add(controlButton(ReactionCatalog.TEXT_2, "purple", new Runnable() {
            @Override public void run() { triggerReaction(ReactionCatalog.KIND_TEXT, 2); }
        })).padRight(4f);
        reactions.add(controlButton(ReactionCatalog.TEXT_3, "purple", new Runnable() {
            @Override public void run() { triggerReaction(ReactionCatalog.KIND_TEXT, 3); }
        })).padRight(10f);
        reactions.add(controlButton(ReactionCatalog.EMOJI_1_GLYPH, "purple", new Runnable() {
            @Override public void run() { triggerReaction(ReactionCatalog.KIND_EMOJI, 1); }
        })).padRight(4f);
        reactions.add(controlButton(ReactionCatalog.EMOJI_2_GLYPH, "purple", new Runnable() {
            @Override public void run() { triggerReaction(ReactionCatalog.KIND_EMOJI, 2); }
        })).padRight(4f);
        reactions.add(controlButton(ReactionCatalog.EMOJI_3_GLYPH, "purple", new Runnable() {
            @Override public void run() { triggerReaction(ReactionCatalog.KIND_EMOJI, 3); }
        })).padRight(10f);
        reactions.add(controlButton(ReactionCatalog.STICKER_1_LABEL, "green_small", new Runnable() {
            @Override public void run() { triggerReaction(ReactionCatalog.KIND_STICKER, 1); }
        })).padRight(4f);
        reactions.add(controlButton(ReactionCatalog.STICKER_2_LABEL, "green_small", new Runnable() {
            @Override public void run() { triggerReaction(ReactionCatalog.KIND_STICKER, 2); }
        })).padRight(4f);
        reactions.add(controlButton(ReactionCatalog.STICKER_3_LABEL, "green_small", new Runnable() {
            @Override public void run() { triggerReaction(ReactionCatalog.KIND_STICKER, 3); }
        }));
        controls.add(reactions).left().padTop(6f).row();
    }
}
