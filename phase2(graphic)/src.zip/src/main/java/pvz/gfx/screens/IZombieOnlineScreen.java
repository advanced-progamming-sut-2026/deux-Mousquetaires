package pvz.gfx.screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.utils.viewport.FitViewport;
import pvz.gfx.Layout;
import pvz.gfx.PvzGame;
import pvz.gfx.art.Backdrops;
import pvz.model.enums.PlantType;
import pvz.model.enums.ZombieType;
import pvz.model.minigame.IZombie;
import pvz.network.GameClient;
import pvz.network.NetProtocol;
import pvz.network.ReactionCatalog;

import java.util.ArrayList;
import java.util.List;

public class IZombieOnlineScreen implements Screen {

    private static final int ROWS = 5;
    private static final int COLS = 9;
    private static final float BOARD_X = 210f;
    private static final float BOARD_Y = 140f;
    private static final float CELL_W = 106f;
    private static final float CELL_H = 96f;
    private static final float PLANT_HEIGHT = 86f;
    private static final float ZOMBIE_HEIGHT = 108f;

    private final PvzGame game;
    private final int level;
    private final String role;
    private final String opponentName;
    private final IZombie rosterPreview;
    private final GameClient client;

    private Stage stage;
    private Label statsLabel;
    private Label reactionLabel;
    private Table controls;

    private int sun, plantSun, secondsElapsed, matchDuration, zombiesPlaced, maxZombies;
    private boolean[] brainEaten = new boolean[ROWS + 1];
    private List<int[]> plants = new ArrayList<>();
    private List<int[]> zombies = new ArrayList<>();
    private int zombieSelected = 0;
    private boolean plantShooterMode = true;
    private boolean ended;

    private String activeReactionKind;
    private int activeReactionId;
    private float reactionTimer;

    private final GameClient.Listener listener = new GameClient.Listener() {
        @Override
        public void onMessage(final String type, final String[] fields) {
            Gdx.app.postRunnable(new Runnable() {
                @Override
                public void run() {
                    handleMessage(type, fields);
                }
            });
        }

        @Override
        public void onDisconnected() {
            Gdx.app.postRunnable(new Runnable() {
                @Override
                public void run() {
                    if (statsLabel != null) statsLabel.setText("Disconnected from server.");
                }
            });
        }
    };

    public IZombieOnlineScreen(PvzGame game, int level, String role, String opponentName) {
        this.game = game;
        this.level = level;
        this.role = role;
        this.opponentName = opponentName;
        this.rosterPreview = new IZombie(level);
        this.client = game.netClient();
    }

    @Override
    public void show() {
        stage = new Stage(new FitViewport(Layout.WORLD_W, Layout.WORLD_H), game.batch());
        Gdx.input.setInputProcessor(stage);
        client.addListener(listener);

        statsLabel = new Label("", game.skin(), "medium");
        statsLabel.setBounds(24f, Layout.WORLD_H - 52f, 1100f, 32f);
        stage.addActor(statsLabel);

        reactionLabel = new Label("", game.skin(), "big");
        reactionLabel.setVisible(false);
        stage.addActor(reactionLabel);

        controls = new Table();
        controls.setFillParent(true);
        controls.bottom().left();
        controls.pad(12f);
        stage.addActor(controls);

        rebuildControls();
    }

    private void handleMessage(String type, String[] f) {
        if (NetProtocol.S2C_MATCH_STATE.equals(type)) {
            sun = parseIntSafe(NetProtocol.field(f, 0));
            plantSun = parseIntSafe(NetProtocol.field(f, 1));
            secondsElapsed = parseIntSafe(NetProtocol.field(f, 2));
            matchDuration = parseIntSafe(NetProtocol.field(f, 3));
            zombiesPlaced = parseIntSafe(NetProtocol.field(f, 4));
            maxZombies = parseIntSafe(NetProtocol.field(f, 5));
            String brains = NetProtocol.field(f, 6);
            for (int lane = 1; lane <= ROWS && lane <= brains.length(); lane++) {
                brainEaten[lane] = brains.charAt(lane - 1) == '1';
            }
            plants = GameClient.parseEntities(NetProtocol.field(f, 7), 4);
            zombies = GameClient.parseEntities(NetProtocol.field(f, 8), 5);
        } else if (NetProtocol.S2C_MATCH_END.equals(type)) {
            ended = true;
            String result = NetProtocol.field(f, 0);
            statsLabel.setText("Match over - you " + result + ". Use Back to mini-games to return.");
            rebuildControls();
        } else if (NetProtocol.S2C_REACTION_RECEIVE.equals(type)) {
            activeReactionKind = NetProtocol.field(f, 0);
            activeReactionId = parseIntSafe(NetProtocol.field(f, 1));
            reactionTimer = ReactionCatalog.KIND_STICKER.equals(activeReactionKind) ? 4f : 2.5f;
        }
    }

    private static int parseIntSafe(String s) {
        try {
            return Integer.parseInt(s);
        } catch (Exception e) {
            return 0;
        }
    }

    private void rebuildControls() {
        controls.clear();

        Table reactions = new Table();
        reactions.add(new Label("Reactions:", game.skin(), "default")).padRight(8f);
        addReactionButton(reactions, ReactionCatalog.TEXT_1, ReactionCatalog.KIND_TEXT, 1);
        addReactionButton(reactions, ReactionCatalog.TEXT_2, ReactionCatalog.KIND_TEXT, 2);
        addReactionButton(reactions, ReactionCatalog.TEXT_3, ReactionCatalog.KIND_TEXT, 3);
        addReactionButton(reactions, ReactionCatalog.EMOJI_1_GLYPH, ReactionCatalog.KIND_EMOJI, 1);
        addReactionButton(reactions, ReactionCatalog.EMOJI_2_GLYPH, ReactionCatalog.KIND_EMOJI, 2);
        addReactionButton(reactions, ReactionCatalog.EMOJI_3_GLYPH, ReactionCatalog.KIND_EMOJI, 3);
        addReactionButton(reactions, ReactionCatalog.STICKER_1_LABEL, ReactionCatalog.KIND_STICKER, 1);
        addReactionButton(reactions, ReactionCatalog.STICKER_2_LABEL, ReactionCatalog.KIND_STICKER, 2);
        addReactionButton(reactions, ReactionCatalog.STICKER_3_LABEL, ReactionCatalog.KIND_STICKER, 3);
        controls.add(reactions).left().row();

        if (!ended && "ZOMBIE".equals(role)) {
            Table roster = new Table();
            int size = rosterPreview.getRosterSize();
            for (int i = 0; i < size; i++) {
                final int index = i;
                TextButton button = new TextButton(rosterPreview.getRosterType(i) + " " + rosterPreview.getRosterCost(i),
                        game.skin(), i == zombieSelected ? "green" : "green_small");
                button.addListener(new ClickListener() {
                    @Override
                    public void clicked(InputEvent event, float x, float y) {
                        zombieSelected = index;
                        rebuildControls();
                    }
                });
                roster.add(button).padRight(6f);
            }
            controls.add(roster).left().padTop(6f).row();
            controls.add(new Label("Click a lane on the lawn to release the selected zombie.",
                    game.skin(), "default")).left().padTop(4f).row();
            addBoardClickZones(true);
        } else if (!ended && "PLANT".equals(role)) {
            Table plantModes = new Table();
            TextButton shooterBtn = new TextButton("Shooter", game.skin(), plantShooterMode ? "green" : "green_small");
            shooterBtn.addListener(new ClickListener() {
                @Override
                public void clicked(InputEvent event, float x, float y) {
                    plantShooterMode = true;
                    rebuildControls();
                }
            });
            TextButton wallBtn = new TextButton("Wall-nut", game.skin(), !plantShooterMode ? "green" : "green_small");
            wallBtn.addListener(new ClickListener() {
                @Override
                public void clicked(InputEvent event, float x, float y) {
                    plantShooterMode = false;
                    rebuildControls();
                }
            });
            plantModes.add(shooterBtn).padRight(6f);
            plantModes.add(wallBtn).padRight(6f);
            controls.add(plantModes).left().padTop(6f).row();
            controls.add(new Label("Click a lawn cell to plant your defender there.",
                    game.skin(), "default")).left().padTop(4f).row();
            addBoardClickZones(false);
        }

        TextButton leave = new TextButton("Back to mini-games", game.skin(), "brown");
        leave.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                client.quitMatch();
                game.setScreen(new MiniGameHubScreen(game));
            }
        });
        controls.add(leave).left().width(240f).padTop(10f).row();
    }

    private void addReactionButton(Table row, String label, final String kind, final int id) {
        TextButton button = new TextButton(label, game.skin(), "purple");
        button.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                client.sendReaction(kind, id);
            }
        });
        row.add(button).padRight(4f);
    }

    private void addBoardClickZones(final boolean zombieRole) {
        for (int lane = 1; lane <= ROWS; lane++) {
            for (int col = 1; col <= COLS; col++) {
                final int fLane = lane;
                final int fCol = col;
                Actor zone = new Actor();
                zone.setBounds(cellX(col), cellY(lane), CELL_W - 2f, CELL_H - 2f);
                zone.addListener(new ClickListener() {
                    @Override
                    public void clicked(InputEvent event, float x, float y) {
                        if (zombieRole) client.sendZombieInput(zombieSelected, fLane);
                        else client.sendPlantInput(fLane, fCol, plantShooterMode);
                    }
                });
                stage.addActor(zone);
            }
        }
    }

    private float cellX(int col) {
        return BOARD_X + (col - 1) * CELL_W;
    }

    private float cellY(int row) {
        return BOARD_Y + (ROWS - row) * CELL_H;
    }

    private float cellCenterX(int col) {
        return BOARD_X + (col - 0.5f) * CELL_W;
    }

    private float smoothX(int columnTimesTen) {
        return BOARD_X + (columnTimesTen / 10f - 0.5f) * CELL_W;
    }

    private void fill(SpriteBatch batch, float x, float y, float w, float h, float r, float g, float b, float a) {
        TextureRegion pixel = game.art().pixel();
        if (pixel == null) return;
        batch.setColor(r, g, b, a);
        batch.draw(pixel, x, y, w, h);
        batch.setColor(1f, 1f, 1f, 1f);
    }

    private void drawRegion(SpriteBatch batch, String id, float x, float y, float w, float h) {
        TextureRegion region = game.art().region(id);
        if (region != null) batch.draw(region, x, y, w, h);
    }

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(0.08f, 0.16f, 0.09f, 1f);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        game.art().update();

        updateReaction(delta);

        SpriteBatch batch = game.batch();
        batch.setProjectionMatrix(stage.getViewport().getCamera().combined);
        batch.begin();

        boolean drawn = Backdrops.drawCover(batch, game.art(), 0f, 0f, Layout.WORLD_W, Layout.WORLD_H,
                Backdrops.LAWN_CENTER, Backdrops.LAWN_LEFT, Backdrops.LAWN_RIGHT);
        if (!drawn) fill(batch, 0f, 0f, Layout.WORLD_W, Layout.WORLD_H, 0.16f, 0.36f, 0.16f, 1f);

        for (int row = 1; row <= ROWS; row++) {
            for (int col = 1; col <= COLS; col++) {
                float shade = ((row + col) % 2 == 0) ? 0.16f : 0.10f;
                fill(batch, cellX(col), cellY(row), CELL_W - 2f, CELL_H - 2f, 0f, shade, 0f, 0.35f);
            }
        }

        for (int lane = 1; lane <= ROWS; lane++) {
            if (brainEaten[lane]) continue;
            float x = BOARD_X - 84f;
            float y = cellY(lane) + 14f;
            if (game.art().region(Backdrops.BRAIN) != null) drawRegion(batch, Backdrops.BRAIN, x, y, 78f, 66f);
            else fill(batch, x, y, 78f, 66f, 0.85f, 0.5f, 0.6f, 1f);
        }

        PlantType shooterType = PvzGame.byName("PEASHOOTER");
        PlantType nutType = PvzGame.byName("WALL_NUT");
        for (int[] plant : plants) {
            float x = cellCenterX(plant[1]);
            float y = cellY(plant[0]) + 6f;
            PlantType pt = plant[3] > 0 ? shooterType : nutType;
            String pam = game.pam().plantPam(pt);
            String clip = game.pam().plantClip(pt, pvz.gfx.art.PamCatalog.Clip.IDLE);
            if (!game.art().drawFitted(batch, pam, clip, 0f, x, y, PLANT_HEIGHT, true, null)) {
                fill(batch, x - 30f, y, 60f, PLANT_HEIGHT, 0.2f, 0.8f, 0.2f, 1f);
            }
        }

        for (int[] zombie : zombies) {
            float x = smoothX(zombie[1]);
            float y = cellY(zombie[0]) + 6f;
            int rosterIndex = zombie[4];
            ZombieType zt;
            if (rosterIndex >= 0 && rosterIndex < rosterPreview.getRosterSize()) zt = rosterPreview.getRosterType(rosterIndex);
            else zt = BowlingScreen.zombieByName("BASIC", "NORMAL");
            if (pvz.gfx.art.CompositeZombies.isComposite(zt)) {
                pvz.gfx.art.CompositeZombies.draw(game.art(), game.pam(), batch, zt,
                        game.pam().zombieClip(zt, pvz.gfx.art.PamCatalog.Clip.WALK), 0f, x, y, ZOMBIE_HEIGHT);
            } else {
                String pam = game.pam().zombiePam(zt);
                String clip = game.pam().zombieClip(zt, pvz.gfx.art.PamCatalog.Clip.WALK);
                if (!game.art().drawFitted(batch, pam, clip, 0f, x, y, ZOMBIE_HEIGHT, true, null)) {
                    fill(batch, x - 30f, y, 60f, ZOMBIE_HEIGHT, 0.6f, 0.2f, 0.2f, 1f);
                }
            }
        }

        drawRegion(batch, Backdrops.SUN, 1180f, 660f, 48f, 48f);
        batch.end();

        int remaining = Math.max(0, matchDuration - secondsElapsed);
        String roleLabel = "ZOMBIE".equals(role) ? "Zombie side" : "Plant side";
        statsLabel.setText("I, Zombie Online vs " + opponentName + "   You are: " + roleLabel
                + "   Zombie sun " + sun + " horde " + zombiesPlaced + "/" + maxZombies
                + "   Plant sun " + plantSun + "   Time left " + remaining + "s");

        stage.act(delta);
        stage.draw();
    }

    private void updateReaction(float delta) {
        if (reactionLabel == null) return;
        if (reactionTimer > 0f) {
            reactionTimer -= delta;
            String text;
            if (ReactionCatalog.KIND_TEXT.equals(activeReactionKind)) text = ReactionCatalog.textFor(activeReactionId);
            else if (ReactionCatalog.KIND_EMOJI.equals(activeReactionKind)) text = ReactionCatalog.emojiGlyphFor(activeReactionId);
            else text = ReactionCatalog.stickerLabelFor(activeReactionId) + " " + ReactionCatalog.emojiGlyphFor(activeReactionId);
            reactionLabel.setText(text);
            float bounce = (float) Math.sin(reactionTimer * 8f) * 10f;
            reactionLabel.setPosition(Layout.WORLD_W - 300f, Layout.WORLD_H - 90f + bounce);
            reactionLabel.setVisible(true);
        } else {
            reactionLabel.setVisible(false);
        }
    }

    @Override
    public void resize(int width, int height) {
        stage.getViewport().update(width, height, true);
    }

    @Override
    public void pause() {
    }

    @Override
    public void resume() {
    }

    @Override
    public void hide() {
        client.removeListener(listener);
        Gdx.input.setInputProcessor(null);
    }

    @Override
    public void dispose() {
        if (stage != null) stage.dispose();
    }
}
