package pvz.gfx.screens;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import pvz.gfx.PvzGame;
import pvz.gfx.art.Backdrops;
import pvz.model.enums.MiniGameType;
import pvz.model.enums.PlantType;
import pvz.model.enums.ZombieType;
import pvz.model.minigame.IZombie;

import java.util.List;

public class IZombieScreen extends MiniGameScreen {

    private final IZombie izombie;
    private int selected = 0;

    public IZombieScreen(PvzGame game, int level) {
        this(game, level, new IZombie(level));
    }

    private IZombieScreen(PvzGame game, int level, IZombie izombie) {
        super(game, MiniGameType.I_ZOMBIE, level, izombie);
        this.izombie = izombie;
    }

    @Override
    protected String gameTitle() {
        return "I, Zombie";
    }

    @Override
    protected String statusLine() {
        ZombieType type = izombie.getRosterType(selected);
        return "Sun " + izombie.getSun()
                + "     Horde " + izombie.getZombiesPlaced() + " / " + izombie.getMaxZombies()
                + "     Holding " + type + " (" + izombie.getRosterCost(selected) + ")";
    }

    @Override
    protected float tickInterval() {
        return 1f;
    }

    @Override
    protected String[] backdrops() {
        return new String[]{Backdrops.LAWN_CENTER, Backdrops.EGYPT_CENTER};
    }

    @Override
    protected void drawBoard(float delta) {
        SpriteBatch batch = game.batch();
        drawGrid(batch);

        for (int lane = 1; lane <= ROWS; lane++) {
            if (izombie.isBrainEaten(lane)) continue;
            float x = BOARD_X - 84f;
            float y = cellY(lane) + 14f;
            if (game.art().region(Backdrops.BRAIN) != null) {
                drawRegion(batch, Backdrops.BRAIN, x, y, 78f, 66f);
            } else {
                fill(batch, x, y, 78f, 66f, 0.85f, 0.5f, 0.6f, 1f);
            }
        }

        PlantType shooter = PvzGame.byName("PEASHOOTER");
        PlantType nut = PvzGame.byName("WALL_NUT");
        for (int[] plant : izombie.getPlantView()) {
            float x = cellCenterX(plant[1]);
            float y = cellY(plant[0]) + 6f;
            drawPlant(batch, plant[3] > 0 ? shooter : nut, x, y, PLANT_HEIGHT);
        }

        for (int[] zombie : izombie.getZombieView()) {
            float x = smoothX(zombie[1]);
            float y = cellY(zombie[0]) + 6f;
            int rosterIndex = zombie[4];

            if (rosterIndex == izombie.getSunProducerMarker()) {
                drawZombie(batch, BowlingScreen.zombieByName("BASIC", "NORMAL"), x, y, ZOMBIE_HEIGHT * 0.9f);
                drawRegion(batch, Backdrops.SUN, x - 18f, y + ZOMBIE_HEIGHT, 36f, 36f);
            } else if (rosterIndex >= 0 && rosterIndex < izombie.getRosterSize()) {
                drawZombie(batch, izombie.getRosterType(rosterIndex), x, y, ZOMBIE_HEIGHT);
            } else {
                drawZombie(batch, BowlingScreen.zombieByName("BASIC", "NORMAL"), x, y, ZOMBIE_HEIGHT);
            }
        }

        int size = izombie.getRosterSize();
        for (int i = 0; i < size; i++) {
            float x = 60f + i * 108f;
            float y = 560f;
            boolean holding = (i == selected);
            boolean affordable = izombie.getSun() >= izombie.getRosterCost(i);
            fill(batch, x - 4f, y - 4f, 104f, 128f,
                    holding ? 1f : 0f, holding ? 0.9f : 0f, holding ? 0.4f : 0f,
                    holding ? 0.55f : 0.35f);
            if (!affordable) fill(batch, x - 4f, y - 4f, 104f, 128f, 0f, 0f, 0f, 0.45f);
            drawZombie(batch, izombie.getRosterType(i), x + 48f, y + 8f, 104f);
        }

        drawRegion(batch, Backdrops.SUN, Layout_SUN_X, 660f, 48f, 48f);
    }

    private static final float Layout_SUN_X = 1180f;

    @Override
    protected void buildControls(Table controls) {

        for (int lane = 1; lane <= ROWS; lane++) {
            final int laneIndex = lane;
            clickZone(BOARD_X, cellY(lane), COLS * CELL_W, CELL_H, new Runnable() {
                @Override
                public void run() {
                    send("place " + izombie.getRosterType(selected).name() + " " + laneIndex);
                }
            });
        }

        int size = izombie.getRosterSize();
        for (int i = 0; i < size; i++) {
            final int index = i;
            clickZone(60f + i * 108f, 560f, 100f, 124f, new Runnable() {
                @Override
                public void run() {
                    selected = index;
                    refresh();
                }
            });
            caption(izombie.getRosterType(i) + "  " + izombie.getRosterCost(i),
                    36f + i * 108f, 536f, 148f);
        }

        Table roster = new Table();
        for (int i = 0; i < size; i++) {
            final int index = i;
            roster.add(controlButton(izombie.getRosterType(i).name() + "  " + izombie.getRosterCost(i),
                    "green_small", new Runnable() {
                        @Override
                        public void run() {
                            selected = index;
                            refresh();
                        }
                    })).padRight(6f);
        }
        controls.add(roster).left().row();
        controls.add(new Label("Pick a zombie, then click the lane you want to send it down.",
                game.skin(), "default")).left().padTop(6f);
    }
}
