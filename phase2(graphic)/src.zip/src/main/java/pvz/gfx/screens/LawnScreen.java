package pvz.gfx.screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.InputAdapter;
import com.badlogic.gdx.InputMultiplexer;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.Align;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import pvz.gfx.Layout;
import pvz.gfx.PvzGame;
import pvz.gfx.actors.SeedCardActor;
import pvz.gfx.art.Backdrops;
import pvz.gfx.art.CompositeZombies;
import pvz.gfx.art.PamCatalog;
import pvz.gfx.fx.ProjectileFx;
import pvz.model.entity.plant.PlantCatalog;
import pvz.model.enums.LevelType;
import pvz.model.enums.PlantType;
import pvz.model.enums.SunType;
import pvz.model.enums.TerrainType;
import pvz.model.enums.WorldType;
import pvz.model.enums.ZombieType;
import pvz.model.session.ActiveZombie;
import pvz.model.session.FallingSun;
import pvz.model.session.GameSession;
import pvz.model.session.LevelSpec;
import pvz.model.session.PlantedUnit;

import pvz.gfx.audio.SfxManager;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class LawnScreen implements Screen {


    private final SfxManager zombieSfx = new SfxManager();


    private static final float SECONDS_PER_TICK = 1f / GameSession.TICKS_PER_SECOND;
    private static final int MAX_TICKS_PER_FRAME = 40;

    private static final float PLANT_HEIGHT = 92f;
    private static final float ZOMBIE_HEIGHT = 118f;

    private static final float SUN_PICK_RADIUS = 42f;
    private static final float ANNOUNCE_SECONDS = 2.6f;

    private static final Color GRASS_LIGHT = new Color(0.42f, 0.66f, 0.24f, 1f);
    private static final Color GRASS_DARK = new Color(0.36f, 0.59f, 0.20f, 1f);
    private static final Color SKY = new Color(0.20f, 0.34f, 0.46f, 1f);
    private static final Color HIGHLIGHT = new Color(1f, 1f, 1f, 0.18f);
    private static final Color GRID_LINE = new Color(0f, 0f, 0f, 0.22f);
    private static final Color SUN_NORMAL = new Color(1f, 0.90f, 0.25f, 1f);
    private static final Color SUN_SPECIAL = new Color(1f, 0.76f, 0.10f, 1f);
    private static final Color SUN_RADIOACTIVE = new Color(0.72f, 0.40f, 0.95f, 1f);
    private static final Color FROZEN_TINT = new Color(0.62f, 0.84f, 1f, 1f);
    private static final Color SLOWED_TINT = new Color(0.80f, 0.88f, 1f, 1f);
    private static final Color NECRO_TINT = new Color(0.72f, 0.52f, 0.92f, 1f);

    private final PvzGame game;
    private final LevelSpec spec;
    private final List<PlantType> chosenPlants;

    private GameSession session;
    private ProjectileFx projectiles;

    private Viewport viewport;
    private Stage stage;

    private Label sunLabel;
    private Label plantFoodLabel;
    private Label announceLabel;
    private ImageButton shovelButton;
    private ImageButton pauseButton;

    private Table pauseOverlay;
    private Table endOverlay;

    private final List<SeedCardActor> seedCards = new ArrayList<>();

    private float tickAccumulator;
    private float animTime;
    private float announceTimer;

    private boolean paused;
    private boolean ended;
    private boolean shovelArmed;

    private PlantType heldPlant;
    private int lastAnnouncedWave = -1;

    private boolean inDialogue;
    private Table dialogueOverlay;
    private int dialogueIndex;
    private String[][] dialogueLines;

    private boolean inBriefing;
    private Table briefingOverlay;

    private static final float MOWER_RUN_SPEED = 640f;
    private final boolean[] mowerWasPresent = new boolean[Layout.ROWS + 1];
    private final boolean[] mowerRunning = new boolean[Layout.ROWS + 1];
    private final float[] runningMowerX = new float[Layout.ROWS + 1];
    private boolean mowerStateInit;

    private final Vector3 touchScratch = new Vector3();
    private final Vector2 cursor = new Vector2();

    private float shakeTimer;
    private float shakeMagnitude;
    private final Vector2 shakeOffset = new Vector2();
    private static final float EXPLOSION_FX_LIFE = 0.5f;
    private final List<float[]> explosionFx = new ArrayList<>();
    private static final float DEATH_FX_LIFE = 0.6f;
    private final List<DeathFx> deathFxList = new ArrayList<>();

    private static final class DeathFx {
        boolean zombie;
        String pam;
        String clip;
        String label;
        float x, y, age;
    }

    public LawnScreen(PvzGame game, LevelSpec spec, List<PlantType> chosenPlants) {
        this.game = game;
        this.spec = spec;
        this.chosenPlants = chosenPlants;
    }

    @Override
    public void show() {
        session = new GameSession(game.user(), spec, chosenPlants, game.boostedPlants(),
                System.nanoTime());
        projectiles = new ProjectileFx(game.art());

        boolean musicOn = game.user() == null || game.user().getSettings().isMusicOn();
        String worldKey = spec.getWorld() == null ? "TUTORIAL" : spec.getWorld().name();
        game.music().play(worldKey, musicOn);

        viewport = new FitViewport(Layout.WORLD_W, Layout.WORLD_H);
        stage = new Stage(viewport, game.batch());

        buildHud();

        Gdx.input.setInputProcessor(new InputMultiplexer(stage, new LawnInput()));

        showObjectives();
    }

    private void buildHud() {
        Table top = new Table();
        top.setFillParent(true);
        top.top().left().pad(10f);
        stage.addActor(top);

        sunLabel = new Label("0", game.skin(), "default");
        plantFoodLabel = new Label("0", game.skin(), "default");

        TextureRegion shovelUp = game.art().region(Backdrops.SHOVEL_BUTTON);
        if (shovelUp == null) shovelUp = game.art().placeholder("SHOVEL", 56, 56, false);
        TextureRegion shovelDown = game.art().region(Backdrops.SHOVEL_BUTTON_DOWN);
        ImageButton.ImageButtonStyle shovelStyle = new ImageButton.ImageButtonStyle();
        shovelStyle.up = new TextureRegionDrawable(shovelUp);
        shovelStyle.down = new TextureRegionDrawable(shovelDown != null ? shovelDown : shovelUp);
        shovelStyle.checked = shovelStyle.down;
        shovelButton = new ImageButton(shovelStyle);
        shovelButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                shovelArmed = !shovelArmed;
                heldPlant = null;
                refreshShovel();
            }
        });

        TextureRegion pauseUp = game.art().region(Backdrops.PAUSE_BUTTON);
        if (pauseUp == null) pauseUp = game.art().placeholder("PAUSE", 44, 44, false);
        TextureRegion pauseDown = game.art().region(Backdrops.PAUSE_BUTTON_DOWN);
        ImageButton.ImageButtonStyle pauseStyle = new ImageButton.ImageButtonStyle();
        pauseStyle.up = new TextureRegionDrawable(pauseUp);
        pauseStyle.down = new TextureRegionDrawable(pauseDown != null ? pauseDown : pauseUp);
        pauseButton = new ImageButton(pauseStyle);
        pauseButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                togglePause();
            }
        });

        Table bar = new Table();
        bar.add(new Label("Sun ", game.skin(), "default"));
        bar.add(sunLabel).width(70f);
        bar.add(new Label("Plant food ", game.skin(), "default")).padLeft(12f);
        bar.add(plantFoodLabel).width(40f);
        bar.add(shovelButton).padLeft(16f).size(56f, 56f);
        bar.add(pauseButton).padLeft(8f).size(44f, 44f);

        top.add(bar).left().row();

        Table seedColumn = new Table();
        seedColumn.setFillParent(true);
        seedColumn.left();
        seedColumn.add(buildSeedBar()).padLeft(6f);
        stage.addActor(seedColumn);

        announceLabel = new Label("", game.skin(), "big");
        announceLabel.setAlignment(Align.center);
        announceLabel.setColor(1f, 0.25f, 0.20f, 0f);

        Table announceTable = new Table();
        announceTable.setFillParent(true);
        announceTable.center();
        announceTable.add(announceLabel);
        stage.addActor(announceTable);
    }

    private Table buildSeedBar() {
        Table bar = new Table();
        seedCards.clear();

        List<PlantType> source = spec.isConveyor() ? session.getConveyorBelt() : chosenPlants;

        for (int i = 0; i < PvzGame.SEED_SLOTS; i++) {
            PlantType type = (source != null && i < source.size()) ? source.get(i) : null;
            final SeedCardActor card = new SeedCardActor(game.art(), game.pam(), game.skin(), type,
                    SeedCardActor.Mode.IN_GAME);
            card.setBoosted(type != null && game.boostedPlants().contains(type));

            card.addListener(new ClickListener() {
                @Override
                public void clicked(InputEvent event, float x, float y) {
                    if (paused || ended) return;
                    if (!card.isPlayable()) return;
                    shovelArmed = false;
                    refreshShovel();
                    heldPlant = (heldPlant == card.getPlant()) ? null : card.getPlant();
                    refreshSelection();
                }
            });

            seedCards.add(card);
            bar.add(card).size(SeedCardActor.CARD_W, SeedCardActor.CARD_H).padBottom(4f).row();
        }
        return bar;
    }

    private void refreshShovel() {

        shovelButton.setColor(shovelArmed ? new Color(1f, 0.65f, 0.55f, 1f) : Color.WHITE);
    }

    private void refreshSelection() {
        for (SeedCardActor card : seedCards) {
            card.setSelected(heldPlant != null && card.getPlant() == heldPlant);
        }
    }

    private void announce(String text) {
        announceLabel.setText(text);
        announceTimer = ANNOUNCE_SECONDS;
    }

    @Override
    public void render(float delta) {
        game.art().update();

        if (!paused && !ended && !inDialogue && !inBriefing) {
            stepSimulation(delta);
        }
        updateEffects(delta);

        Gdx.gl.glClearColor(SKY.r, SKY.g, SKY.b, 1f);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        viewport.apply();
        float baseX = viewport.getCamera().position.x;
        float baseY = viewport.getCamera().position.y;
        if (shakeOffset.x != 0f || shakeOffset.y != 0f) {
            viewport.getCamera().position.set(baseX + shakeOffset.x, baseY + shakeOffset.y, viewport.getCamera().position.z);
            viewport.getCamera().update();
        }

        Batch batch = game.batch();
        batch.setProjectionMatrix(viewport.getCamera().combined);
        batch.begin();
        drawLawn(batch);
        drawGraves(batch);
        drawMowers(batch);
        drawPlantingHints(batch);
        drawEntities(batch);
        projectiles.draw(batch);
        drawSuns(batch);
        drawSeasonalFx(batch);
        drawExplosionFx(batch);
        drawDeathFx(batch);
        drawWaveMeter(batch);
        drawHeldPlant(batch);
        drawCooldownCursor(batch);
        batch.end();

        if (shakeOffset.x != 0f || shakeOffset.y != 0f) {
            viewport.getCamera().position.set(baseX, baseY, viewport.getCamera().position.z);
            viewport.getCamera().update();
        }

        updateHud(delta);
        stage.act(delta);
        stage.draw();
    }

    private void stepSimulation(float delta) {
        float scaled = delta * game.gameSpeed();
        animTime += scaled;

        projectiles.setSfxOn(game.user().getSettings().isSfxOn());
        projectiles.update(scaled, session);

        tickAccumulator += scaled;
        int ticks = 0;
        while (tickAccumulator >= SECONDS_PER_TICK && ticks < MAX_TICKS_PER_FRAME) {
            session.advanceTicks(1);
            tickAccumulator -= SECONDS_PER_TICK;
            ticks++;

            if (session.isGameover()) {
                showEndOverlay();
                return;
            }
        }

        if (ticks > 0) collectViewEvents();

        int wave = session.getCurrentWave();
        if (session.areWavesStarted() && wave != lastAnnouncedWave && wave > 0) {
            lastAnnouncedWave = wave;
            WorldType world = spec.getWorld();

            if (world == WorldType.DARK_AGES && hasTerrain(TerrainType.NECROMANCY)) {
                announce("Beware! Necromancy is raising zombies from the graves!");
            } else if (world == WorldType.BIG_WAVE_BEACH && hasTerrain(TerrainType.LOW_TIDE)) {
                announce("Warning! Zombies are surging in from the low tide!");
            } else if (wave >= session.getWaveCount()) {
                announce("Final wave!");
            } else {
                announce("Wave " + wave + " incoming!");
            }
        }

        updateMowers(scaled);
    }

    private void collectViewEvents() {
        for (int[] loc : session.drainExplosionEvents()) {
            explosionFx.add(new float[]{Layout.cellCenterX(loc[0]), Layout.cellY(loc[1]) + Layout.CELL_H * 0.5f, 0f});
            triggerShake(0.35f, 10f);
        }
        for (int[] loc : session.drainGargantuarSmashEvents()) {
            triggerShake(0.22f, 6f);
        }
        for (int[] loc : session.drainPianistEvents()) {
            zombieSfx.play("pianist_note", game.user().getSettings().isSfxOn());
        }
        for (float[] loc : session.drainSmallTornadoEvents()) {
            smallTornadoFx.add(new float[]{Layout.cellCenterX(loc[0]), Layout.cellY((int) loc[1]) + Layout.CELL_H * 0.5f, 0f});
        }
        for (Object[] ev : session.drainZombieDeathEvents()) {
            ZombieType type = (ZombieType) ev[0];
            int col = (Integer) ev[1];
            int row = (Integer) ev[2];
            DeathFx fx = new DeathFx();
            fx.zombie = true;
            if (CompositeZombies.isComposite(type)) {
                fx.pam = CompositeZombies.BODY_PAM;
                fx.clip = "idle";
            } else {
                fx.pam = game.pam().zombiePam(type);
                fx.clip = game.pam().zombieClip(type, PamCatalog.Clip.DEATH);
            }
            fx.label = type.name();
            fx.x = Layout.cellCenterX(col);
            fx.y = Layout.cellY(row);
            deathFxList.add(fx);
        }
        for (Object[] ev : session.drainPlantDeathEvents()) {
            PlantType type = (PlantType) ev[0];
            int col = (Integer) ev[1];
            int row = (Integer) ev[2];
            DeathFx fx = new DeathFx();
            fx.zombie = false;
            fx.pam = game.pam().plantPam(type);
            fx.clip = game.pam().plantClip(type, PamCatalog.Clip.DEATH);
            fx.label = type.name();
            fx.x = Layout.cellCenterX(col);
            fx.y = Layout.cellY(row);
            deathFxList.add(fx);
        }
    }

    private void triggerShake(float seconds, float magnitude) {
        shakeTimer = Math.max(shakeTimer, seconds);
        shakeMagnitude = Math.max(shakeMagnitude, magnitude);
    }

    private void updateEffects(float delta) {
        for (Iterator<float[]> it = explosionFx.iterator(); it.hasNext(); ) {
            float[] fx = it.next();
            fx[2] += delta;
            if (fx[2] >= EXPLOSION_FX_LIFE) it.remove();
        }
        for (Iterator<float[]> it = smallTornadoFx.iterator(); it.hasNext(); ) {
            float[] fx = it.next();
            fx[2] += delta;
            if (fx[2] >= SMALL_TORNADO_FX_LIFE) it.remove();
        }
        for (Iterator<DeathFx> it = deathFxList.iterator(); it.hasNext(); ) {
            DeathFx fx = it.next();
            fx.age += delta;
            if (fx.age >= DEATH_FX_LIFE) it.remove();
        }

        if (shakeTimer > 0f) {
            shakeTimer -= delta;
            float power = shakeMagnitude * Math.max(0f, shakeTimer) / 0.35f;
            shakeOffset.set(MathUtils.random(-power, power), MathUtils.random(-power, power));
            if (shakeTimer <= 0f) {
                shakeTimer = 0f;
                shakeMagnitude = 0f;
                shakeOffset.set(0f, 0f);
            }
        } else {
            shakeOffset.set(0f, 0f);
        }
    }

    private void updateMowers(float dt) {
        if (!mowerStateInit) {
            for (int row = 1; row <= Layout.ROWS; row++) {
                mowerWasPresent[row] = session.hasMower(row);
            }
            mowerStateInit = true;
        }
        for (int row = 1; row <= Layout.ROWS; row++) {
            boolean present = session.hasMower(row);
            if (mowerWasPresent[row] && !present && !mowerRunning[row]) {
                mowerRunning[row] = true;
                runningMowerX[row] = Layout.LAWN_X - Layout.MOWER_W;
            }
            mowerWasPresent[row] = present;
            if (mowerRunning[row]) {
                runningMowerX[row] += MOWER_RUN_SPEED * dt;
                if (runningMowerX[row] > Layout.LAWN_X + Layout.LAWN_W + Layout.MOWER_W) {
                    mowerRunning[row] = false;
                }
            }
        }
    }

    private boolean hasTerrain(TerrainType type) {
        for (int col = 1; col <= Layout.COLS; col++) {
            for (int row = 1; row <= Layout.ROWS; row++) {
                if (session.terrainAt(col, row) == type) return true;
            }
        }
        return false;
    }

    private void updateHud(float delta) {
        sunLabel.setText(String.valueOf(session.getSunBank()));
        plantFoodLabel.setText(String.valueOf(session.getPlantFoodsLeft()));

        int sun = session.getSunBank();
        for (SeedCardActor card : seedCards) {
            if (card.isEmptySlot()) continue;
            card.setAffordable(card.getSunCost() <= sun);
            card.setRecharge(rechargeOf(card.getPlant()));
        }

        if (announceTimer > 0f) {
            announceTimer -= delta;
            float alpha = Math.min(1f, announceTimer / 0.6f);
            announceLabel.setColor(1f, 0.25f, 0.20f, alpha);
        } else {
            announceLabel.setColor(1f, 0.25f, 0.20f, 0f);
        }
    }

    private float rechargeOf(PlantType type) {
        if (type == null) return 1f;
        return session.getCooldownFraction(type);
    }

    private void drawLawn(Batch batch) {
        TextureRegion pixel = game.art().pixel();

        WorldType world = spec.getWorld();
        boolean painted = Backdrops.drawCover(batch, game.art(), 0f, 0f,
                Layout.WORLD_W, Layout.WORLD_H,
                Backdrops.worldCenter(world),
                Backdrops.worldLeft(world),
                Backdrops.worldRight(world));
        float tint = painted ? 0.28f : 1f;

        for (int row = 1; row <= Layout.ROWS; row++) {
            for (int col = 1; col <= Layout.COLS; col++) {
                Color base = ((row + col) % 2 == 0) ? GRASS_LIGHT : GRASS_DARK;
                batch.setColor(base.r, base.g, base.b, base.a * tint);
                batch.draw(pixel, Layout.cellX(col), Layout.cellY(row), Layout.CELL_W, Layout.CELL_H);

                Color terrain = terrainColor(session.terrainAt(col, row));
                if (terrain != null) {
                    batch.setColor(terrain);
                    batch.draw(pixel, Layout.cellX(col), Layout.cellY(row), Layout.CELL_W, Layout.CELL_H);
                }
            }
        }

        if (game.showGrid()) {
            batch.setColor(GRID_LINE);
            for (int col = 1; col <= Layout.COLS + 1; col++) {
                batch.draw(pixel, Layout.cellX(col) - 1f, Layout.LAWN_Y, 2f, Layout.LAWN_H);
            }
            for (int row = 1; row <= Layout.ROWS + 1; row++) {
                batch.draw(pixel, Layout.LAWN_X, Layout.cellY(row) - 1f, Layout.LAWN_W, 2f);
            }
        }
        batch.setColor(Color.WHITE);
    }

    private static Color terrainColor(TerrainType terrain) {
        if (terrain == null) return null;
        switch (terrain) {
            case WATER:
                return new Color(0.20f, 0.45f, 0.85f, 0.55f);
            case LOW_TIDE:
                return new Color(0.30f, 0.55f, 0.80f, 0.30f);
            case FROZEN:
                return new Color(0.70f, 0.90f, 1f, 0.45f);
            case ICE_SLIP_UP:
            case ICE_SLIP_DOWN:
                return new Color(0.80f, 0.95f, 1f, 0.30f);
            case TOMB:
                return new Color(0.25f, 0.20f, 0.22f, 0.55f);
            case NECROMANCY:
                return new Color(0.35f, 0.15f, 0.45f, 0.40f);
            case GRASS:
            default:
                return null;
        }
    }

    private void drawMowers(Batch batch) {
        TextureRegion region = game.art().region(Backdrops.MOWER);
        float w = Layout.MOWER_W + 16f;
        float h = 48f;
        batch.setColor(Color.WHITE);

        for (int row = 1; row <= Layout.ROWS; row++) {
            if (!session.hasMower(row)) continue;
            float x = Layout.LAWN_X - Layout.MOWER_W - 6f;
            float y = Layout.cellCenterY(row) - h / 2f;
            if (region != null) {
                batch.draw(region, x, y, w, h);
            } else {
                batch.draw(game.art().placeholder("MOWER", 48, 40, false),
                        x, Layout.cellCenterY(row) - 20f, Layout.MOWER_W - 8f, 40f);
            }
        }

        for (int row = 1; row <= Layout.ROWS; row++) {
            if (!mowerRunning[row]) continue;
            float x = runningMowerX[row];
            float y = Layout.cellCenterY(row) - h / 2f;

            batch.setColor(0.85f, 0.85f, 0.78f, 0.45f);
            batch.draw(game.art().pixel(), x - 20f, y + 6f, 18f, h - 16f);
            batch.setColor(Color.WHITE);
            if (region != null) {
                batch.draw(region, x, y, w, h);
            } else {
                batch.draw(game.art().placeholder("MOWER", 48, 40, false),
                        x, y + 4f, Layout.MOWER_W - 8f, 40f);
            }
        }
        batch.setColor(Color.WHITE);
    }

    private void drawPlantingHints(Batch batch) {
        if (heldPlant == null && !shovelArmed) return;

        int col = Layout.colAt(cursor.x);
        int row = Layout.rowAt(cursor.y);
        if (!Layout.onLawn(col, row)) return;

        TextureRegion pixel = game.art().pixel();
        batch.setColor(HIGHLIGHT);
        batch.draw(pixel, Layout.LAWN_X, Layout.cellY(row), Layout.LAWN_W, Layout.CELL_H);
        batch.draw(pixel, Layout.cellX(col), Layout.LAWN_Y, Layout.CELL_W, Layout.LAWN_H);
        batch.setColor(Color.WHITE);
    }

    private void drawEntities(Batch batch) {
        List<PlantedUnit> plants = session.getPlantsOnLawn();

        for (int row = 1; row <= Layout.ROWS; row++) {
            for (PlantedUnit unit : plants) {
                if (unit.getRow() == row && isCarrier(unit.getType())) drawPlant(batch, unit);
            }
            for (PlantedUnit unit : plants) {
                if (unit.getRow() == row && !isCarrier(unit.getType()) && !isShield(unit.getType())) {
                    drawPlant(batch, unit);
                }
            }
            for (ActiveZombie zombie : session.getZombiesOnLawn()) {
                if (zombie.getRow() == row) drawZombie(batch, zombie);
            }
            for (PlantedUnit unit : plants) {
                if (unit.getRow() == row && isShield(unit.getType())) drawPlant(batch, unit);
            }
        }
        batch.setColor(Color.WHITE);
    }

    private static boolean isCarrier(PlantType type) {
        return type != null && type.name().contains("LILY_PAD");
    }

    private static boolean isShield(PlantType type) {
        return type != null && type.name().contains("PUMPKIN");
    }

    private void drawPlant(Batch batch, PlantedUnit unit) {
        PlantType type = unit.getType();
        if (type == null) return;

        float x = Layout.cellCenterX(unit.getCol());
        float y = Layout.cellY(unit.getRow()) + 8f;

        if (unit.isFrozen()) {
            batch.setColor(FROZEN_TINT);
        } else if (unit.isDisabled()) {
            batch.setColor(0.65f, 0.65f, 0.65f, 1f);
        } else {
            batch.setColor(Color.WHITE);
        }

        String pam = game.pam().plantPam(type);
        String clip = game.pam().plantClip(type, PamCatalog.Clip.IDLE);
        if (!game.art().drawFitted(batch, pam, clip, animTime, x, y, PLANT_HEIGHT, true, null)) {
            batch.draw(game.art().placeholder(type.name(), 64, 72, false), x - 32f, y, 64f, 72f);
        }

        if (unit.isFrozen()) {
            if (!game.art().drawFitted(batch, Backdrops.ICE_BLOCK_PLANT_PAM, "freeze_idle", animTime,
                    x, y, PLANT_HEIGHT, true, null)) {
                batch.setColor(0.6f, 0.85f, 1f, 0.32f);
                batch.draw(game.art().placeholder("ICE_BLOCK_PLANT", 60, (int) PLANT_HEIGHT, false),
                        x - 30f, y, 60f, PLANT_HEIGHT);
            }
        }
        batch.setColor(Color.WHITE);
    }

    private void drawZombie(Batch batch, ActiveZombie zombie) {
        float x = Layout.cellCenterX((float) zombie.getCol());
        float y = Layout.cellY(zombie.getRow()) + 6f;

        if (zombie.isFrozen()) {
            batch.setColor(FROZEN_TINT);
        } else if (zombie.getSlowTicks() > 0) {
            batch.setColor(SLOWED_TINT);
        } else if (zombie.isGlowing()) {
            batch.setColor(1f, 0.85f, 0.55f, 1f);
        } else {
            batch.setColor(Color.WHITE);
        }

        ZombieType zType = zombie.getZombie().getType();

        PamCatalog.Clip motion = PamCatalog.Clip.WALK;
        if ((zType == ZombieType.OCTOPUS || zType == ZombieType.FISHERMAN) && zombie.getAbilityTimer() > 0) {
            motion = PamCatalog.Clip.ATTACK;
        }
        if (CompositeZombies.isComposite(zType)) {
            CompositeZombies.draw(game.art(), game.pam(), batch, zType, game.pam().zombieClip(zType, motion),
                    animTime, x, y, ZOMBIE_HEIGHT);
        } else {
            String pam = game.pam().zombiePam(zType);
            String clip = game.pam().zombieClip(zType, motion);
            if (!game.art().drawFitted(batch, pam, clip, animTime, x, y, ZOMBIE_HEIGHT, true, null)) {
                batch.draw(game.art().placeholder(zType.name(), 58, 84, false),
                        x - 29f, y, 58f, 84f);
            }
        }

        if (zombie.isFrozen()) {
            if (!game.art().drawFitted(batch, Backdrops.ICE_BLOCK_ZOMBIE_PAM, "idle", animTime,
                    x, y, ZOMBIE_HEIGHT, true, null)) {
                batch.setColor(0.6f, 0.85f, 1f, 0.35f);
                batch.draw(game.art().placeholder("ICE_BLOCK_ZOMBIE", 52, (int) ZOMBIE_HEIGHT, false),
                        x - 26f, y, 52f, ZOMBIE_HEIGHT);
            }
            batch.setColor(Color.WHITE);
        }
    }

    private void drawSuns(Batch batch) {
        for (int[] sun : session.getGroundSuns()) {
            drawSun(batch, Layout.cellCenterX(sun[0]), Layout.cellCenterY(sun[1]) - 24f,
                    sun[2] >= 100 ? SunType.SPECIAL : SunType.NORMAL);
        }
        for (FallingSun sun : session.getFallingSuns()) {
            float x = Layout.cellCenterX(sun.getX());
            float targetY = Layout.cellCenterY(sun.getY()) - 24f;
            float y = Layout.WORLD_H - (Layout.WORLD_H - targetY) * sun.getFallProgress();
            drawSun(batch, x, y, sun.getType());
        }
        batch.setColor(Color.WHITE);
    }

    private void drawSun(Batch batch, float x, float y, SunType type) {
        float size = type == SunType.SPECIAL ? 54f : 44f;

        TextureRegion region = game.art().region(size > 50f ? Backdrops.SUN : Backdrops.SUN_SMALL);
        if (region == null) region = game.art().region(Backdrops.SUN);
        if (region != null) {
            if (type == SunType.RADIOACTIVE) batch.setColor(SUN_RADIOACTIVE);
            else batch.setColor(Color.WHITE);
            batch.draw(region, x - size / 2f, y - size / 2f, size, size);
        } else {
            Color color = type == SunType.SPECIAL ? SUN_SPECIAL
                    : (type == SunType.RADIOACTIVE ? SUN_RADIOACTIVE : SUN_NORMAL);
            batch.setColor(color);
            batch.draw(game.art().placeholder("SUN_" + type.name(), 48, 48, true),
                    x - size / 2f, y - size / 2f, size, size);
        }
        batch.setColor(Color.WHITE);
    }

    private void drawHeldPlant(Batch batch) {
        if (heldPlant == null) return;
        batch.setColor(1f, 1f, 1f, 0.75f);
        float footX = cursor.x;
        float footY = cursor.y - 36f;
        String pam = game.pam().plantPam(heldPlant);
        String clip = game.pam().plantClip(heldPlant, PamCatalog.Clip.IDLE);
        if (!game.art().drawFitted(batch, pam, clip, animTime, footX, footY, PLANT_HEIGHT, true, null)) {
            batch.draw(game.art().placeholder(heldPlant.name(), 64, 72, false),
                    footX - 32f, footY, 64f, 72f);
        }
        batch.setColor(Color.WHITE);
    }

    private void drawExplosionFx(Batch batch) {
        if (explosionFx.isEmpty()) return;
        TextureRegion rear = game.art().region(Backdrops.EXPLOSION_REAR);
        TextureRegion top = game.art().region(Backdrops.EXPLOSION_TOP);
        for (float[] fx : explosionFx) {
            float t = fx[2] / EXPLOSION_FX_LIFE;
            float alpha = 1f - t;
            float size = 90f + t * 40f;
            batch.setColor(1f, 1f, 1f, alpha);
            if (rear != null) {
                batch.draw(rear, fx[0] - size / 2f, fx[1] - size / 2f, size, size);
            } else {
                batch.draw(game.art().placeholder("BOOM", (int) size, (int) size, false),
                        fx[0] - size / 2f, fx[1] - size / 2f, size, size);
            }
            if (top != null) {
                batch.draw(top, fx[0] - size / 2f, fx[1] - size * 0.35f, size, size);
            }
        }
        batch.setColor(Color.WHITE);
    }

    private void drawDeathFx(Batch batch) {
        if (deathFxList.isEmpty()) return;
        for (DeathFx fx : deathFxList) {
            float alpha = Math.max(0f, 1f - (fx.age / DEATH_FX_LIFE));
            batch.setColor(1f, 1f, 1f, alpha);
            float height = fx.zombie ? ZOMBIE_HEIGHT : PLANT_HEIGHT;
            if (!game.art().drawFitted(batch, fx.pam, fx.clip, fx.age, fx.x, fx.y, height, true, null)) {
                batch.draw(game.art().placeholder(fx.label, 64, 72, false), fx.x - 32f, fx.y, 64f, 72f);
            }
        }
        batch.setColor(Color.WHITE);
    }

    private void drawCooldownCursor(Batch batch) {
        if (heldPlant == null) return;
        if (session.getCooldownFraction(heldPlant) >= 1f) return;
        float size = 28f;
        batch.setColor(Color.WHITE);
        TextureRegion glass = game.art().region(Backdrops.HOURGLASS_CURSOR);
        if (glass == null) glass = game.art().placeholder("HOURGLASS", (int) size, (int) size, false);
        batch.draw(glass, cursor.x + 10f, cursor.y - 10f, size, size);
    }

    private void drawGraves(Batch batch) {
        WorldType world = spec.getWorld();
        String graveId = world == WorldType.ANCIENT_EGYPT ? Backdrops.GRAVE_EGYPT : Backdrops.GRAVE;
        TextureRegion region = game.art().region(graveId);
        if (region == null) region = game.art().region(Backdrops.GRAVE);

        for (int col = 1; col <= Layout.COLS; col++) {
            for (int row = 1; row <= Layout.ROWS; row++) {
                TerrainType terrain = session.terrainAt(col, row);
                if (terrain != TerrainType.TOMB && terrain != TerrainType.NECROMANCY) continue;

                float cx = Layout.cellCenterX(col);
                float by = Layout.cellY(row) + 6f;
                float w = 48f;
                float h = 62f;
                boolean necro = terrain == TerrainType.NECROMANCY;

                if (region != null) {
                    batch.setColor(necro ? NECRO_TINT : Color.WHITE);
                    batch.draw(region, cx - w / 2f, by, w, h);
                } else {
                    batch.draw(game.art().placeholder(necro ? "GRAVE_NECRO" : "GRAVE", (int) w, (int) h, false),
                            cx - w / 2f, by, w, h);
                }
            }
        }
        batch.setColor(Color.WHITE);
    }

    private void drawSeasonalFx(Batch batch) {
        WorldType world = spec.getWorld();
        if (world == null) return;
        TextureRegion pixel = game.art().pixel();

        switch (world) {
            case FROSTBITE_CAVES:
                drawFrostbiteWind(batch);
                break;
            case BIG_WAVE_BEACH:
                batch.setColor(0.20f, 0.50f, 0.85f, 0.12f);
                batch.draw(pixel, Layout.LAWN_X, Layout.LAWN_Y, Layout.LAWN_W, Layout.CELL_H * 2f);
                break;
            case DARK_AGES:
                batch.setColor(0.35f, 0.12f, 0.45f, 0.14f);
                batch.draw(pixel, Layout.LAWN_X, Layout.LAWN_Y, Layout.LAWN_W, Layout.LAWN_H);
                break;
            default:
                break;
        }
        if (session.getWaveCount() > 0 && session.getCurrentWave() >= session.getWaveCount()) {
            drawSandstorm(batch);
        }
        drawSmallTornadoes(batch);
        batch.setColor(Color.WHITE);
    }

    private static final float SMALL_TORNADO_FX_LIFE = 1.2f;
    private final List<float[]> smallTornadoFx = new ArrayList<>();

    private void drawSmallTornadoes(Batch batch) {
        if (smallTornadoFx.isEmpty()) return;
        for (float[] fx : smallTornadoFx) {
            float t = fx[2] / SMALL_TORNADO_FX_LIFE;
            float alpha = 1f - Math.min(1f, t);
            batch.setColor(1f, 1f, 1f, alpha * 0.9f);
            if (!game.art().drawFitted(batch, Backdrops.SANDSTORM_TOP_PAM, "loop", animTime,
                    fx[0], fx[1], Layout.CELL_H * 1.4f, true, null)) {
                TextureRegion pixel = game.art().pixel();
                batch.draw(pixel, fx[0] - 30f, fx[1], 60f, 80f);
            }
        }
        batch.setColor(Color.WHITE);
    }

    private void drawFrostbiteWind(Batch batch) {
        if (game.art().drawFitted(batch, Backdrops.FROSTBITE_CHILL_WIND_PAM, "animation", animTime,
                Layout.LAWN_X + Layout.LAWN_W * 0.5f, Layout.LAWN_Y, Layout.LAWN_H, true, null)) {
            return;
        }
        for (int i = 0; i < 5; i++) {
            float travel = (animTime * (60f + i * 14f) + i * 220f) % (Layout.LAWN_W + 240f);
            float gx = Layout.LAWN_X + Layout.LAWN_W - travel;
            float gy = Layout.LAWN_Y + 40f + i * 90f + (float) Math.sin(animTime * 2f + i) * 30f;
            batch.setColor(1f, 1f, 1f, 0.30f);
            if (!game.art().drawFitted(batch, Backdrops.ICE_BLOCK_PARTICLES_PAM, "animation", animTime + i * 0.4f,
                    gx, gy, 44f, true, null)) {
                TextureRegion region = game.art().region(Backdrops.ICE_BLOCK_PARTICLES_IMAGE);
                if (region != null) batch.draw(region, gx - 22f, gy, 44f, 40f);
            }
        }

        float baseX = Layout.LAWN_X + Layout.LAWN_W * 0.5f;
        float baseY = Layout.LAWN_Y + 20f;
        int gustSegments = 8;
        for (int i = 0; i < gustSegments; i++) {
            float f = i / (float) gustSegments;
            float sway = (float) Math.sin(animTime * 6f + i * 0.7f) * (10f + f * 26f);
            float yy = baseY + f * 300f;
            float size = 26f + f * 30f;
            batch.setColor(1f, 1f, 1f, 0.20f + (1f - f) * 0.20f);
            if (!game.art().drawFitted(batch, Backdrops.ICE_BLOCK_PARTICLES_PAM, "animation2", animTime + i * 0.2f,
                    baseX + sway, yy, size, true, null)) {
                TextureRegion region = game.art().region(Backdrops.ICE_BLOCK_PARTICLES_IMAGE);
                if (region != null) batch.draw(region, baseX + sway - size / 2f, yy, size, size);
            }
        }
        batch.setColor(Color.WHITE);
    }

    private void drawSandstorm(Batch batch) {
        float cx = Layout.LAWN_X + Layout.LAWN_W * 0.5f;
        float baseY = Layout.LAWN_Y;
        batch.setColor(1f, 1f, 1f, 0.90f);
        boolean drewRear = game.art().drawFitted(batch, Backdrops.SANDSTORM_REAR_PAM, "loop", animTime,
                cx, baseY, Layout.LAWN_H, true, null);
        boolean drewTop = game.art().drawFitted(batch, Backdrops.SANDSTORM_TOP_PAM, "loop", animTime,
                cx, baseY, Layout.LAWN_H, true, null);
        if (!drewRear && !drewTop) {
            TextureRegion pixel = game.art().pixel();
            batch.setColor(0.82f, 0.68f, 0.35f, 0.20f);
            batch.draw(pixel, Layout.LAWN_X, Layout.LAWN_Y, Layout.LAWN_W, Layout.LAWN_H);
        }
        batch.setColor(Color.WHITE);
    }

    private void drawWaveMeter(Batch batch) {
        int waveCount = session.getWaveCount();
        if (waveCount <= 0) return;

        float w = 360f;
        float h = 16f;
        float x = Layout.WORLD_W - w - 30f;
        float y = 26f;

        TextureRegion bg = game.art().region(Backdrops.PROGRESS_METER_BG);
        TextureRegion fill = game.art().region(Backdrops.PROGRESS_METER_FILL);

        float progress = session.getCurrentWaveProgress();

        if (bg != null) {
            batch.setColor(Color.WHITE);
            batch.draw(bg, x, y, w, h);
        } else {
            batch.draw(game.art().placeholder("WAVE_METER_BG", (int) w, (int) h, false), x, y, w, h);
        }
        if (fill != null) {
            batch.setColor(Color.WHITE);
            batch.draw(fill, x, y, w * progress, h);
        } else {
            batch.setColor(0.85f, 0.20f, 0.15f, 0.95f);
            batch.draw(game.art().placeholder("WAVE_METER_FILL", (int) w, (int) h, false), x, y, w * progress, h);
        }

        TextureRegion pole = game.art().region(Backdrops.PROGRESS_METER_POLE);
        TextureRegion flag = game.art().region(Backdrops.PROGRESS_FLAG);
        if (flag == null) flag = game.art().region(Backdrops.RED_FLAG);
        for (int i = 1; i <= waveCount; i++) {
            float fx = x + w * (i / (float) waveCount);
            boolean big = i >= waveCount;
            float fh = big ? 34f : 26f;
            float fw = big ? 22f : 16f;
            if (pole != null) {
                batch.setColor(Color.WHITE);
                batch.draw(pole, fx - 2f, y, 4f, h + fh);
            }
            if (flag != null) {
                batch.setColor(Color.WHITE);
                batch.draw(flag, fx - fw / 2f, y + h - 3f, fw, fh);
            } else if (pole == null) {
                batch.draw(game.art().placeholder("FLAG", (int) fw, (int) (h + fh), false),
                        fx - fw / 2f, y, fw, h + fh);
            }
        }

        TextureRegion head = game.art().region(Backdrops.WAVE_METER_HEAD);
        float markerSize = 22f;
        float markerX = x + w * progress;
        batch.setColor(Color.WHITE);
        if (head != null) {
            batch.draw(head, markerX - markerSize / 2f, y - 4f, markerSize, markerSize);
        } else {
            batch.draw(game.art().placeholder("ZHEAD", (int) markerSize, (int) markerSize, false),
                    markerX - markerSize / 2f, y - 4f, markerSize, markerSize);
        }
        batch.setColor(Color.WHITE);
    }

    private boolean isWorldIntroLevel() {
        String id = spec.getId();
        return "1-1".equals(id) || "2-1".equals(id) || "3-1".equals(id) || "4-1".equals(id);
    }

    private void onIntroFinished() {
        announce("A huge wave of zombies is approaching!");
    }

    private List<String> objectivesFor(LevelSpec spec) {
        List<String> lines = new ArrayList<>();
        LevelType type = spec.getLevelType();
        if (type == null) type = LevelType.NORMAL;
        switch (type) {
            case TIMED_WAR:
                lines.add("Defeat " + spec.getKillTarget() + " zombies within "
                        + spec.getTimeLimitSeconds() + " seconds!");
                break;
            case DEAD_LINE:
                lines.add("Don't let any zombie reach column " + spec.getDeadlineColumn() + "!");
                break;
            case SAVE_OUR_SEEDS:
                lines.add("Protect the pre-planted seedlings -- losing one ends the level!");
                break;
            case SAVE_THE_PLANTS:
                lines.add("Don't lose more than " + spec.getMaxPlantLosses() + " of your plants!");
                break;
            case LOVE_YOUR_PLANTS:
                lines.add("Keep plant losses to " + spec.getMaxPlantLosses() + " or fewer!");
                break;
            case NIGHT_OPS:
                lines.add("No sun falls from the sky at night -- rely on sun-producing plants!");
                break;
            case PLANT_WHAT_YOU_GET:
                lines.add("You start with " + spec.getInitialSun()
                        + " sun and no sun production -- spend it wisely!");
                break;
            case CONVEYOR_BELT:
                lines.add("Plants arrive on a conveyor belt -- grab them before they pass!");
                break;
            case LOCKED_PLANTS:
                lines.add("Some of your favorite plants are locked away for this level!");
                break;
            case SCORED:
                lines.add("Score attack: earn as many MooPoints as you can!");
                break;
            case NORMAL:
            default:
                lines.add("Don't let the zombies reach your house!");
                break;
        }
        if (!spec.isSkySunEnabled() && type != LevelType.NIGHT_OPS && type != LevelType.PLANT_WHAT_YOU_GET) {
            lines.add("No sun will fall from the sky this level.");
        }
        lines.add("Survive and defeat all " + spec.getWaveCount() + " waves of zombies to win!");
        return lines;
    }

    private void showObjectives() {
        inBriefing = true;
        List<String> lines = objectivesFor(spec);

        briefingOverlay = new Table();
        briefingOverlay.setFillParent(true);
        briefingOverlay.center();

        TextureRegion pixel = game.art().pixel();
        if (pixel != null) {
            briefingOverlay.setBackground(new TextureRegionDrawable(pixel)
                    .tint(new Color(0f, 0f, 0f, 0.55f)));
        }

        Table box = new Table();
        if (pixel != null) {
            box.setBackground(new TextureRegionDrawable(pixel)
                    .tint(new Color(0.30f, 0.20f, 0.08f, 0.92f)));
        }
        box.pad(24f);

        Label title = new Label("Level Objectives", game.skin(), "big");
        title.setColor(1f, 0.85f, 0.30f, 1f);
        box.add(title).padBottom(14f).row();

        for (String line : lines) {
            Label l = new Label("\u2022 " + line, game.skin(), "default");
            l.setWrap(true);
            box.add(l).width(560f).left().padBottom(6f).row();
        }

        TextButton continueButton = new TextButton("Continue", game.skin(), "green");
        continueButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                if (briefingOverlay != null) briefingOverlay.remove();
                briefingOverlay = null;
                inBriefing = false;
                startDialogue();
            }
        });
        box.add(continueButton).width(220f).height(44f).padTop(12f).row();

        briefingOverlay.add(box).width(620f);
        stage.addActor(briefingOverlay);
    }

    private void startDialogue() {
        if (!isWorldIntroLevel()) {
            onIntroFinished();
            return;
        }
        dialogueLines = dialogueFor(spec.getWorld());
        if (dialogueLines == null || dialogueLines.length == 0) {
            onIntroFinished();
            return;
        }
        inDialogue = true;
        dialogueIndex = 0;
        showDialogueLine();
    }

    private String[][] dialogueFor(WorldType world) {
        if (world == WorldType.ANCIENT_EGYPT) {
            return new String[][]{
                    {"Crazy Dave", "WABBY WABBO! Ancient Egypt! I think I buried my car keys here."},
                    {"Penny", "User Dave, that was five thousand years ago. Also, zombies approach."},
                    {"Crazy Dave", "Then let's plant some plants! To the lawn!"}
            };
        } else if (world == WorldType.FROSTBITE_CAVES) {
            return new String[][]{
                    {"Crazy Dave", "Brrr! The Frostbite Caves! My mustache is a popsicle!"},
                    {"Penny", "Warning: icy wind will freeze your plants. Thaw them with fire."},
                    {"Crazy Dave", "Cool. Literally. Let's go!"}
            };
        } else if (world == WorldType.BIG_WAVE_BEACH) {
            return new String[][]{
                    {"Crazy Dave", "Big Wave Beach! Surf's up, brains down!"},
                    {"Penny", "Caution: the tide rises and zombies swim in from the low tide."},
                    {"Crazy Dave", "Then we plant fast before the water comes back!"}
            };
        } else if (world == WorldType.DARK_AGES) {
            return new String[][]{
                    {"Crazy Dave", "The Dark Ages! Spooky! The necromancy tickles my beard."},
                    {"Penny", "Alert: necromancers raise zombies from the graves. Stay sharp."},
                    {"Crazy Dave", "Sharp like a jalapeno! Defend the lawn!"}
            };
        }
        return new String[][]{
                {"Crazy Dave", "Time to plant, neighbor! The zombies are coming!"},
                {"Penny", "Affirmative, User Dave. Deploying to the lawn."}
        };
    }

    private void showDialogueLine() {
        if (dialogueOverlay != null) dialogueOverlay.remove();
        if (dialogueLines == null || dialogueIndex >= dialogueLines.length) {
            inDialogue = false;
            dialogueOverlay = null;
            onIntroFinished();
            return;
        }

        String speaker = dialogueLines[dialogueIndex][0];
        String line = dialogueLines[dialogueIndex][1];

        dialogueOverlay = new Table();
        dialogueOverlay.setFillParent(true);
        dialogueOverlay.bottom();

        TextureRegion pixel = game.art().pixel();
        if (pixel != null) {
            dialogueOverlay.setBackground(new TextureRegionDrawable(pixel)
                    .tint(new Color(0f, 0f, 0f, 0.25f)));
        }

        Table box = new Table();
        if (pixel != null) {
            box.setBackground(new TextureRegionDrawable(pixel)
                    .tint(new Color(0f, 0f, 0f, 0.82f)));
        }
        box.pad(18f);

        String portraitClip = "Crazy Dave".equals(speaker) ? "dave" : "winnie";
        NpcPortraitActor portrait = new NpcPortraitActor(game, Backdrops.DAVE_WINNIE_NARRATION_PAM,
                portraitClip, speaker, 96f);
        box.add(portrait).size(96f, 96f).padRight(14f);

        Table textCol = new Table();
        Label name = new Label(speaker, game.skin(), "medium");
        name.setColor(1f, 0.85f, 0.30f, 1f);
        textCol.add(name).left().padBottom(6f).row();

        Label body = new Label(line, game.skin(), "default");
        body.setWrap(true);
        textCol.add(body).width(660f).left().row();

        Label hint = new Label("(click to continue)", game.skin(), "default");
        hint.setColor(0.7f, 0.7f, 0.7f, 1f);
        textCol.add(hint).right().padTop(6f);
        box.add(textCol);

        dialogueOverlay.add(box).width(900f).padBottom(40f);
        dialogueOverlay.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                dialogueIndex++;
                showDialogueLine();
            }
        });
        stage.addActor(dialogueOverlay);
    }

    private void togglePause() {
        if (ended) return;
        paused = !paused;

        if (!paused) {
            if (pauseOverlay != null) pauseOverlay.remove();
            pauseOverlay = null;
            return;
        }

        pauseOverlay = new Table();
        pauseOverlay.setFillParent(true);
        pauseOverlay.center();
        pauseOverlay.add(new Label("Paused", game.skin(), "big")).padBottom(18f).row();

        TextButton resume = new TextButton("Resume", game.skin(), "green");
        resume.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                togglePause();
            }
        });
        pauseOverlay.add(resume).width(260f).padBottom(8f).row();

        TextButton restart = new TextButton("Restart level", game.skin(), "brown");
        restart.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                game.setScreen(new LawnScreen(game, spec, chosenPlants));
            }
        });
        pauseOverlay.add(restart).width(260f).padBottom(8f).row();

        TextButton exit = new TextButton("Save and exit", game.skin(), "brown");
        exit.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                game.save();
                game.setScreen(new MainMenuScreen(game));
            }
        });
        pauseOverlay.add(exit).width(260f);

        stage.addActor(pauseOverlay);
    }

    private void showEndOverlay() {
        if (ended) return;
        ended = true;

        final boolean won = session.isWon();
        if (won) {
            game.user().getProgress().completeLevel(spec.getId());
            game.save();
        }

        endOverlay = new Table();
        endOverlay.setFillParent(true);
        endOverlay.center();

        endOverlay.add(new Label(won ? "Level complete!" : "The zombies ate your brains!",
                game.skin(), "big")).padBottom(10f).row();

        String message = session.getEndMessage();
        if (message != null && !message.isEmpty()) {
            endOverlay.add(new Label(message, game.skin(), "default")).padBottom(16f).row();
        }

        endOverlay.add(new Label("Zombies defeated: " + session.getKillsThisLevel()
                + "   Sun collected: " + session.getSunCollectedTotal(),
                game.skin(), "default")).padBottom(18f).row();

        if (!won) {
            TextButton retry = new TextButton("Try again", game.skin(), "green");
            retry.addListener(new ClickListener() {
                @Override
                public void clicked(InputEvent event, float x, float y) {
                    game.setScreen(new LawnScreen(game, spec, chosenPlants));
                }
            });
            endOverlay.add(retry).width(260f).padBottom(8f).row();
        }

        TextButton leave = new TextButton("Back to menu", game.skin(), "brown");
        leave.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                game.setScreen(new MainMenuScreen(game));
            }
        });
        endOverlay.add(leave).width(260f);

        stage.addActor(endOverlay);
    }

    private final class LawnInput extends InputAdapter {

        @Override
        public boolean mouseMoved(int screenX, int screenY) {
            track(screenX, screenY);
            hoverCollectSun();
            return false;
        }

        @Override
        public boolean touchDragged(int screenX, int screenY, int pointer) {
            track(screenX, screenY);
            hoverCollectSun();
            return false;
        }

        @Override
        public boolean touchDown(int screenX, int screenY, int pointer, int button) {
            if (paused || ended) return false;
            track(screenX, screenY);

            if (button == Input.Buttons.RIGHT) {
                heldPlant = null;
                shovelArmed = false;
                refreshShovel();
                refreshSelection();
                return true;
            }

            if (hoverCollectSun()) return true;

            int col = Layout.colAt(cursor.x);
            int row = Layout.rowAt(cursor.y);
            if (!Layout.onLawn(col, row)) return false;

            if (shovelArmed) {
                session.pluckPlant(col, row);
                shovelArmed = false;
                refreshShovel();
                return true;
            }

            if (heldPlant != null) {
                session.plantPlant(heldPlant, col, row);

                if (session.plantAt(col, row) != null) {
                    heldPlant = null;
                    refreshSelection();
                }
                return true;
            }

            if (session.plantAt(col, row) != null && session.getPlantFoodsLeft() > 0) {
                session.feedPlant(col, row);
                return true;
            }
            return false;
        }

        @Override
        public boolean keyDown(int keycode) {
            switch (keycode) {
                case Input.Keys.ESCAPE:
                    togglePause();
                    return true;
                case Input.Keys.G:
                    game.setShowGrid(!game.showGrid());
                    return true;
                case Input.Keys.SPACE:
                    if (!session.areWavesStarted()) session.startZombieWaves();
                    return true;
                case Input.Keys.NUM_1:
                    game.setGameSpeed(1);
                    return true;
                case Input.Keys.NUM_2:
                    game.setGameSpeed(2);
                    return true;
                case Input.Keys.NUM_3:
                    game.setGameSpeed(3);
                    return true;
                default:
                    return false;
            }
        }

        private void track(int screenX, int screenY) {
            touchScratch.set(screenX, screenY, 0f);
            viewport.getCamera().unproject(touchScratch,
                    viewport.getScreenX(), viewport.getScreenY(),
                    viewport.getScreenWidth(), viewport.getScreenHeight());
            cursor.set(touchScratch.x, touchScratch.y);
        }
    }

    private boolean hoverCollectSun() {
        if (paused || ended) return false;

        for (int[] sun : session.getGroundSuns()) {
            float x = Layout.cellCenterX(sun[0]);
            float y = Layout.cellCenterY(sun[1]) - 24f;
            if (cursor.dst(x, y) <= SUN_PICK_RADIUS) {
                session.collectSun(sun[0], sun[1]);
                return true;
            }
        }

        for (FallingSun sun : session.getFallingSuns()) {
            float x = Layout.cellCenterX(sun.getX());
            float targetY = Layout.cellCenterY(sun.getY()) - 24f;
            float y = Layout.WORLD_H - (Layout.WORLD_H - targetY) * sun.getFallProgress();
            if (cursor.dst(x, y) <= SUN_PICK_RADIUS) {
                session.collectSun(sun.getX(), sun.getY());
                return true;
            }
        }
        return false;
    }

    @Override
    public void resize(int width, int height) {
        viewport.update(width, height, true);
    }

    @Override
    public void pause() {
    }

    @Override
    public void resume() {
    }

    @Override
    public void hide() {
        Gdx.input.setInputProcessor(null);
    }

    @Override
    public void dispose() {
        if (stage != null) stage.dispose();
    }
}
