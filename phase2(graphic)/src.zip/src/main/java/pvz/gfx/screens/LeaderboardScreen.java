package pvz.gfx.screens;

import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import pvz.gfx.PvzGame;
import pvz.gfx.art.Backdrops;
import pvz.model.auth.User;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class LeaderboardScreen extends PanelScreen {

    private static final String[] COLUMNS = {"Mini-games", "Daily quests", "Quests", "Score",
            "Games", "Zombies"};

    private int column = 3;
    private boolean ascending = false;

    public LeaderboardScreen(PvzGame game) {
        super(game);
    }

    @Override
    protected String title() {
        return "Leaderboard";
    }

    @Override
    protected String[] backdrops() {
        return new String[]{Backdrops.MENU_WEST, Backdrops.MENU_DARKAGES, Backdrops.MENU_TUTORIAL};
    }

    private int valueOf(User user, int index) {
        switch (index) {
            case 0:
                return user.getMiniGamesCompleted();
            case 1:
                return user.getDailyQuestsDone();
            case 2:
                return user.getOtherQuestsDone();
            case 3:
                return user.getBestMooPoints();
            case 4:
                return user.getGamesPlayed();
            default:
                return user.getZombiesKilled();
        }
    }

    @Override
    protected void build(Table body) {
        Table picker = new Table();
        for (int i = 0; i < COLUMNS.length; i++) {
            final int index = i;
            picker.add(button(COLUMNS[i] + (column == i ? (ascending ? "  ^" : "  v") : ""),
                    new Runnable() {
                        @Override
                        public void run() {
                            if (column == index) ascending = !ascending;
                            else {
                                column = index;
                                ascending = false;
                            }
                            rebuild();
                        }
                    })).width(180f).padRight(6f).padBottom(6f);
            if (i == 2) picker.row();
        }
        body.add(picker).left().padBottom(12f).row();

        List<User> users = new ArrayList<>();
        try {
            users.addAll(game.auth().getAllUsers());
        } catch (Exception e) {
            say("Could not read the account list: " + e.getMessage());
        }
        if (users.isEmpty() && game.user() != null) users.add(game.user());

        final int sortColumn = column;
        Collections.sort(users, new Comparator<User>() {
            @Override
            public int compare(User a, User b) {
                return Integer.compare(valueOf(a, sortColumn), valueOf(b, sortColumn));
            }
        });
        if (!ascending) Collections.reverse(users);

        Table table = new Table();
        table.add(new Label("#", game.skin(), "medium")).left().padRight(18f);
        table.add(new Label("Player", game.skin(), "medium")).left().padRight(24f);
        for (String name : COLUMNS) {
            table.add(new Label(name, game.skin(), "medium")).left().padRight(20f);
        }
        table.row();

        int rank = 1;
        for (User user : users) {
            boolean me = game.user() != null && user.getUsername().equals(game.user().getUsername());

            Label rankLabel = new Label(String.valueOf(rank), game.skin(), "default");
            Label nameLabel = new Label(user.getNickname() == null ? user.getUsername() : user.getNickname(),
                    game.skin(), me ? "medium" : "default");
            if (me) nameLabel.setColor(1f, 0.9f, 0.4f, 1f);

            table.add(rankLabel).left().padRight(18f).padBottom(3f);
            table.add(nameLabel).left().padRight(24f).padBottom(3f);
            for (int i = 0; i < COLUMNS.length; i++) {
                table.add(new Label(String.valueOf(valueOf(user, i)), game.skin(), "default"))
                        .left().padRight(20f).padBottom(3f);
            }
            table.row();
            rank++;
        }

        body.add(table).left().row();
    }
}
