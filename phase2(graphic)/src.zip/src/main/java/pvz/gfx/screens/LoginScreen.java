package pvz.gfx.screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.ui.TextField;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.Scaling;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import pvz.gfx.Layout;
import pvz.gfx.PvzGame;
import pvz.gfx.art.Backdrops;
import pvz.model.auth.User;

public class LoginScreen implements Screen {

    private final PvzGame game;

    private Viewport viewport;
    private Stage stage;
    private TextField userField;
    private TextField passField;
    private Label message;
    private boolean stayLoggedIn;
    private TextButton stayButton;

    public LoginScreen(PvzGame game) {
        this.game = game;
    }

    @Override
    public void show() {
        viewport = new FitViewport(Layout.WORLD_W, Layout.WORLD_H);
        stage = new Stage(viewport, game.batch());
        Gdx.input.setInputProcessor(stage);

        addBackground();
        addSunflowers();

        userField = new TextField("", game.skin());
        userField.setMessageText("username");
        passField = new TextField("", game.skin());
        passField.setMessageText("password");
        passField.setPasswordMode(true);
        passField.setPasswordCharacter('*');
        message = new Label("", game.skin(), "default");
        message.setColor(1f, 0.7f, 0.4f, 1f);

        Table root = new Table();
        root.setFillParent(true);
        root.pad(24f);
        stage.addActor(root);

        Label title = new Label("Plants vs. Zombies 2", game.skin(), "big");
        Label subtitle = new Label("Log in", game.skin(), "default");

        stayButton = new TextButton("Stay logged in: OFF", game.skin(), "purple");
        stayButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                stayLoggedIn = !stayLoggedIn;
                stayButton.setText("Stay logged in: " + (stayLoggedIn ? "ON" : "OFF"));
            }
        });

        TextButton loginButton = new TextButton("Log in", game.skin(), "green");
        loginButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                attemptLogin();
            }
        });

        TextButton forgotPasswordButton = new TextButton("Forgot password?", game.skin(), "brown");
        forgotPasswordButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                game.setScreen(new ForgotPasswordScreen(game));
            }
        });

        TextButton registerButton = new TextButton("Create account", game.skin(), "brown");
        registerButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                game.setScreen(new RegisterScreen(game));
            }
        });

        TextButton quitButton = new TextButton("Quit", game.skin(), "brown");
        quitButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                Gdx.app.exit();
            }
        });

        root.add(title).padBottom(6f).row();
        root.add(subtitle).padBottom(22f).row();
        root.add(userField).width(360f).height(44f).padBottom(10f).row();
        root.add(passField).width(360f).height(44f).padBottom(10f).row();
        root.add(forgotPasswordButton).width(360f).height(36f).padBottom(10f).row();
        root.add(stayButton).width(360f).height(40f).padBottom(14f).row();
        root.add(loginButton).width(360f).height(48f).padBottom(10f).row();
        root.add(registerButton).width(360f).height(44f).padBottom(10f).row();
        root.add(quitButton).width(360f).height(40f).padBottom(14f).row();
        root.add(message).width(360f).row();
    }

    private void addBackground() {
        TextureRegion region = Backdrops.first(game.art(),
                Backdrops.MENU_TUTORIAL, Backdrops.MENU_WEST, Backdrops.MENU_BEACH,
                Backdrops.MENU_EGYPT, Backdrops.MENU_PIRATE);
        if (region != null) {
            Image background = new Image(new TextureRegionDrawable(region));
            background.setFillParent(true);
            background.setScaling(Scaling.fill);
            stage.addActor(background);
        }

        TextureRegion pixel = game.art().pixel();
        if (pixel != null) {
            Image shade = new Image(new TextureRegionDrawable(pixel));
            shade.setFillParent(true);
            shade.setColor(0f, 0f, 0f, region != null ? 0.45f : 0.30f);
            stage.addActor(shade);
        }
    }

    private void addSunflowers() {
        float size = 190f;
        float margin = 70f;

        SunflowerActor left = new SunflowerActor(game, size);
        left.setPosition(margin, margin);
        stage.addActor(left);

        SunflowerActor right = new SunflowerActor(game, size);
        right.setPosition(Layout.WORLD_W - margin - size, margin);
        stage.addActor(right);
    }

    private void attemptLogin() {
        String username = userField.getText().trim();
        String password = passField.getText();
        if (username.isEmpty() || password.isEmpty()) {
            message.setText("Enter both username and password.");
            return;
        }
        User user = game.auth().login(username, password, stayLoggedIn);
        if (user == null) {
            message.setText("Invalid username or password.");
            return;
        }
        game.onUserLoggedIn(user);
        game.setScreen(new MainMenuScreen(game));
    }

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(0.10f, 0.16f, 0.10f, 1f);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        game.art().update();
        stage.act(delta);
        stage.draw();
    }

    @Override
    public void resize(int width, int height) {
        viewport.update(width, height, true);
    }

    @Override
    public void pause() {
    }

    @Override
    public void resume() {
    }

    @Override
    public void hide() {
        Gdx.input.setInputProcessor(null);
    }

    @Override
    public void dispose() {
        if (stage != null) stage.dispose();
    }
}
