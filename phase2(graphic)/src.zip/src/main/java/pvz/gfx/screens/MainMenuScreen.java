package pvz.gfx.screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.CheckBox;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.ScrollPane;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.Scaling;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import pvz.gfx.Layout;
import pvz.gfx.PvzGame;
import pvz.gfx.actors.SeedCardActor;
import pvz.gfx.art.Backdrops;
import pvz.model.auth.Collection;
import pvz.model.auth.GameProgress;
import pvz.model.auth.UserSettings;
import pvz.model.enums.PlantType;
import pvz.model.session.LevelSpec;

public class MainMenuScreen implements Screen {

    private enum Panel {
        MAIN,
        CHAPTERS,
        SETTINGS,
        COLLECTION
    }

    private final PvzGame game;

    private Viewport viewport;
    private Stage stage;
    private Table root;

    private Panel panel = Panel.MAIN;
    private Table bgLayer;

    public MainMenuScreen(PvzGame game) {
        this.game = game;
    }

    @Override
    public void show() {
        viewport = new FitViewport(Layout.WORLD_W, Layout.WORLD_H);
        stage = new Stage(viewport, game.batch());
        Gdx.input.setInputProcessor(stage);

        root = new Table();
        root.setFillParent(true);
        root.pad(24f);
        stage.addActor(root);

        boolean musicOn = game.user() == null || game.user().getSettings().isMusicOn();
        game.music().play("main_menu", musicOn);

        showPanel(Panel.MAIN);
    }

    private void showPanel(Panel next) {
        panel = next;
        root.clear();
        root.top();
        showMenuBackground(panel == Panel.MAIN);

        switch (panel) {
            case CHAPTERS:
                root.add(header("Adventure")).left().row();
                root.add(buildChapters()).expand().fill().row();
                root.add(backButton(Panel.MAIN)).left().padTop(12f);
                break;
            case SETTINGS: {

                ScrollPane settingsPane = new ScrollPane(buildSettings(), game.skin());
                settingsPane.setFadeScrollBars(false);
                settingsPane.setScrollingDisabled(true, false);
                root.add(header("Settings")).left().row();
                root.add(settingsPane).expand().fill().row();
                root.add(backButton(Panel.MAIN)).left().padTop(12f);
                break;
            }
            case COLLECTION:
                root.add(header("Collection")).left().row();
                root.add(buildCollection()).expand().fill().row();
                root.add(backButton(Panel.MAIN)).left().padTop(12f);
                break;
            case MAIN:
            default:
                root.center();
                root.add(buildMain()).expand().fill();
                break;
        }
    }

    private Label header(String text) {
        return new Label(text, game.skin(), "big");
    }

    private TextButton backButton(final Panel target) {
        TextButton back = new TextButton("Back", game.skin(), "brown");
        back.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                showPanel(target);
            }
        });
        return back;
    }

    private Table buildMain() {
        Table table = new Table();

        table.add(buildWalletBar()).growX().padTop(4f).padBottom(10f).row();

        Table center = new Table();
        center.add(new Label("Plants vs Zombies 2", game.skin(), "big")).padBottom(4f).row();
        center.add(new Label("Welcome ," + game.user().getNickname(), game.skin(), "default"))
                .padBottom(18f).row();

        if (!game.art().usingRealAssets()) {
            Label notice = new Label(
                    "Running on placeholder art. Set pvz.assets in gradle.properties to load real animations.",
                    game.skin(), "default");
            notice.setColor(1f, 0.85f, 0.4f, 1f);
            center.add(notice).padBottom(16f).row();
        }

        TextButton adventure = new TextButton("Adventure", game.skin(), "green");
        adventure.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                game.setScreen(new ChaptersScreen(game));
            }
        });
        TextButton collection = new TextButton("Collection", game.skin(), "green");
        collection.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                game.setScreen(new AlmanacScreen(game));
            }
        });
        Table primary = new Table();
        primary.add(adventure).width(300f).height(64f).pad(6f);
        primary.add(collection).width(300f).height(64f).pad(6f);
        center.add(primary).padBottom(12f).row();

        Table menus = new Table();
        menus.add(navButton("Shop", "shop")).width(200f).pad(4f);
        menus.add(navButton("Greenhouse", "greenhouse")).width(200f).pad(4f);
        menus.add(navButton("Mini-games", "minigames")).width(200f).pad(4f).row();
        menus.add(navButton("Travel log", "travel")).width(200f).pad(4f);
        menus.add(navButton("Leaderboard", "leaderboard")).width(200f).pad(4f);
        menus.add(navButton("News (" + game.news().unreadCount() + ")", "news")).width(200f).pad(4f).row();
        center.add(menus).padBottom(12f).row();

        TextButton quickPlay = new TextButton("Quick play (1-1)", game.skin(), "green");
        quickPlay.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                game.setScreen(new PlantSelectScreen(game, LevelSpec.adventure(1, 1)));
            }
        });
        center.add(quickPlay).width(300f).padBottom(8f).row();

        TextButton onlineBtn = new TextButton("Online (2P)", game.skin(), "purple");
        onlineBtn.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                game.setScreen(new OpponentSelectScreen(game, 1));
            }
        });
        TextButton couchBtn = new TextButton("Couch Play (2P)", game.skin(), "purple");
        couchBtn.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                game.setScreen(new IZombieCouchScreen(game, 1));
            }
        });
        Table multiplayer = new Table();
        multiplayer.add(onlineBtn).width(196f).height(52f).pad(4f);
        multiplayer.add(couchBtn).width(196f).height(52f).pad(4f);
        center.add(multiplayer).padBottom(12f).row();

        TextButton exit = new TextButton("Save and quit", game.skin(), "brown");
        exit.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                game.save();
                Gdx.app.exit();
            }
        });
        center.add(exit).width(300f).row();

        table.add(center).expand().center().row();

        table.add(buildBottomBar()).growX().padTop(10f).padBottom(4f);
        return table;
    }

    private Table buildWalletBar() {
        Table bar = new Table();
        bar.left();
        bar.add(currencyChip(Backdrops.COIN, game.user().getCoins())).padRight(20f);
        bar.add(currencyChip(Backdrops.SUN, game.user().getPlantFoods())).padRight(20f);
        bar.add(currencyChip(Backdrops.GEM, game.user().getGems()));
        return bar;
    }

    private Table currencyChip(String iconId, int amount) {
        Table chip = new Table();
        TextureRegion region = game.art().region(iconId);
        if (region == null) region = game.art().placeholder(iconId, 44, 44, true);
        Image icon = new Image(new TextureRegionDrawable(region));
        icon.setScaling(Scaling.fit);
        chip.add(icon).size(44f, 44f).padRight(6f);

        Table box = new Table();
        TextureRegion pixel = game.art().pixel();
        if (pixel != null) {
            box.setBackground(new TextureRegionDrawable(pixel).tint(new Color(0f, 0f, 0f, 0.5f)));
        }
        box.pad(6f, 14f, 6f, 14f);
        box.add(new Label(String.valueOf(amount), game.skin(), "medium"));
        chip.add(box);
        return chip;
    }

    private Table buildBottomBar() {
        Table bar = new Table();
        bar.add(iconButton(Backdrops.SETTINGS_ICON, "Settings", new Runnable() {
            @Override
            public void run() {
                showPanel(Panel.SETTINGS);
            }
        })).padRight(48f);
        bar.add(iconButton(Backdrops.PROFILE_ICON, "Profile", new Runnable() {
            @Override
            public void run() {
                game.setScreen(new ProfileScreen(game));
            }
        }));
        return bar;
    }

    private Table iconButton(String iconId, String label, final Runnable action) {
        Table wrap = new Table();
        TextureRegion region = game.art().region(iconId);
        if (region == null) region = game.art().placeholder(label, 84, 84, true);
        Image icon = new Image(new TextureRegionDrawable(region));
        icon.setScaling(Scaling.fit);
        wrap.add(icon).size(84f, 84f).row();
        wrap.add(new Label(label, game.skin(), "default")).padTop(4f);
        wrap.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                action.run();
            }
        });
        return wrap;
    }

    private void showMenuBackground(boolean on) {
        if (bgLayer != null) {
            bgLayer.setVisible(on);
            return;
        }
        if (!on) return;

        bgLayer = new Table();
        bgLayer.setFillParent(true);
        TextureRegion region = Backdrops.first(game.art(),
                Backdrops.LAWN_CENTER, Backdrops.EGYPT_CENTER, Backdrops.MENU_FUTURE);
        if (region != null) {
            Image bg = new Image(new TextureRegionDrawable(region));
            bg.setScaling(Scaling.fill);
            bg.setFillParent(true);
            bgLayer.addActor(bg);
        }
        TextureRegion pixel = game.art().pixel();
        if (pixel != null) {
            Image dim = new Image(new TextureRegionDrawable(pixel));
            dim.setFillParent(true);
            dim.setColor(0f, 0f, 0f, 0.45f);
            bgLayer.addActor(dim);
        }
        stage.addActor(bgLayer);
        bgLayer.toBack();
    }

    private TextButton navButton(String text, final String target) {
        TextButton button = new TextButton(text, game.skin(), "purple");
        button.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                if ("shop".equals(target)) game.setScreen(new ShopScreen(game));
                else if ("greenhouse".equals(target)) game.setScreen(new GreenhouseScreen(game));
                else if ("travel".equals(target)) game.setScreen(new TravelLogScreen(game));
                else if ("minigames".equals(target)) game.setScreen(new MiniGameHubScreen(game));
                else if ("profile".equals(target)) game.setScreen(new ProfileScreen(game));
                else if ("leaderboard".equals(target)) game.setScreen(new LeaderboardScreen(game));
                else if ("news".equals(target)) game.setScreen(new NewsScreen(game));
            }
        });
        return button;
    }

    private TextButton menuButton(String text, final Panel target) {
        TextButton button = new TextButton(text, game.skin(), "default");
        button.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                showPanel(target);
            }
        });
        return button;
    }

    private ScrollPane buildChapters() {
        Table grid = new Table();
        grid.top().left();

        GameProgress progress = game.user().getProgress();

        for (int chapter = 1; chapter <= GameProgress.CHAPTERS; chapter++) {
            grid.add(new Label("Chapter " + chapter, game.skin(), "default")).left().padTop(10f).row();

            Table row = new Table();
            row.left();
            for (int level = 1; level <= GameProgress.LEVELS_PER_CHAPTER; level++) {
                final LevelSpec spec = LevelSpec.adventure(chapter, level);

                boolean unlocked = progress.isLevelUnlocked(spec.getId());
                boolean cleared = progress.isLevelCleared(spec.getId());

                String label = level + (cleared ? " (done)" : "");
                TextButton button = new TextButton(label, game.skin(),
                        cleared ? "green_small" : "brown");
                button.setDisabled(!unlocked);

                if (unlocked) {
                    button.addListener(new ClickListener() {
                        @Override
                        public void clicked(InputEvent event, float x, float y) {
                            game.setScreen(new PlantSelectScreen(game, spec));
                        }
                    });
                }
                row.add(button).width(140f).height(52f).padRight(8f);

                Label mode = new Label(String.valueOf(spec.getLevelType()), game.skin(), "default");
                mode.setFontScale(0.7f);
                row.add(mode).padRight(18f);
            }
            grid.add(row).left().row();
        }

        ScrollPane pane = new ScrollPane(grid, game.skin());
        pane.setFadeScrollBars(false);
        return pane;
    }

    private Table buildSettings() {
        Table table = new Table();
        table.top().left();

        table.add(new Label("Game speed", game.skin(), "default")).left().padBottom(6f).row();

        Table speeds = new Table();
        speeds.left();
        for (int i = 1; i <= 3; i++) {
            final int speed = i;
            TextButton button = new TextButton(i + "x", game.skin(),
                    game.gameSpeed() == i ? "green" : "brown");
            button.addListener(new ClickListener() {
                @Override
                public void clicked(InputEvent event, float x, float y) {
                    game.setGameSpeed(speed);
                    showPanel(Panel.SETTINGS);
                }
            });
            speeds.add(button).width(90f).padRight(8f);
        }
        table.add(speeds).left().padBottom(18f).row();

        final UserSettings settings = game.user().getSettings();

        table.add(section("Difficulty")).left().padBottom(6f).row();

        Table diffs = new Table();
        diffs.left();
        for (int i = 1; i <= 5; i++) {
            final int level = i;
            TextButton button = new TextButton(i + "  " + DIFFICULTY_NAMES[i - 1], game.skin(),
                    settings.getDifficulty() == i ? "green" : "brown");
            button.addListener(new ClickListener() {
                @Override
                public void clicked(InputEvent event, float x, float y) {
                    settings.changeDifficulty(level);
                    game.save();
                    showPanel(Panel.SETTINGS);
                }
            });
            diffs.add(button).width(148f).padRight(8f);
        }
        table.add(diffs).left().padBottom(4f).row();

        Label diffHint = new Label("Zombie health and damage x" + settings.getDifficultyMultiplier()
                + "   -   applies to the next level you start", game.skin(), "default");
        diffHint.setFontScale(0.8f);
        diffHint.setColor(0.8f, 0.8f, 0.8f, 1f);
        table.add(diffHint).left().padBottom(18f).row();

        table.add(section("Audio")).left().padBottom(6f).row();

        final CheckBox music = new CheckBox(" Music", game.skin());
        music.setChecked(settings.isMusicOn());
        music.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                settings.setMusicOn(music.isChecked());
                game.music().setEnabled(music.isChecked());
                game.save();
            }
        });
        table.add(music).left().padBottom(8f).row();

        final CheckBox sfx = new CheckBox(" Sound effects", game.skin());
        sfx.setChecked(settings.isSfxOn());
        sfx.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                settings.setSfxOn(sfx.isChecked());
                game.save();
            }
        });
        table.add(sfx).left().padBottom(18f).row();

        table.add(section("Display")).left().padBottom(6f).row();

        final CheckBox grid = new CheckBox(" Show lawn grid lines", game.skin());
        grid.setChecked(game.showGrid());
        grid.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                game.setShowGrid(grid.isChecked());
            }
        });
        table.add(grid).left().padBottom(18f).row();

        table.add(section("Developer")).left().padBottom(6f).row();

        final CheckBox debug = new CheckBox(" Debug mode (reveals cheats)", game.skin());
        debug.setChecked(game.debugMode());
        debug.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                game.setDebugMode(debug.isChecked());
                game.save();
                showPanel(Panel.SETTINGS);
            }
        });
        table.add(debug).left().padBottom(10f).row();

        if (game.debugMode()) {
            Table cheats = new Table();
            cheats.left();
            cheats.add(cheatButton("+1000 coins", 1000, 0, false)).padRight(8f);
            cheats.add(cheatButton("+100 gems", 0, 100, false)).padRight(8f);
            cheats.add(cheatButton("+1 plant food", 0, 0, true));
            table.add(cheats).left().padBottom(8f).row();

            Label wallet = new Label("Coins: " + game.user().getCoins()
                    + "      Gems: " + game.user().getGems()
                    + "      Plant food: " + game.user().getPlantFoods(),
                    game.skin(), "default");
            wallet.setFontScale(0.85f);
            table.add(wallet).left().padBottom(8f).row();

            Label inGame = new Label(
                    "In game, debug mode also adds sun, plant food, instant recharge and zombie spawning.",
                    game.skin(), "default");
            inGame.setFontScale(0.8f);
            inGame.setColor(0.8f, 0.8f, 0.8f, 1f);
            table.add(inGame).left().padBottom(18f).row();
        }

        Label hint = new Label(
                "In game: Esc pauses, G toggles the grid, Space starts the waves, 1/2/3 set the speed.",
                game.skin(), "default");
        hint.setFontScale(0.85f);
        table.add(hint).left();
        return table;
    }

    private static final String[] DIFFICULTY_NAMES = {
            "Relaxed", "Easy", "Normal", "Hard", "Brutal"
    };

    private Label section(String text) {
        Label label = new Label(text, game.skin(), "medium");
        label.setColor(1f, 0.88f, 0.45f, 1f);
        return label;
    }

    private TextButton cheatButton(String label, final int coins, final int gems,
                                   final boolean plantFood) {
        TextButton button = new TextButton(label, game.skin(), "purple");
        button.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                if (coins > 0) game.user().addCoins(coins);
                if (gems > 0) game.user().addGems(gems);
                if (plantFood) game.user().addPlantFood();
                game.save();
                showPanel(Panel.SETTINGS);
            }
        });
        return button;
    }

    private ScrollPane buildCollection() {
        Table grid = new Table();
        grid.top().left();

        Collection collection = game.user().getCollection();
        int column = 0;

        for (PlantType type : PlantType.values()) {
            boolean unlocked = collection.isPlantUnlocked(type);

            SeedCardActor card = new SeedCardActor(game.art(), game.pam(), game.skin(), type, SeedCardActor.Mode.COLLECTION);
            card.setLocked(!unlocked);
            card.setLevel(unlocked ? collection.getPlantLevel(type) : 0);
            card.setBoosted(game.boostedPlants().contains(type));

            grid.add(card).size(SeedCardActor.CARD_W, SeedCardActor.CARD_H).pad(4f);
            if (++column % 12 == 0) grid.row();
        }

        ScrollPane pane = new ScrollPane(grid, game.skin());
        pane.setFadeScrollBars(false);
        pane.setScrollingDisabled(true, false);
        return pane;
    }

    @Override
    public void render(float delta) {
        game.art().update();
        Gdx.gl.glClearColor(0.12f, 0.20f, 0.13f, 1f);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        stage.act(delta);
        stage.draw();
    }

    @Override
    public void resize(int width, int height) {
        viewport.update(width, height, true);
    }

    @Override
    public void pause() {
    }

    @Override
    public void resume() {
    }

    @Override
    public void hide() {
        Gdx.input.setInputProcessor(null);
    }

    @Override
    public void dispose() {
        if (stage != null) stage.dispose();
    }
}
