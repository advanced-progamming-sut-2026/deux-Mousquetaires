package pvz.gfx.screens;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Stack;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.Scaling;
import pvz.gfx.PvzGame;
import pvz.gfx.art.Backdrops;
import pvz.gfx.art.PamCatalog;
import pvz.model.enums.MiniGameType;
import pvz.model.enums.PlantType;
import pvz.model.enums.ZombieType;

public class MiniGameHubScreen extends PanelScreen {

    public MiniGameHubScreen(PvzGame game) {
        super(game);
    }

    @Override
    protected String title() {
        return "Mini-games";
    }

    @Override
    protected String[] backdrops() {
        return new String[]{Backdrops.MENU_WEST, Backdrops.MENU_EGYPT, Backdrops.MENU_TUTORIAL};
    }

    @Override
    protected void build(Table body) {
        body.add(sectionLabel("Clear a level to earn 100 x level coins, a progress unlock and a headline."))
                .left().padBottom(14f).row();

        for (final MiniGameType type : MiniGameType.values()) {
            body.add(gameCard(type)).growX().padBottom(16f).row();
        }
    }

    private Stack gameCard(final MiniGameType type) {
        Color accent = accent(type);

        Stack stack = new Stack();
        Image panel = new Image(new TextureRegionDrawable(game.art().pixel()));
        panel.setColor(accent.r * 0.22f, accent.g * 0.22f, accent.b * 0.22f, 0.82f);
        stack.add(panel);

        Table card = new Table();
        card.pad(12f).left();

        Stack art = new Stack();
        TextureRegion plate = game.art().region(plate(type));
        if (plate != null) {
            Image thumb = new Image(new TextureRegionDrawable(plate));
            thumb.setScaling(Scaling.fill);
            art.add(thumb);
        } else {
            Image fill = new Image(new TextureRegionDrawable(game.art().pixel()));
            fill.setColor(accent.r * 0.4f, accent.g * 0.4f, accent.b * 0.4f, 1f);
            art.add(fill);
        }
        Table rigWrap = new Table();
        rigWrap.add(icon(type)).size(96f, 116f).center();
        art.add(rigWrap);
        card.add(art).size(190f, 120f).padRight(16f);

        Table text = new Table();
        text.left();
        Label name = new Label(MiniGames.label(type), game.skin(), "medium");
        name.setColor(accent);
        Label blurb = new Label(MiniGames.blurb(type), game.skin(), "default");
        blurb.setWrap(true);
        Label reward = new Label("Reward: 100 x level coins", game.skin(), "default");
        reward.setFontScale(0.75f);
        reward.setColor(1f, 0.9f, 0.5f, 1f);
        text.add(name).left().row();
        text.add(blurb).width(430f).left().padTop(4f).row();
        text.add(reward).left().padTop(6f).row();
        card.add(text).left().expandX().top();

        Table levels = new Table();
        for (int level = 1; level <= 3; level++) {
            final int chosen = level;
            TextButton button = new TextButton("Level " + level, game.skin(), "green");
            button.addListener(new ClickListener() {
                @Override
                public void clicked(InputEvent event, float x, float y) {
                    game.setScreen(MiniGames.screen(game, type, chosen));
                }
            });
            levels.add(button).width(130f).height(46f).padBottom(6f).row();
        }
        card.add(levels).right().padLeft(12f);

        stack.add(card);
        return stack;
    }

    private RigActor icon(MiniGameType type) {
        if (type == MiniGameType.I_ZOMBIE) {
            ZombieType zombie = ZombieType.BASIC;
            return new RigActor(game.art(), game.pam().zombiePam(zombie),
                    game.pam().zombieClip(zombie, PamCatalog.Clip.IDLE), null, zombie.name());
        }
        PlantType plant;
        switch (type) {
            case WALLNUT_BOWLING: plant = PlantType.WALL_NUT; break;
            case BEGHOULED: plant = PlantType.SUNFLOWER; break;
            case VASEBREAKER: plant = PlantType.POTATO_MINE; break;
            case ZOMBOTANY:
            default: plant = PlantType.PEASHOOTER; break;
        }
        return new RigActor(game.art(), game.pam().plantPam(plant),
                game.pam().plantClip(plant, PamCatalog.Clip.IDLE), null, plant.name());
    }

    private String plate(MiniGameType type) {
        switch (type) {
            case VASEBREAKER: return Backdrops.MENU_EGYPT;
            case WALLNUT_BOWLING: return Backdrops.MENU_TUTORIAL;
            case I_ZOMBIE: return Backdrops.MENU_DARKAGES;
            case BEGHOULED: return Backdrops.MENU_WEST;
            case ZOMBOTANY:
            default: return Backdrops.MENU_BEACH;
        }
    }

    private Color accent(MiniGameType type) {
        switch (type) {
            case VASEBREAKER: return new Color(1f, 0.85f, 0.35f, 1f);
            case WALLNUT_BOWLING: return new Color(0.6f, 1f, 0.6f, 1f);
            case I_ZOMBIE: return new Color(0.78f, 0.6f, 0.95f, 1f);
            case BEGHOULED: return new Color(0.95f, 0.65f, 0.4f, 1f);
            case ZOMBOTANY:
            default: return new Color(0.4f, 0.9f, 0.95f, 1f);
        }
    }
}
