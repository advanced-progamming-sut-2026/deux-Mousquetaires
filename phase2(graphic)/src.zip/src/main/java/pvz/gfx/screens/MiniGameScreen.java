package pvz.gfx.screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.Align;
import com.badlogic.gdx.utils.viewport.FitViewport;
import pvz.gfx.Layout;
import pvz.gfx.PvzGame;
import pvz.gfx.art.Backdrops;
import pvz.gfx.art.CompositeZombies;
import pvz.gfx.art.PamCatalog;
import pvz.model.auth.User;
import pvz.model.enums.MiniGameType;
import pvz.model.enums.PlantType;
import pvz.model.enums.ZombieType;
import pvz.model.minigame.MiniGame;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

public abstract class MiniGameScreen implements Screen {

    protected static final int ROWS = 5;
    protected static final int COLS = 9;
    protected static final float BOARD_X = 210f;
    protected static final float BOARD_Y = 140f;
    protected static final float CELL_W = 106f;
    protected static final float CELL_H = 96f;

    protected static final float PLANT_HEIGHT = 86f;
    protected static final float ZOMBIE_HEIGHT = 108f;

    protected final PvzGame game;
    protected final MiniGameType type;
    protected final int level;
    protected final MiniGame mini;

    protected Stage stage;
    protected float time;

    private final List<Actor> zones = new ArrayList<>();
    private Label banner;
    private Label stats;
    private Table bar;
    private Table overlay;

    private ByteArrayOutputStream buffer;
    private PrintStream previousOut;
    private PrintStream captured;

    private float tickClock;
    private boolean rewarded;
    private boolean started;

    protected MiniGameScreen(PvzGame game, MiniGameType type, int level, MiniGame mini) {
        this.game = game;
        this.type = type;
        this.level = Math.max(1, Math.min(3, level));
        this.mini = mini;
    }

    protected abstract String gameTitle();

    protected abstract String statusLine();

    protected abstract void drawBoard(float delta);

    protected abstract void buildControls(Table controls);

    protected float tickInterval() {
        return 0f;
    }

    protected String[] backdrops() {
        return new String[]{Backdrops.LAWN_CENTER, Backdrops.EGYPT_CENTER};
    }

    @Override
    public void show() {
        stage = new Stage(new FitViewport(Layout.WORLD_W, Layout.WORLD_H), game.batch());
        Gdx.input.setInputProcessor(stage);

        buildHud();

        if (!started) {
            started = true;
            capture();
            try {
                mini.start();
            } finally {
                release();
            }
            showCaptured();
        }
        refresh();
    }

    private void buildHud() {
        bar = new Table();
        bar.bottom().left();
        bar.setFillParent(true);
        bar.pad(12f);
        stage.addActor(bar);

        banner = new Label("", game.skin(), "default");
        banner.setWrap(true);
        banner.setAlignment(Align.topLeft);
        banner.setColor(1f, 0.95f, 0.7f, 1f);
        banner.setBounds(24f, Layout.WORLD_H - 150f, 470f, 132f);
        stage.addActor(banner);

        stats = new Label("", game.skin(), "medium");
        stats.setBounds(24f, Layout.WORLD_H - 52f, 900f, 32f);
        stage.addActor(stats);
    }

    protected void refresh() {
        for (Actor zone : zones) zone.remove();
        zones.clear();

        bar.clear();
        Table controls = new Table();
        buildControls(controls);
        bar.add(controls).left().row();

        Table footer = new Table();
        TextButton quit = new TextButton("Give up", game.skin(), "brown");
        quit.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                send("quit");
            }
        });
        TextButton leave = new TextButton("Back to mini-games", game.skin(), "brown");
        leave.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                leave();
            }
        });
        footer.add(quit).width(150f).padRight(10f);
        footer.add(leave).width(240f);
        bar.add(footer).left().padTop(8f);

        if (stats != null) stats.setText(gameTitle() + "  (level " + level + ")     " + statusLine());
    }

    protected void send(String command) {
        if (mini.isGameover()) return;

        capture();
        try {
            mini.handle(command);
        } catch (Exception e) {
            Gdx.app.error("MiniGame", "Command failed: " + command, e);
        } finally {
            release();
        }
        showCaptured();
        refresh();

        if (mini.isGameover()) finish();
    }

    private void capture() {
        buffer = new ByteArrayOutputStream();
        try {
            captured = new PrintStream(buffer, true, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            captured = new PrintStream(buffer, true);
        }
        previousOut = System.out;
        System.setOut(captured);
    }

    private void release() {
        if (previousOut != null) System.setOut(previousOut);
        previousOut = null;
        if (captured != null) captured.flush();
    }

    private void showCaptured() {
        if (buffer == null || banner == null) return;
        String text = buffer.toString();
        String[] lines = text.split("\\r?\\n");

        StringBuilder tail = new StringBuilder();
        int kept = 0;
        for (int i = lines.length - 1; i >= 0 && kept < 5; i--) {
            String line = lines[i].trim();
            if (line.isEmpty() || line.startsWith("Commands:")) continue;
            tail.insert(0, line + "\n");
            kept++;
        }
        if (tail.length() > 0) banner.setText(tail.toString().trim());
    }

    private void finish() {
        if (rewarded) return;
        rewarded = true;

        String message;
        User user = game.user();
        if (mini.isWon() && user != null) {
            int coins = 100 * mini.getLevel();
            user.addCoins(coins);
            user.recordMiniGameCompleted();
            String name = type.name().toLowerCase().replace('_', '-');
            user.getProgress().unlockMiniGame(name);
            game.quests().onEvent("minigame_completed", 1);
            game.news().publish("Mini-game victory!",
                    user.getUsername() + " finished " + name + " level " + mini.getLevel()
                            + " and earned " + coins + " coins.");
            message = "Victory!  +" + coins + " coins";
        } else {
            message = mini.isWon() ? "Victory!" : "Defeat";
        }
        game.save();
        showResult(message);
    }

    private void showResult(String headline) {
        if (overlay != null) overlay.remove();

        overlay = new Table();
        overlay.setFillParent(true);
        overlay.center();

        TextureRegion pixel = game.art().pixel();
        if (pixel != null) {
            Image shade = new Image(new TextureRegionDrawable(pixel));
            shade.setFillParent(true);
            shade.setColor(0f, 0f, 0f, 0.6f);
            stage.addActor(shade);
        }

        Label title = new Label(headline, game.skin(), "big");
        overlay.add(title).padBottom(18f).row();

        TextButton again = new TextButton("Play again", game.skin(), "green");
        again.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                game.setScreen(MiniGames.screen(game, type, level));
            }
        });
        overlay.add(again).width(260f).padBottom(10f).row();

        TextButton leave = new TextButton("Back to mini-games", game.skin(), "brown");
        leave.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                leave();
            }
        });
        overlay.add(leave).width(260f).row();

        stage.addActor(overlay);
    }

    protected void leave() {
        game.save();
        game.setScreen(new MiniGameHubScreen(game));
    }

    protected float cellX(int col) {
        return BOARD_X + (col - 1) * CELL_W;
    }

    protected float cellY(int row) {
        return BOARD_Y + (ROWS - row) * CELL_H;
    }

    protected float cellCenterX(float col) {
        return BOARD_X + (col - 0.5f) * CELL_W;
    }

    protected float cellCenterY(float row) {
        return BOARD_Y + (ROWS - row + 0.5f) * CELL_H;
    }

    protected float smoothX(int columnTimesTen) {
        return BOARD_X + (columnTimesTen / 10f - 0.5f) * CELL_W;
    }

    protected void drawBackground(SpriteBatch batch) {
        boolean drawn = Backdrops.drawCover(batch, game.art(), 0f, 0f, Layout.WORLD_W, Layout.WORLD_H,
                backdrops()[0], Backdrops.LAWN_LEFT, Backdrops.LAWN_RIGHT);
        if (!drawn) {
            fill(batch, 0f, 0f, Layout.WORLD_W, Layout.WORLD_H, 0.16f, 0.36f, 0.16f, 1f);
        }
    }

    protected void drawGrid(SpriteBatch batch) {
        for (int row = 1; row <= ROWS; row++) {
            for (int col = 1; col <= COLS; col++) {
                float shade = ((row + col) % 2 == 0) ? 0.16f : 0.10f;
                fill(batch, cellX(col), cellY(row), CELL_W - 2f, CELL_H - 2f, 0f, shade, 0f, 0.35f);
            }
        }
    }

    protected void fill(SpriteBatch batch, float x, float y, float width, float height,
                        float r, float g, float b, float a) {
        TextureRegion pixel = game.art().pixel();
        if (pixel == null) return;
        batch.setColor(r, g, b, a);
        batch.draw(pixel, x, y, width, height);
        batch.setColor(1f, 1f, 1f, 1f);
    }

    protected void drawRegion(SpriteBatch batch, String id, float x, float y, float width, float height) {
        TextureRegion region = game.art().region(id);
        if (region == null) return;
        batch.draw(region, x, y, width, height);
    }

    protected void drawPlant(SpriteBatch batch, PlantType plant, float centerX, float footY, float height) {
        if (plant != null) {
            String pam = game.pam().plantPam(plant);
            String clip = game.pam().plantClip(plant, PamCatalog.Clip.IDLE);
            if (game.art().drawFitted(batch, pam, clip, time, centerX, footY, height, true, null)) return;
        }
        TextureRegion swatch = game.art().placeholder(plant == null ? "plant" : plant.name(),
                (int) (height * 0.8f), (int) height, true);
        if (swatch != null) batch.draw(swatch, centerX - height * 0.4f, footY, height * 0.8f, height);
    }

    protected void drawZombie(SpriteBatch batch, ZombieType zombie, float centerX, float footY, float height) {
        if (zombie != null && CompositeZombies.isComposite(zombie)) {
            CompositeZombies.draw(game.art(), game.pam(), batch, zombie,
                    game.pam().zombieClip(zombie, PamCatalog.Clip.WALK), time, centerX, footY, height);
            return;
        }
        if (zombie != null) {
            String pam = game.pam().zombiePam(zombie);
            String clip = game.pam().zombieClip(zombie, PamCatalog.Clip.WALK);
            if (game.art().drawFitted(batch, pam, clip, time, centerX, footY, height, true, null)) return;
        }
        TextureRegion swatch = game.art().placeholder(zombie == null ? "zombie" : zombie.name(),
                (int) (height * 0.6f), (int) height, false);
        if (swatch != null) batch.draw(swatch, centerX - height * 0.3f, footY, height * 0.6f, height);
    }

    protected void clickZone(float x, float y, float width, float height, final Runnable action) {
        Actor zone = new Actor();
        zone.setBounds(x, y, width, height);
        zone.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float px, float py) {
                action.run();
            }
        });
        stage.addActor(zone);
        zones.add(zone);
    }

    protected Label caption(String text, float x, float y, float width) {
        Label label = new Label(text, game.skin(), "default");
        label.setAlignment(Align.center);
        label.setBounds(x, y, width, 24f);
        stage.addActor(label);
        zones.add(label);
        return label;
    }

    protected TextButton controlButton(String text, String style, final Runnable action) {
        TextButton button = new TextButton(text, game.skin(), style);
        button.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                action.run();
            }
        });
        return button;
    }

    @Override
    public void render(float delta) {
        float scaled = delta * Math.max(1, game.gameSpeed());
        time += scaled;

        Gdx.gl.glClearColor(0.08f, 0.16f, 0.09f, 1f);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        game.art().update();

        float interval = tickInterval();
        if (interval > 0f && !mini.isGameover()) {
            tickClock += scaled;
            while (tickClock >= interval && !mini.isGameover()) {
                tickClock -= interval;
                send("advance 1");
            }
        }

        SpriteBatch batch = game.batch();
        batch.setProjectionMatrix(stage.getViewport().getCamera().combined);
        batch.begin();
        drawBackground(batch);
        drawBoard(scaled);
        batch.end();

        if (stats != null) stats.setText(gameTitle() + "  (level " + level + ")     " + statusLine());

        stage.act(delta);
        stage.draw();
    }

    @Override
    public void resize(int width, int height) {
        stage.getViewport().update(width, height, true);
    }

    @Override
    public void pause() {
    }

    @Override
    public void resume() {
    }

    @Override
    public void hide() {
        release();
        Gdx.input.setInputProcessor(null);
    }

    @Override
    public void dispose() {
        release();
        if (stage != null) stage.dispose();
    }
}
