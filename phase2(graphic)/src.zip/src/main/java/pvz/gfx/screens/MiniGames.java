package pvz.gfx.screens;

import com.badlogic.gdx.Screen;
import pvz.gfx.PvzGame;
import pvz.model.enums.MiniGameType;

public final class MiniGames {

    private MiniGames() {
    }

    public static Screen screen(PvzGame game, MiniGameType type, int level) {
        switch (type) {
            case BEGHOULED:
                return new BeghouledScreen(game, level);
            case VASEBREAKER:
                return new VasebreakerScreen(game, level);
            case WALLNUT_BOWLING:
                return new BowlingScreen(game, level);
            case ZOMBOTANY:
                return new ZombotanyScreen(game, level);
            case I_ZOMBIE:
                return new IZombieScreen(game, level);
            default:
                return new MiniGameHubScreen(game);
        }
    }

    public static String label(MiniGameType type) {
        switch (type) {
            case BEGHOULED:
                return "Beghouled";
            case VASEBREAKER:
                return "Vasebreaker";
            case WALLNUT_BOWLING:
                return "Wall-nut Bowling";
            case ZOMBOTANY:
                return "Zombotany";
            case I_ZOMBIE:
                return "I, Zombie";
            default:
                return type.name();
        }
    }

    public static String blurb(MiniGameType type) {
        switch (type) {
            case BEGHOULED:
                return "Swap neighbouring plants to line up three and farm sun.";
            case VASEBREAKER:
                return "Break the vases. Zombies hide in some, seed packets in others.";
            case WALLNUT_BOWLING:
                return "Roll nuts down the lanes and bowl the horde over.";
            case ZOMBOTANY:
                return "Plant-headed zombies walk in. Defend with your own plants.";
            case I_ZOMBIE:
                return "Play the other side: buy zombies and eat all five brains.";
            default:
                return "";
        }
    }

    public static String key(MiniGameType type) {
        return type.name().toLowerCase().replace('_', '-');
    }
}
