package pvz.gfx.screens;

import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import pvz.gfx.PvzGame;
import pvz.gfx.art.Backdrops;
import pvz.model.news.News;

import java.time.format.DateTimeFormatter;
import java.util.List;

public class NewsScreen extends PanelScreen {

    private static final DateTimeFormatter STAMP = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    public NewsScreen(PvzGame game) {
        super(game);
    }

    @Override
    protected String title() {
        return "News  (" + game.news().unreadCount() + " unread)";
    }

    @Override
    protected String[] backdrops() {
        return new String[]{Backdrops.MENU_PIRATE, Backdrops.MENU_TUTORIAL, Backdrops.MENU_EGYPT};
    }

    @Override
    protected void build(Table body) {
        List<News> all = game.news().getAll();

        if (all.isEmpty()) {
            body.add(new Label("No headlines yet. Win a level or a mini-game and come back.",
                    game.skin(), "default")).left().row();
            return;
        }

        body.add(button("Mark everything as read", new Runnable() {
            @Override
            public void run() {
                for (News news : game.news().getAll()) news.markAsRead();
                game.save();
                say("All headlines marked as read.");
                rebuild();
            }
        })).width(320f).left().padBottom(12f).row();

        for (int i = all.size() - 1; i >= 0; i--) {
            final News news = all.get(i);
            body.add(item(news)).growX().padBottom(10f).row();
        }
    }

    private Table item(final News news) {
        Table row = new Table();

        Table text = new Table();
        Label title = new Label((news.isRead() ? "" : "NEW   ") + news.getTitle(), game.skin(), "medium");
        if (!news.isRead()) title.setColor(1f, 0.9f, 0.4f, 1f);

        Label content = new Label(news.getContent(), game.skin(), "default");
        content.setWrap(true);

        String stamp = news.getPublishDate() == null ? "" : news.getPublishDate().format(STAMP);
        Label date = new Label(stamp, game.skin(), "default");
        date.setColor(0.8f, 0.8f, 0.8f, 1f);

        text.add(title).left().row();
        text.add(date).left().padTop(2f).row();
        text.add(content).width(620f).left().padTop(4f).row();

        row.add(text).left().expandX();

        if (!news.isRead()) {
            row.add(button("Mark read", new Runnable() {
                @Override
                public void run() {
                    news.markAsRead();
                    game.save();
                    rebuild();
                }
            })).width(180f).right();
        }
        return row;
    }
}
