package pvz.gfx.screens;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.Actor;
import pvz.gfx.PvzGame;

public class NpcPortraitActor extends Actor {

    private final PvzGame game;
    private final String pam;
    private final String clip;
    private final String fallbackKey;
    private float time;

    public NpcPortraitActor(PvzGame game, String pam, String clip, String fallbackKey, float size) {
        this.game = game;
        this.pam = pam;
        this.clip = clip;
        this.fallbackKey = fallbackKey;
        setSize(size, size);
    }

    @Override
    public void act(float delta) {
        super.act(delta);
        time += delta;
    }

    @Override
    public void draw(Batch batch, float parentAlpha) {
        float w = getWidth();
        float h = getHeight();
        float footX = getX() + w / 2f;
        float footY = getY();

        Color prev = batch.getColor().cpy();
        batch.setColor(1f, 1f, 1f, parentAlpha * getColor().a);

        boolean drawn = pam != null
                && game.art().drawFitted(batch, pam, clip, time, footX, footY, h, true, null);

        if (!drawn) {
            TextureRegion region = game.art().placeholder(fallbackKey, (int) w, (int) h, true);
            if (region != null) {
                batch.draw(region, getX(), getY(), w, h);
            }
        }

        batch.setColor(prev);
    }
}
