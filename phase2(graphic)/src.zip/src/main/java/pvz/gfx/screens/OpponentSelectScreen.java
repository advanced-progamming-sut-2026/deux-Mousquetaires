package pvz.gfx.screens;

import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.ui.TextField;
import pvz.gfx.PvzGame;
import pvz.gfx.art.Backdrops;
import pvz.network.GameClient;
import pvz.network.NetProtocol;

public class OpponentSelectScreen extends PanelScreen {

    private final int level;

    private TextField hostField;
    private TextField portField;
    private TextField userField;
    private TextField passField;
    private TextField nicknameField;
    private TextField emailField;
    private TextField challengeField;

    private boolean connected;
    private boolean loggedIn;
    private String incomingChallenger;
    private boolean waitingInQueue;

    private final GameClient.Listener listener = new GameClient.Listener() {
        @Override
        public void onMessage(final String type, final String[] fields) {
            com.badlogic.gdx.Gdx.app.postRunnable(new Runnable() {
                @Override
                public void run() {
                    handleMessage(type, fields);
                }
            });
        }

        @Override
        public void onDisconnected() {
            com.badlogic.gdx.Gdx.app.postRunnable(new Runnable() {
                @Override
                public void run() {
                    connected = false;
                    loggedIn = false;
                    say("Disconnected from server.");
                    rebuild();
                }
            });
        }
    };

    public OpponentSelectScreen(PvzGame game, int level) {
        super(game);
        this.level = level;
        this.connected = game.netClient().isConnected();
    }

    @Override
    public void show() {
        super.show();
        game.netClient().addListener(listener);
    }

    @Override
    public void hide() {
        super.hide();
        game.netClient().removeListener(listener);
    }

    @Override
    protected String title() {
        return "Online I, Zombie - Opponent Select";
    }

    @Override
    protected String[] backdrops() {
        return new String[]{Backdrops.MENU_DARKAGES, Backdrops.MENU_TUTORIAL};
    }

    private void handleMessage(String type, String[] f) {
        if (NetProtocol.S2C_REGISTER_OK.equals(type)) {
            say("Registered as " + NetProtocol.field(f, 0) + ". You can now log in.");
        } else if (NetProtocol.S2C_REGISTER_ERR.equals(type)) {
            say("Registration failed: " + NetProtocol.field(f, 0));
        } else if (NetProtocol.S2C_LOGIN_OK.equals(type)) {
            loggedIn = true;
            say("Logged in as " + NetProtocol.field(f, 0) + ".");
            rebuild();
        } else if (NetProtocol.S2C_LOGIN_ERR.equals(type)) {
            say("Login failed: " + NetProtocol.field(f, 0));
        } else if (NetProtocol.S2C_CHALLENGE_INCOMING.equals(type)) {
            incomingChallenger = NetProtocol.field(f, 0);
            rebuild();
        } else if (NetProtocol.S2C_CHALLENGE_DECLINED.equals(type)) {
            say(NetProtocol.field(f, 0) + " declined your challenge.");
        } else if (NetProtocol.S2C_CHALLENGE_OFFLINE.equals(type)) {
            say(NetProtocol.field(f, 0) + " is not online right now.");
        } else if (NetProtocol.S2C_CHALLENGE_INVALID.equals(type)) {
            say("No such username: " + NetProtocol.field(f, 0));
        } else if (NetProtocol.S2C_QUEUE_WAITING.equals(type)) {
            waitingInQueue = true;
            say("Waiting for a random opponent...");
        } else if (NetProtocol.S2C_MATCH_START.equals(type)) {
            waitingInQueue = false;
            game.setScreen(new IZombieOnlineScreen(game, level, NetProtocol.field(f, 0), NetProtocol.field(f, 1)));
        }
    }

    @Override
    protected void build(Table body) {
        body.add(sectionLabel("1) Connect to the game server (loopback address works without internet)."))
                .left().padBottom(6f).row();

        Table connectRow = new Table();
        hostField = new TextField(connected ? "connected" : "localhost", game.skin());
        portField = new TextField(String.valueOf(NetProtocol.DEFAULT_PORT), game.skin());
        connectRow.add(new Label("Host", game.skin(), "default")).padRight(6f);
        connectRow.add(hostField).width(220f).padRight(12f);
        connectRow.add(new Label("Port", game.skin(), "default")).padRight(6f);
        connectRow.add(portField).width(100f).padRight(12f);
        connectRow.add(button(connected ? "Connected" : "Connect", new Runnable() {
            @Override
            public void run() {
                doConnect();
            }
        })).width(160f);
        body.add(connectRow).left().padBottom(16f).row();

        if (!connected) return;

        body.add(sectionLabel("2) Register or log in with your server account (username must be unique)."))
                .left().padBottom(6f).row();

        Table account = new Table();
        userField = new TextField("", game.skin());
        passField = new TextField("", game.skin());
        passField.setPasswordMode(true);
        passField.setPasswordCharacter('*');
        nicknameField = new TextField("", game.skin());
        emailField = new TextField("", game.skin());
        account.add(new Label("Username", game.skin(), "default")).padRight(6f);
        account.add(userField).width(200f).padRight(12f);
        account.add(new Label("Password", game.skin(), "default")).padRight(6f);
        account.add(passField).width(200f).row();
        account.add(new Label("Nickname", game.skin(), "default")).padRight(6f).padTop(6f);
        account.add(nicknameField).width(200f).padRight(12f).padTop(6f);
        account.add(new Label("Email", game.skin(), "default")).padRight(6f).padTop(6f);
        account.add(emailField).width(200f).padTop(6f).row();
        body.add(account).left().padBottom(10f).row();

        Table accountButtons = new Table();
        accountButtons.add(button("Register", new Runnable() {
            @Override
            public void run() {
                game.netClient().register(userField.getText().trim(), passField.getText(),
                        nicknameField.getText().trim(), emailField.getText().trim(), "PREFER_NOT_TO_SAY");
            }
        })).width(150f).padRight(10f);
        accountButtons.add(button("Log in", new Runnable() {
            @Override
            public void run() {
                game.netClient().login(userField.getText().trim(), passField.getText());
            }
        })).width(150f);
        body.add(accountButtons).left().padBottom(20f).row();

        if (!loggedIn) return;

        if (incomingChallenger != null) {
            body.add(sectionLabel(incomingChallenger + " is challenging you to a duel!"))
                    .left().padBottom(6f).row();
            Table challengeButtons = new Table();
            challengeButtons.add(button("Accept", new Runnable() {
                @Override
                public void run() {
                    game.netClient().acceptChallenge();
                    incomingChallenger = null;
                }
            })).width(150f).padRight(10f);
            challengeButtons.add(button("Reject", new Runnable() {
                @Override
                public void run() {
                    game.netClient().rejectChallenge();
                    incomingChallenger = null;
                    rebuild();
                }
            })).width(150f);
            body.add(challengeButtons).left().padBottom(20f).row();
        }

        body.add(sectionLabel("3) Challenge a specific online player, or join the random queue."))
                .left().padBottom(6f).row();

        Table challengeRow = new Table();
        challengeField = new TextField("", game.skin());
        challengeRow.add(new Label("Username", game.skin(), "default")).padRight(6f);
        challengeRow.add(challengeField).width(200f).padRight(12f);
        challengeRow.add(button("Send challenge", new Runnable() {
            @Override
            public void run() {
                game.netClient().challenge(challengeField.getText().trim());
                say("Challenge sent to " + challengeField.getText().trim() + ".");
            }
        })).width(180f);
        body.add(challengeRow).left().padBottom(10f).row();

        body.add(button(waitingInQueue ? "Leave queue" : "Join random queue", new Runnable() {
            @Override
            public void run() {
                if (waitingInQueue) {
                    game.netClient().leaveQueue();
                    waitingInQueue = false;
                    say("Left the queue.");
                } else {
                    game.netClient().joinQueue();
                }
                rebuild();
            }
        })).width(220f).left().row();
    }

    private void doConnect() {
        try {
            int port = Integer.parseInt(portField.getText().trim());
            game.netClient().connect(hostField.getText().trim(), port);
            connected = true;
            say("Connected to " + hostField.getText().trim() + ":" + port + ".");
            rebuild();
        } catch (Exception e) {
            say("Could not connect: " + e.getMessage());
        }
    }
}
