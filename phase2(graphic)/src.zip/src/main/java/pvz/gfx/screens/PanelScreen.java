package pvz.gfx.screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.ScrollPane;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.Align;
import com.badlogic.gdx.utils.Scaling;
import com.badlogic.gdx.utils.viewport.FitViewport;
import pvz.gfx.Layout;
import pvz.gfx.PvzGame;
import pvz.gfx.art.Backdrops;
import pvz.model.auth.User;

public abstract class PanelScreen implements Screen {

    protected final PvzGame game;

    protected Stage stage;
    protected Table root;

    private Label status;
    private Label wallet;
    private String pendingMessage;

    protected PanelScreen(PvzGame game) {
        this.game = game;
    }

    protected abstract String title();

    protected abstract void build(Table body);

    protected String[] backdrops() {
        return new String[]{Backdrops.MENU_TUTORIAL, Backdrops.MENU_EGYPT, Backdrops.MENU_WEST,
                Backdrops.MENU_PIRATE, Backdrops.MENU_BEACH};
    }

    @Override
    public void show() {
        stage = new Stage(new FitViewport(Layout.WORLD_W, Layout.WORLD_H), game.batch());
        Gdx.input.setInputProcessor(stage);

        addBackground();

        root = new Table();
        root.setFillParent(true);
        root.pad(20f).top();
        stage.addActor(root);

        rebuild();
    }

    private void addBackground() {
        TextureRegion region = Backdrops.first(game.art(), backdrops());
        if (region != null) {
            Image image = new Image(new TextureRegionDrawable(region));
            image.setFillParent(true);
            image.setScaling(Scaling.fill);
            stage.addActor(image);
        }

        TextureRegion pixel = game.art().pixel();
        if (pixel != null) {
            Image shade = new Image(new TextureRegionDrawable(pixel));
            shade.setFillParent(true);
            shade.setColor(0f, 0f, 0f, region != null ? 0.45f : 0.72f);
            stage.addActor(shade);
        }
    }

    protected void rebuild() {
        root.clear();

        Label heading = new Label(title(), game.skin(), "big");
        wallet = new Label(walletText(), game.skin(), "default");
        wallet.setAlignment(Align.right);

        Table header = new Table();
        header.add(heading).left().expandX();
        header.add(wallet).right();
        root.add(header).growX().padBottom(12f).row();

        Table body = new Table();
        body.top();
        build(body);

        ScrollPane scroll = new ScrollPane(body, game.skin());
        scroll.setFadeScrollBars(false);
        scroll.setScrollingDisabled(true, false);
        root.add(scroll).grow().row();

        status = new Label(pendingMessage == null ? "" : pendingMessage, game.skin(), "default");
        status.setWrap(true);
        status.setColor(1f, 0.93f, 0.6f, 1f);
        root.add(status).growX().padTop(10f).row();

        TextButton back = new TextButton("Back to menu", game.skin(), "brown");
        back.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                back();
            }
        });
        root.add(back).width(240f).padTop(10f).row();
    }

    protected void back() {
        game.save();
        game.setScreen(new MainMenuScreen(game));
    }

    protected void say(String message) {
        pendingMessage = message;
        if (status != null) status.setText(message == null ? "" : message);
    }

    protected void refreshWallet() {
        if (wallet != null) wallet.setText(walletText());
    }

    protected String walletText() {
        User user = game.user();
        if (user == null) return "";
        return "Coins " + user.getCoins()
                + "   Gems " + user.getGems()
                + "   Pots " + user.getPots() + "/" + User.MAX_POTS
                + "   Plant food " + user.getPlantFoods() + "/" + User.MAX_PLANT_FOOD;
    }

    protected Label sectionLabel(String text) {
        Label label = new Label(text, game.skin(), "medium");
        label.setColor(1f, 0.9f, 0.5f, 1f);
        return label;
    }

    protected TextButton button(String text, final Runnable action) {
        TextButton button = new TextButton(text, game.skin(), "purple");
        button.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                action.run();
            }
        });
        return button;
    }

    protected void popup(String title, String message) {
        showModal(title, message, "OK", null, null, null);
    }

    protected void confirm(String title, String message, String confirmText, final Runnable onConfirm) {
        showModal(title, message, confirmText, "Cancel", onConfirm, null);
    }

    private void showModal(String title, String message, String okText, String cancelText,
                           final Runnable onOk, final Runnable onCancel) {
        final Table veil = new Table();
        veil.setFillParent(true);
        veil.center();
        veil.setTouchable(com.badlogic.gdx.scenes.scene2d.Touchable.enabled);

        TextureRegion pixel = game.art().pixel();
        if (pixel != null) {
            Image dim = new Image(new TextureRegionDrawable(pixel));
            dim.setFillParent(true);
            dim.setColor(0f, 0f, 0f, 0.6f);
            veil.addActor(dim);
        }

        Table box = new Table();
        if (pixel != null) {
            box.setBackground(new TextureRegionDrawable(pixel)
                    .tint(new com.badlogic.gdx.graphics.Color(0.10f, 0.16f, 0.12f, 0.98f)));
        }
        box.pad(24f);
        if (title != null) box.add(new Label(title, game.skin(), "big")).padBottom(10f).row();
        Label body = new Label(message == null ? "" : message, game.skin(), "default");
        body.setWrap(true);
        body.setAlignment(Align.center);
        box.add(body).width(460f).padBottom(18f).row();

        Table buttons = new Table();
        TextButton ok = new TextButton(okText == null ? "OK" : okText, game.skin(), "green");
        ok.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                veil.remove();
                if (onOk != null) onOk.run();
            }
        });
        buttons.add(ok).width(180f).pad(6f);
        if (cancelText != null) {
            TextButton cancel = new TextButton(cancelText, game.skin(), "brown");
            cancel.addListener(new ClickListener() {
                @Override
                public void clicked(InputEvent event, float x, float y) {
                    veil.remove();
                    if (onCancel != null) onCancel.run();
                }
            });
            buttons.add(cancel).width(180f).pad(6f);
        }
        box.add(buttons);

        veil.add(box);
        stage.addActor(veil);
    }

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(0.07f, 0.13f, 0.09f, 1f);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        game.art().update();
        stage.act(delta);
        stage.draw();
    }

    @Override
    public void resize(int width, int height) {
        stage.getViewport().update(width, height, true);
    }

    @Override
    public void pause() {
    }

    @Override
    public void resume() {
    }

    @Override
    public void hide() {
        Gdx.input.setInputProcessor(null);
    }

    @Override
    public void dispose() {
        if (stage != null) stage.dispose();
    }
}
