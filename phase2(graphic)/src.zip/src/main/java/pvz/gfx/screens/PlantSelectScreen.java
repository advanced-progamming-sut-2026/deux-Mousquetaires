package pvz.gfx.screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.ScrollPane;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.utils.Align;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import pvz.gfx.Layout;
import pvz.gfx.PvzGame;
import pvz.gfx.actors.SeedCardActor;
import pvz.model.auth.Collection;
import pvz.model.enums.PlantType;
import pvz.model.session.LevelSpec;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class PlantSelectScreen implements Screen {

    private final PvzGame game;
    private final LevelSpec spec;

    private Viewport viewport;
    private Stage stage;

    private Table slotRow;
    private Label warningLabel;
    private Label boostStatusLabel;
    private TextButton rockButton;

    private final List<PlantType> chosen = new ArrayList<>();
    private final List<SeedCardActor> slots = new ArrayList<>();

    private Set<PlantType> boosted;

    public PlantSelectScreen(PvzGame game, LevelSpec spec) {
        this.game = game;
        this.spec = spec;
    }

    @Override
    public void show() {
        boosted = game.boostedPlants();

        viewport = new FitViewport(Layout.WORLD_W, Layout.WORLD_H);
        stage = new Stage(viewport, game.batch());
        Gdx.input.setInputProcessor(stage);

        for (PlantType forced : spec.getForcedPlants()) {
            if (!chosen.contains(forced) && chosen.size() < PvzGame.SEED_SLOTS) chosen.add(forced);
        }

        Table root = new Table();
        root.setFillParent(true);
        root.pad(18f);
        root.top();

        root.add(buildBriefing()).expandX().left().row();
        root.add(buildSlotRow()).expandX().left().padTop(10f).row();
        root.add(buildPlantGrid()).expand().fill().padTop(10f).row();
        root.add(buildFooter()).expandX().right().padTop(10f).row();

        stage.addActor(root);
        refresh();
    }

    private Table buildBriefing() {
        Table table = new Table();
        table.left();

        String title = spec.isConveyor()
                ? "Conveyor level -- seeds arrive on the belt"
                : "Choose your plants";

        Label heading = new Label(title, game.skin(), "big");

        StringBuilder mission = new StringBuilder();
        mission.append("World: ").append(spec.getWorld())
                .append("   Mode: ").append(spec.getLevelType())
                .append("   Waves: ").append(spec.getWaveCount());
        if (spec.getTimeLimitSeconds() > 0) mission.append("   Time: ").append(spec.getTimeLimitSeconds()).append("s");
        if (spec.getKillTarget() > 0) mission.append("   Kill target: ").append(spec.getKillTarget());
        if (spec.getDeadlineColumn() > 0) mission.append("   Deadline column: ").append(spec.getDeadlineColumn());
        if (spec.getMaxPlantLosses() > 0) mission.append("   Plants you may lose: ").append(spec.getMaxPlantLosses());
        if (!spec.isSunProducersAllowed()) mission.append("   No sun producers!");
        if (spec.getRewardPlant() != null) mission.append("   Reward: ").append(spec.getRewardPlant());

        Label detail = new Label(mission.toString(), game.skin(), "default");
        detail.setWrap(true);

        table.add(heading).left().row();
        table.add(detail).width(1100f).left().padTop(4f);
        return table;
    }

    private Table buildSlotRow() {
        Table wrap = new Table();
        wrap.left();

        slotRow = new Table();
        slotRow.left();
        rebuildSlots();

        boostStatusLabel = new Label("", game.skin(), "default");
        boostStatusLabel.setColor(1f, 0.85f, 0.25f, 1f);

        wrap.add(slotRow).left().row();
        wrap.add(boostStatusLabel).left().padTop(4f);
        return wrap;
    }

    private void rebuildSlots() {
        slotRow.clearChildren();
        slots.clear();

        for (int i = 0; i < PvzGame.SEED_SLOTS; i++) {
            final PlantType type = i < chosen.size() ? chosen.get(i) : null;
            SeedCardActor card = new SeedCardActor(art(), game.pam(), game.skin(), type, SeedCardActor.Mode.SELECT);
            card.setBoosted(type != null && boosted.contains(type));

            if (type != null) card.setLevel(game.user().getCollection().getPlantLevel(type));

            if (type != null && !spec.getForcedPlants().contains(type)) {
                card.addListener(new ClickListener() {
                    @Override
                    public void clicked(InputEvent event, float x, float y) {
                        chosen.remove(type);
                        rebuildSlots();
                        refresh();
                    }
                });
            }
            slots.add(card);
            slotRow.add(card).size(SeedCardActor.CARD_W, SeedCardActor.CARD_H).padRight(6f);
        }
    }

    private ScrollPane buildPlantGrid() {
        Table grid = new Table();
        grid.top().left();

        Collection collection = game.user().getCollection();
        int column = 0;

        for (final PlantType type : PlantType.values()) {
            if (!collection.isPlantUnlocked(type)) continue;

            final boolean lockedByLevel = spec.getLockedPlants().contains(type);

            SeedCardActor card = new SeedCardActor(art(), game.pam(), game.skin(), type, SeedCardActor.Mode.COLLECTION);
            card.setBoosted(boosted.contains(type));
            card.setLevel(collection.getPlantLevel(type));
            card.setLocked(lockedByLevel);

            if (!lockedByLevel) {
                card.addListener(new ClickListener() {
                    @Override
                    public void clicked(InputEvent event, float x, float y) {
                        pick(type);
                    }
                });
            } else {

                card.addListener(new ClickListener() {
                    @Override
                    public void clicked(InputEvent event, float x, float y) {
                        warn(type + " is locked for this level.");
                    }
                });
            }

            grid.add(card).size(SeedCardActor.CARD_W, SeedCardActor.CARD_H).pad(4f);
            if (++column % 12 == 0) grid.row();
        }

        ScrollPane pane = new ScrollPane(grid, game.skin());
        pane.setFadeScrollBars(false);
        pane.setScrollingDisabled(true, false);
        return pane;
    }

    private void pick(PlantType type) {
        if (chosen.contains(type)) {
            warn("That plant is already in your seed bank.");
            return;
        }
        if (chosen.size() >= PvzGame.SEED_SLOTS) {
            warn("All " + PvzGame.SEED_SLOTS + " seed slots are full. Remove one first.");
            return;
        }
        chosen.add(type);
        warn("");
        rebuildSlots();
        refresh();
    }

    private Table buildFooter() {
        Table table = new Table();

        warningLabel = new Label("", game.skin(), "default");
        warningLabel.setColor(1f, 0.35f, 0.3f, 1f);
        warningLabel.setAlignment(Align.right);

        TextButton back = new TextButton("Back", game.skin(), "brown");
        back.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                game.setScreen(new MainMenuScreen(game));
            }
        });

        rockButton = new TextButton("Let's Rock!", game.skin(), "green");
        rockButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                start();
            }
        });

        table.add(warningLabel).right().padRight(16f);
        table.add(back).width(160f).padRight(8f);
        table.add(rockButton).width(220f);
        return table;
    }

    private void start() {
        if (chosen.isEmpty() && !spec.isConveyor()) {
            warn("Pick at least one plant before you start.");
            return;
        }

        game.consumeBoostsFor(chosen);
        game.setScreen(new LawnScreen(game, spec, new ArrayList<>(chosen)));
    }

    private void warn(String message) {
        if (warningLabel != null) warningLabel.setText(message);
    }

    private void refresh() {
        if (rockButton != null) {
            rockButton.setDisabled(chosen.isEmpty() && !spec.isConveyor());
        }

        if (boostStatusLabel != null) {
            int boostedCount = 0;
            for (PlantType type : chosen) if (boosted.contains(type)) boostedCount++;
            if (boostedCount > 0) {
                boostStatusLabel.setText(boostedCount + " of " + chosen.size() + " chosen plants are boosted (gold card, extra power this level).");
            } else {
                boostStatusLabel.setText("Card number = upgrade level. Gold card = greenhouse boost active.");
            }
        }
    }

    private pvz.gfx.art.Art art() {
        return game.art();
    }

    @Override
    public void render(float delta) {
        game.art().update();
        Gdx.gl.glClearColor(0.16f, 0.28f, 0.16f, 1f);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        stage.act(delta);
        stage.draw();
    }

    @Override
    public void resize(int width, int height) {
        viewport.update(width, height, true);
    }

    @Override
    public void pause() {
    }

    @Override
    public void resume() {
    }

    @Override
    public void hide() {
        Gdx.input.setInputProcessor(null);
    }

    @Override
    public void dispose() {
        if (stage != null) stage.dispose();
    }
}
