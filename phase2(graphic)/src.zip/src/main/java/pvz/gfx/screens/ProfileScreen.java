package pvz.gfx.screens;

import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.ui.TextField;
import pvz.gfx.PvzGame;
import pvz.gfx.actors.SeedCardActor;
import pvz.gfx.art.Backdrops;
import pvz.model.auth.Collection;
import pvz.model.auth.User;
import pvz.model.enums.PlantType;

public class ProfileScreen extends PanelScreen {

    private TextField nickname;
    private TextField email;

    public ProfileScreen(PvzGame game) {
        super(game);
    }

    @Override
    protected String title() {
        return "Profile";
    }

    @Override
    protected String[] backdrops() {
        return new String[]{Backdrops.MENU_FUTURE, Backdrops.MENU_TUTORIAL, Backdrops.MENU_EGYPT};
    }

    @Override
    protected void build(Table body) {
        final User user = game.user();
        if (user == null) return;

        body.add(sectionLabel("Account")).left().padBottom(6f).row();

        Table account = new Table();
        account.add(new Label("Username", game.skin(), "default")).left().padRight(12f);
        account.add(new Label(user.getUsername(), game.skin(), "medium")).left().row();

        nickname = new TextField(user.getNickname() == null ? "" : user.getNickname(), game.skin());
        account.add(new Label("Nickname", game.skin(), "default")).left().padRight(12f).padTop(6f);
        account.add(nickname).width(320f).left().padTop(6f).row();

        email = new TextField(user.getEmail() == null ? "" : user.getEmail(), game.skin());
        account.add(new Label("Email", game.skin(), "default")).left().padRight(12f).padTop(6f);
        account.add(email).width(320f).left().padTop(6f).row();

        account.add(new Label("Gender", game.skin(), "default")).left().padRight(12f).padTop(6f);
        account.add(new Label(String.valueOf(user.getGender()), game.skin(), "default")).left().padTop(6f).row();

        body.add(account).left().padBottom(8f).row();

        body.add(button("Save account details", new Runnable() {
            @Override
            public void run() {
                save(user);
            }
        })).width(300f).left().padBottom(14f).row();

        body.add(sectionLabel("Records")).left().padBottom(6f).row();

        Table stats = new Table();
        stat(stats, "Games played", user.getGamesPlayed());
        stat(stats, "Mini-games completed", user.getMiniGamesCompleted());
        stat(stats, "Daily quests done", user.getDailyQuestsDone());
        stat(stats, "Other quests done", user.getOtherQuestsDone());
        stat(stats, "Zombies defeated", user.getZombiesKilled());
        stat(stats, "Best score", user.getBestMooPoints());
        stat(stats, "Coins", user.getCoins());
        stat(stats, "Gems", user.getGems());
        stat(stats, "Pots", user.getPots());
        stat(stats, "Plant food", user.getPlantFoods());
        body.add(stats).left().padBottom(14f).row();

        body.add(sectionLabel("Collection")).left().padBottom(6f).row();
        body.add(collection(user)).left().row();
    }

    private void stat(Table table, String name, int value) {
        table.add(new Label(name, game.skin(), "default")).left().padRight(24f).padBottom(3f);
        table.add(new Label(String.valueOf(value), game.skin(), "medium")).left().padBottom(3f).row();
    }

    private Table collection(User user) {
        Table strip = new Table();
        Collection collection = user.getCollection();
        int shown = 0;
        for (PlantType type : PlantType.values()) {
            if (!collection.isPlantUnlocked(type)) continue;
            Table cell = new Table();
            SeedCardActor card = new SeedCardActor(game.art(), game.pam(), game.skin(), type,
                    SeedCardActor.Mode.COLLECTION);
            cell.add(card).size(SeedCardActor.CARD_W, SeedCardActor.CARD_H).row();
            cell.add(new Label("lvl " + collection.getPlantLevel(type) + " / " + Collection.MAX_PLANT_LEVEL,
                    game.skin(), "default")).row();
            strip.add(cell).pad(4f);
            shown++;
            if (shown % 10 == 0) strip.row();
        }
        if (shown == 0) strip.add(new Label("No plants unlocked yet.", game.skin(), "default"));
        return strip;
    }

    private void save(User user) {
        String newNickname = nickname.getText().trim();
        String newEmail = email.getText().trim();

        if (!newNickname.isEmpty()) {
            String problem = game.auth().nicknameProblem(newNickname);
            if (problem != null) {
                popup("Invalid nickname", problem);
                return;
            }
        }
        if (!newEmail.isEmpty()) {
            String problem = game.auth().emailProblem(newEmail);
            if (problem != null) {
                popup("Invalid email", problem);
                return;
            }
        }

        if (!newNickname.isEmpty()) user.setNickname(newNickname);
        if (!newEmail.isEmpty()) user.setEmail(newEmail);
        game.save();
        rebuild();
        popup("Saved", "Your profile has been updated.");
    }
}
