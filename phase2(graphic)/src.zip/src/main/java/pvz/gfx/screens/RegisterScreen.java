package pvz.gfx.screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.ui.TextField;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import pvz.gfx.Layout;
import pvz.gfx.PvzGame;
import pvz.model.auth.SecurityQuestions;
import pvz.model.auth.User;
import pvz.model.enums.Gender;

public class RegisterScreen implements Screen {

    private final PvzGame game;

    private Viewport viewport;
    private Stage stage;
    private TextField userField;
    private TextField passField;
    private TextField confirmField;
    private TextField nickField;
    private TextField emailField;
    private TextField securityAnswerField;
    private Label message;
    private Gender gender = Gender.MALE;
    private TextButton genderButton;

    private int securityQuestionNumber = 1;
    private TextButton securityQuestionButton;

    public RegisterScreen(PvzGame game) {
        this.game = game;
    }

    @Override
    public void show() {
        viewport = new FitViewport(Layout.WORLD_W, Layout.WORLD_H);
        stage = new Stage(viewport, game.batch());
        Gdx.input.setInputProcessor(stage);

        userField = field("username", false);
        passField = field("password (min 8 chars)", true);
        confirmField = field("confirm password", true);
        nickField = field("nickname (3-30 chars)", false);
        emailField = field("email", false);
        securityAnswerField = field("security answer", false);
        message = new Label("", game.skin(), "default");
        message.setColor(1f, 0.7f, 0.4f, 1f);

        Table root = new Table();
        root.setFillParent(true);
        root.pad(24f);
        stage.addActor(root);

        Label title = new Label("Create account", game.skin(), "big");

        genderButton = new TextButton("Gender: MALE", game.skin(), "purple");
        genderButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                Gender[] all = Gender.values();
                gender = all[(gender.ordinal() + 1) % all.length];
                genderButton.setText("Gender: " + gender.name());
            }
        });

        securityQuestionButton = new TextButton(
                "Security question: " + SecurityQuestions.byNumber(securityQuestionNumber),
                game.skin(), "purple");
        securityQuestionButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                securityQuestionNumber = securityQuestionNumber % SecurityQuestions.count() + 1;
                securityQuestionButton.setText(
                        "Security question: " + SecurityQuestions.byNumber(securityQuestionNumber));
            }
        });

        TextButton createButton = new TextButton("Create & log in", game.skin(), "green");
        createButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                attemptRegister();
            }
        });

        TextButton backButton = new TextButton("Back to login", game.skin(), "brown");
        backButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                game.setScreen(new LoginScreen(game));
            }
        });

        root.add(title).padBottom(18f).row();
        root.add(userField).width(400f).height(40f).padBottom(8f).row();
        root.add(passField).width(400f).height(40f).padBottom(8f).row();
        root.add(confirmField).width(400f).height(40f).padBottom(8f).row();
        root.add(nickField).width(400f).height(40f).padBottom(8f).row();
        root.add(emailField).width(400f).height(40f).padBottom(8f).row();
        root.add(securityQuestionButton).width(400f).height(38f).padBottom(8f).row();
        root.add(securityAnswerField).width(400f).height(40f).padBottom(8f).row();
        root.add(genderButton).width(400f).height(38f).padBottom(12f).row();
        root.add(createButton).width(400f).height(46f).padBottom(8f).row();
        root.add(backButton).width(400f).height(40f).padBottom(12f).row();
        root.add(message).width(400f).row();
    }

    private TextField field(String hint, boolean password) {
        TextField textField = new TextField("", game.skin());
        textField.setMessageText(hint);
        if (password) {
            textField.setPasswordMode(true);
            textField.setPasswordCharacter('*');
        }
        return textField;
    }

    private void attemptRegister() {
        if (securityAnswerField.getText().trim().isEmpty()) {
            message.setText("Please answer the security question, so you can recover your password later.");
            return;
        }
        try {
            User user = game.auth().register(
                    userField.getText().trim(),
                    passField.getText(),
                    confirmField.getText(),
                    nickField.getText().trim(),
                    emailField.getText().trim(),
                    gender);
            game.auth().addSecurityQA(user,
                    SecurityQuestions.byNumber(securityQuestionNumber),
                    securityAnswerField.getText());
            game.onUserLoggedIn(user);
            game.setScreen(new MainMenuScreen(game));
        } catch (IllegalArgumentException ex) {
            message.setText(ex.getMessage());
        } catch (Throwable t) {
            message.setText("Could not register: " + t.getMessage());
        }
    }

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(0.10f, 0.16f, 0.10f, 1f);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        stage.act(delta);
        stage.draw();
    }

    @Override
    public void resize(int width, int height) {
        viewport.update(width, height, true);
    }

    @Override
    public void pause() {
    }

    @Override
    public void resume() {
    }

    @Override
    public void hide() {
        Gdx.input.setInputProcessor(null);
    }

    @Override
    public void dispose() {
        if (stage != null) stage.dispose();
    }
}
