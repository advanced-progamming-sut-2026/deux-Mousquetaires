package pvz.gfx.screens;

import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.Actor;
import pvz.gfx.art.Art;
import pvz.gfx.art.CompositeZombies;
import pvz.gfx.art.PamCatalog;
import pvz.model.enums.ZombieType;

public class RigActor extends Actor {

    private final Art art;
    private String pam;
    private String clip;
    private TextureRegion fallback;
    private final String label;

    private PamCatalog pamCatalog;
    private ZombieType compositeZombie;

    private float time;

    public RigActor(Art art, String pam, String clip, TextureRegion fallback, String label) {
        this.art = art;
        this.pam = pam;
        this.clip = clip;
        this.fallback = fallback;
        this.label = label == null ? "?" : label;
    }

    public RigActor(Art art, PamCatalog pamCatalog, ZombieType compositeZombie, String label) {
        this.art = art;
        this.pamCatalog = pamCatalog;
        this.compositeZombie = compositeZombie;
        this.label = label == null ? "?" : label;
    }

    @Override
    public void act(float delta) {
        super.act(delta);
        time += delta;
    }

    @Override
    public void draw(Batch batch, float parentAlpha) {
        float x = getX();
        float y = getY();
        float w = getWidth();
        float h = getHeight();
        float alpha = parentAlpha * getColor().a;

        if (compositeZombie != null) {
            batch.setColor(1f, 1f, 1f, alpha);
            float footX = x + w / 2f;
            float footY = y + 6f;
            CompositeZombies.draw(art, pamCatalog, batch, compositeZombie, "idle", time, footX, footY, h - 12f);
            batch.setColor(1f, 1f, 1f, 1f);
            return;
        }

        boolean drew = false;
        if (pam != null && art.usingRealAssets()) {
            batch.setColor(1f, 1f, 1f, alpha);
            float footX = x + w / 2f;
            float footY = y + 6f;
            drew = art.drawFitted(batch, pam, clip, time, footX, footY, h - 12f, true, null);
        }

        if (!drew) {
            TextureRegion region = fallback != null
                    ? fallback
                    : art.placeholder(label, (int) w, (int) h, false);
            if (region != null) {
                batch.setColor(1f, 1f, 1f, alpha);
                float rw = region.getRegionWidth();
                float rh = region.getRegionHeight();
                float scale = Math.min(w / rw, h / rh);
                float dw = rw * scale;
                float dh = rh * scale;
                batch.draw(region, x + (w - dw) / 2f, y + (h - dh) / 2f, dw, dh);
            }
        }

        batch.setColor(1f, 1f, 1f, 1f);
    }
}
