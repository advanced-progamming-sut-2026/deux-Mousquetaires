package pvz.gfx.screens;

import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.SelectBox;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.Scaling;
import pvz.gfx.PvzGame;
import pvz.gfx.actors.SeedCardActor;
import pvz.gfx.art.Backdrops;
import pvz.model.auth.Collection;
import pvz.model.auth.User;
import pvz.model.enums.PlantType;
import pvz.model.shop.ShopService;

public class ShopScreen extends PanelScreen {

    private SelectBox<String> plantPicker;

    public ShopScreen(PvzGame game) {
        super(game);
    }

    @Override
    protected String title() {
        return "Shop";
    }

    @Override
    protected String[] backdrops() {
        return new String[]{Backdrops.MENU_WEST, Backdrops.MENU_PIRATE, Backdrops.MENU_TUTORIAL};
    }

    @Override
    protected void build(Table body) {
        body.add(row("Garden pot", "2000 coins. You may own " + User.MAX_POTS + " at most.",
                "Buy pot", 1, 1, null, Backdrops.SHOP_POT)).growX().padBottom(10f).row();

        body.add(row("Plant food", "3 gems. Capped at " + User.MAX_PLANT_FOOD + " in storage.",
                "Buy plant food", 2, 1, null, Backdrops.PLANT_FOOD)).growX().padBottom(10f).row();

        body.add(row("Random seed bundle", "1000 coins for "
                        + ShopService.RANDOM_BUNDLE_PACKETS + " packets of a random unlocked plant.",
                "Buy bundle", 3, 1, null, Backdrops.SHOP_SEED_BUNDLE)).growX().padBottom(10f).row();

        body.add(chosenBundleRow()).growX().padBottom(10f).row();

        body.add(row("Gems to coins", ShopService.CONVERSION_PRICE_GEMS + " gems become "
                        + ShopService.CONVERSION_COINS + " coins.",
                "Convert", 5, 1, null, Backdrops.COIN)).growX().padBottom(10f).row();

        body.add(row("Daily offer", "Today's plant, " + ShopService.DAILY_PACKETS + " packets for "
                        + ShopService.DAILY_BASE_PRICE + " coins ("
                        + ShopService.DAILY_DISCOUNT_PRICE + " if you already own it). Once per day.",
                "Buy daily", 6, 1, null, Backdrops.SHOP_SEED_BUNDLE)).growX().padBottom(10f).row();

        body.add(sectionLabel("Your unlocked plants")).left().padTop(10f).padBottom(6f).row();
        body.add(collectionStrip()).left().row();
    }

    private Table row(String name, String detail, String action, final int itemId,
                      final int count, final PlantType chosen, String imageId) {
        Table row = new Table();

        Table text = new Table();
        Label title = new Label(name, game.skin(), "medium");
        Label body = new Label(detail, game.skin(), "default");
        body.setWrap(true);
        text.add(title).left().row();
        text.add(body).width(540f).left().padTop(2f).row();

        final String itemName = name;
        row.add(text).left().expandX();

        row.add(itemImage(imageId)).size(66f, 66f).right().padRight(12f);
        row.add(button(action, new Runnable() {
            @Override
            public void run() {
                confirmBuy(itemName, itemId, count, chosen);
            }
        })).width(190f).right();
        return row;
    }

    private Image itemImage(String id) {
        TextureRegion region = id == null ? null : game.art().region(id);
        if (region == null) region = game.art().placeholder(id == null ? "shop" : id, 66, 66, false);
        Image image = new Image(new TextureRegionDrawable(region));
        image.setScaling(Scaling.fit);
        return image;
    }

    private void confirmBuy(final String name, final int itemId, final int count, final PlantType chosen) {
        confirm("Confirm purchase", "Buy \"" + name + "\"?", "Buy", new Runnable() {
            @Override
            public void run() {
                buy(itemId, count, chosen);
            }
        });
    }

    private Table chosenBundleRow() {
        Table row = new Table();

        Array<String> names = new Array<>();
        Collection collection = game.user() == null ? null : game.user().getCollection();
        for (PlantType type : PlantType.values()) {
            if (collection == null || collection.isPlantUnlocked(type)) names.add(type.name());
        }
        if (names.size == 0) names.add("PEASHOOTER");

        plantPicker = new SelectBox<>(game.skin());
        plantPicker.setItems(names);

        Table text = new Table();
        text.add(new Label("Chosen seed bundle", game.skin(), "medium")).left().row();
        Label detail = new Label(ShopService.CHOSEN_BUNDLE_PRICE_GEMS + " gems for "
                + ShopService.CHOSEN_BUNDLE_PACKETS + " packets of the plant you pick.",
                game.skin(), "default");
        detail.setWrap(true);
        text.add(detail).width(540f).left().padTop(2f).row();
        text.add(plantPicker).width(300f).left().padTop(6f).row();

        row.add(text).left().expandX();
        row.add(itemImage(Backdrops.SHOP_SEED_BUNDLE)).size(66f, 66f).right().padRight(12f);
        row.add(button("Buy chosen", new Runnable() {
            @Override
            public void run() {
                confirmBuy("Chosen seed bundle: " + plantPicker.getSelected(), 4, 1,
                        PvzGame.byName(plantPicker.getSelected()));
            }
        })).width(190f).right();
        return row;
    }

    private Table collectionStrip() {
        Table strip = new Table();
        User user = game.user();
        if (user == null) return strip;

        Collection collection = user.getCollection();
        int shown = 0;
        for (PlantType type : PlantType.values()) {
            if (!collection.isPlantUnlocked(type)) continue;
            SeedCardActor card = new SeedCardActor(game.art(), game.pam(), game.skin(), type,
                    SeedCardActor.Mode.COLLECTION);
            strip.add(card).size(SeedCardActor.CARD_W, SeedCardActor.CARD_H).pad(4f);
            shown++;
            if (shown % 10 == 0) strip.row();
        }
        return strip;
    }

    private void buy(int itemId, int count, PlantType chosen) {
        User user = game.user();
        if (user == null) return;
        String message = game.shop().buy(user, itemId, count, chosen);
        game.save();
        say(message);
        refreshWallet();
        rebuild();
    }
}
