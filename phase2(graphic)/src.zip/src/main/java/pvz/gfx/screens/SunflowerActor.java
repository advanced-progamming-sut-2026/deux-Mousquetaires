package pvz.gfx.screens;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.Actor;
import pvz.gfx.PvzGame;
import pvz.gfx.art.Backdrops;
import pvz.gfx.art.PamCatalog;
import pvz.model.enums.PlantType;

public class SunflowerActor extends Actor {

    private final PvzGame game;
    private final String pam;
    private final String clip;
    private float time;

    public SunflowerActor(PvzGame game, float height) {
        this.game = game;
        PlantType sunflower = PvzGame.byName("SUNFLOWER");
        this.pam = sunflower == null ? null : game.pam().plantPam(sunflower);
        this.clip = sunflower == null ? null
                : game.pam().plantClip(sunflower, PamCatalog.Clip.IDLE);
        setSize(height, height);
    }

    @Override
    public void act(float delta) {
        super.act(delta);
        time += delta;
    }

    @Override
    public void draw(Batch batch, float parentAlpha) {
        float w = getWidth();
        float h = getHeight();
        float footX = getX() + w / 2f;
        float footY = getY();

        Color prev = batch.getColor().cpy();
        batch.setColor(1f, 1f, 1f, parentAlpha * getColor().a);

        boolean drawn = pam != null
                && game.art().drawFitted(batch, pam, clip, time, footX, footY, h, true, null);

        if (!drawn) {
            TextureRegion region = game.art().region(Backdrops.SUN_BIG);
            if (region == null) region = game.art().region(Backdrops.SUN);
            if (region == null) {
                region = game.art().placeholder("SUNFLOWER", (int) w, (int) h, true);
            }
            if (region != null) {
                float pulse = 1f + 0.06f * (float) Math.sin(time * 2.2f);
                float rot = 8f * (float) Math.sin(time * 1.6f);
                float dw = w * pulse;
                float dh = h * pulse;
                batch.draw(region,
                        getX() + (w - dw) / 2f, footY + (h - dh) / 2f,
                        dw / 2f, dh / 2f, dw, dh, 1f, 1f, rot);
            }
        }

        batch.setColor(prev);
    }
}
