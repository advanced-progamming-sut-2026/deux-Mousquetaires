package pvz.gfx.screens;

import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.ProgressBar;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import pvz.gfx.PvzGame;
import pvz.gfx.art.Backdrops;
import pvz.model.shop.Quest;

import java.util.ArrayList;
import java.util.List;

public class TravelLogScreen extends PanelScreen {

    private static final String[] PAGES = {"story", "epic", "daily", "repeatable", "minigames"};

    public TravelLogScreen(PvzGame game) {
        super(game);
    }

    @Override
    protected String title() {
        return "Travel log";
    }

    @Override
    protected String[] backdrops() {
        return new String[]{Backdrops.MENU_DARKAGES, Backdrops.MENU_EGYPT, Backdrops.MENU_TUTORIAL};
    }

    @Override
    protected void build(Table body) {
        List<Quest> quests = game.quests().getQuests();

        for (String page : PAGES) {
            List<Quest> onPage = new ArrayList<>();
            for (Quest quest : quests) {
                if (page.equalsIgnoreCase(quest.getPage())) onPage.add(quest);
            }
            if (onPage.isEmpty()) continue;

            body.add(sectionLabel(pageTitle(page))).left().padTop(10f).padBottom(6f).row();
            for (Quest quest : onPage) {
                body.add(questRow(quest)).growX().padBottom(8f).row();
            }
        }

        body.add(sectionLabel("Mini-games")).left().padTop(14f).padBottom(6f).row();
        body.add(button("Open the mini-game arcade", new Runnable() {
            @Override
            public void run() {
                game.setScreen(new MiniGameHubScreen(game));
            }
        })).width(340f).left().row();
    }

    private String pageTitle(String page) {
        switch (page) {
            case "story":
                return "Story quests";
            case "epic":
                return "Epic quests";
            case "daily":
                return "Daily quests";
            case "repeatable":
                return "Repeatable quests";
            case "minigames":
                return "Mini-game quests";
            default:
                return page;
        }
    }

    private Table questRow(final Quest quest) {
        Table row = new Table();

        Table text = new Table();
        Label title = new Label(quest.getTitle() + "   [" + quest.getPriority() + "]", game.skin(), "medium");
        Label detail = new Label(quest.describe(), game.skin(), "default");
        detail.setWrap(true);
        text.add(title).left().row();
        text.add(detail).width(600f).left().padTop(2f).row();

        ProgressBar bar = new ProgressBar(0f, Math.max(1, quest.getTarget()), 1f, false,
                game.skin(), "default-horizontal");
        bar.setValue(quest.getProgress());
        text.add(bar).width(600f).left().padTop(6f).row();
        text.add(new Label(quest.getProgress() + " / " + quest.getTarget()
                + "     reward: " + quest.getRewardType() + " " + quest.getRewardPayload(),
                game.skin(), "default")).left().padTop(2f).row();

        row.add(text).left().expandX();

        if (quest.isClaimed()) {
            Label done = new Label("Claimed", game.skin(), "default");
            done.setColor(0.6f, 1f, 0.6f, 1f);
            row.add(done).right().width(200f);
        } else if (quest.isDone()) {
            row.add(button("Claim reward", new Runnable() {
                @Override
                public void run() {
                    claim(quest);
                }
            })).width(200f).right();
        } else {
            Label waiting = new Label("In progress", game.skin(), "default");
            waiting.setColor(0.85f, 0.85f, 0.85f, 1f);
            row.add(waiting).right().width(200f);
        }
        return row;
    }

    private void claim(Quest quest) {
        String message = game.quests().claim(quest.getId(), game.user(), game.news());
        game.save();
        say(message);
        refreshWallet();
        rebuild();
    }
}
