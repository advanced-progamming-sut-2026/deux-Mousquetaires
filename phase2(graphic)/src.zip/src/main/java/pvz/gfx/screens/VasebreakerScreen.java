package pvz.gfx.screens;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import pvz.gfx.PvzGame;
import pvz.gfx.art.Backdrops;
import pvz.model.enums.MiniGameType;
import pvz.model.enums.PlantType;
import pvz.model.minigame.Vasebreaker;

import java.util.List;

public class VasebreakerScreen extends MiniGameScreen {

    private static final float GRID_X = 300f;
    private static final float GRID_Y = 210f;
    private static final float CELL_WIDTH = 132f;
    private static final float CELL_HEIGHT = 152f;
    private static final int PER_ROW = 6;

    private final Vasebreaker vases;

    public VasebreakerScreen(PvzGame game, int level) {
        this(game, level, new Vasebreaker(level));
    }

    private VasebreakerScreen(PvzGame game, int level, Vasebreaker vases) {
        super(game, MiniGameType.VASEBREAKER, level, vases);
        this.vases = vases;
    }

    @Override
    protected String gameTitle() {
        return "Vasebreaker";
    }

    @Override
    protected String statusLine() {
        return "Vases left " + vases.getVaseCount()
                + "     House " + vases.getHouseHp()
                + "     Packets held " + vases.getPacketCount()
                + "     Planted " + vases.getPlantedView().size();
    }

    @Override
    protected String[] backdrops() {
        return new String[]{Backdrops.EGYPT_CENTER, Backdrops.MENU_EGYPT, Backdrops.LAWN_CENTER};
    }

    private float vaseX(int index) {
        return GRID_X + (index % PER_ROW) * CELL_WIDTH;
    }

    private float vaseY(int index) {
        return GRID_Y + (2 - index / PER_ROW) * CELL_HEIGHT;
    }

    @Override
    protected void drawBoard(float delta) {
        SpriteBatch batch = game.batch();
        int count = vases.getVaseCount();

        fill(batch, GRID_X - 24f, GRID_Y - 24f, PER_ROW * CELL_WIDTH + 48f, 3f * CELL_HEIGHT + 48f,
                0.10f, 0.07f, 0.03f, 0.55f);

        for (int i = 0; i < count; i++) {
            float x = vaseX(i);
            float y = vaseY(i);
            boolean big = (i % 5 == 4);
            String id = big ? Backdrops.VASE_BIG : Backdrops.VASE;

            if (game.art().region(id) != null) {
                drawRegion(batch, id, x + 12f, y + 14f, CELL_WIDTH - 34f, CELL_HEIGHT - 40f);
            } else if (game.art().region(Backdrops.VASE_ALT) != null) {
                drawRegion(batch, Backdrops.VASE_ALT, x + 12f, y + 14f, CELL_WIDTH - 34f, CELL_HEIGHT - 40f);
            } else {
                fill(batch, x + 24f, y + 16f, CELL_WIDTH - 60f, CELL_HEIGHT - 50f, 0.62f, 0.42f, 0.22f, 1f);
            }
        }

        PlantType nut = PvzGame.byName("WALL_NUT");
        for (int i = 0; i < vases.getHouseHp(); i++) {
            drawPlant(batch, nut, 120f, 180f + i * 96f, 84f);
        }

        List<Integer> planted = vases.getPlantedView();
        for (int i = 0; i < planted.size(); i++) {
            PlantType plant = plantOf(planted.get(i));
            drawPlant(batch, plant, 210f, 180f + i * 96f, 84f);
        }

        List<int[]> packets = vases.getPacketView();
        for (int i = 0; i < packets.size(); i++) {
            int[] packet = packets.get(i);
            float x = 300f + i * 96f;
            float y = 60f;
            drawRegion(batch, Backdrops.SEED_PLATE, x, y, 84f, 100f);
            PlantType plant = plantOf(packet[1]);
            drawPlant(batch, plant, x + 42f, y + 14f, 66f);
        }
    }

    private PlantType plantOf(int ordinal) {
        PlantType[] all = PlantType.values();
        if (ordinal < 0 || ordinal >= all.length) return null;
        return all[ordinal];
    }

    @Override
    protected void buildControls(Table controls) {
        int count = vases.getVaseCount();
        for (int i = 0; i < count; i++) {
            final int number = i + 1;
            clickZone(vaseX(i), vaseY(i), CELL_WIDTH - 16f, CELL_HEIGHT - 16f, new Runnable() {
                @Override
                public void run() {
                    send("break " + number);
                }
            });
            caption(String.valueOf(number), vaseX(i), vaseY(i) - 2f, CELL_WIDTH - 16f);
        }

        List<int[]> packets = vases.getPacketView();
        for (int i = 0; i < packets.size(); i++) {
            final int number = i + 1;
            float x = 300f + i * 96f;
            float y = 60f;

            clickZone(x, y, 84f, 100f, new Runnable() {
                @Override
                public void run() {
                    send("plant " + number);
                }
            });
            caption(packets.get(i)[0] + " left - click to plant", x, 38f, 84f);
        }

        controls.add(new com.badlogic.gdx.scenes.scene2d.ui.Label(
                "Click a vase to break it. Click a held packet to plant it on the lawn (planted seeds never expire).",
                game.skin(), "default")).left();
    }
}
