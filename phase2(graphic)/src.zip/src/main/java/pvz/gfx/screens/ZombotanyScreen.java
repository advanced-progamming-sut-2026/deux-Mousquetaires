package pvz.gfx.screens;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import pvz.gfx.PvzGame;
import pvz.gfx.art.Backdrops;
import pvz.model.enums.MiniGameType;
import pvz.model.enums.PlantType;
import pvz.model.enums.ZombieType;
import pvz.model.minigame.Zombotany;

import java.util.List;

public class ZombotanyScreen extends MiniGameScreen {

    private static final String[] CHOICES = {"sunflower", "peashooter", "wallnut"};
    private static final int[] COSTS = {50, 100, 50};
    private static final float PACKET_Y = 470f;
    private static final float SUN_Y = 600f;

    private final Zombotany zombotany;
    private int selected = 0;

    public ZombotanyScreen(PvzGame game, int level) {
        this(game, level, new Zombotany(level));
    }

    private ZombotanyScreen(PvzGame game, int level, Zombotany zombotany) {
        super(game, MiniGameType.ZOMBOTANY, level, zombotany);
        this.zombotany = zombotany;
    }

    @Override
    protected String gameTitle() {
        return "Zombotany";
    }

    @Override
    protected String statusLine() {
        return "Sun " + zombotany.getSun()
                + "     Kills " + zombotany.getKills() + " / " + zombotany.getKillTarget()
                + "     Holding " + CHOICES[selected];
    }

    @Override
    protected float tickInterval() {
        return 1f;
    }

    private PlantType plantFor(int index) {
        switch (index) {
            case 0:
                return PvzGame.byName("SUNFLOWER");
            case 1:
                return PvzGame.byName("PEASHOOTER");
            default:
                return PvzGame.byName("WALL_NUT");
        }
    }

    private PlantType plantForUnit(int[] unit) {
        if (unit[4] == 1) return PvzGame.byName("SUNFLOWER");
        if (unit[3] > 0) return PvzGame.byName("PEASHOOTER");
        return PvzGame.byName("WALL_NUT");
    }

    private ZombieType zombieForUnit(int[] unit) {
        ZombieType[] all = ZombieType.values();
        int ordinal = unit[3];
        if (ordinal >= 0 && ordinal < all.length) return all[ordinal];
        return BowlingScreen.zombieByName("BASIC", "NORMAL");
    }

    @Override
    protected void drawBoard(float delta) {
        SpriteBatch batch = game.batch();
        drawGrid(batch);

        for (int lane = 1; lane <= ROWS; lane++) {
            if (!zombotany.hasMower(lane)) continue;
            float x = BOARD_X - 74f;
            float y = cellY(lane) + 12f;
            if (game.art().region(Backdrops.MOWER) != null) {
                drawRegion(batch, Backdrops.MOWER, x, y, 70f, 46f);
            } else {
                fill(batch, x, y, 70f, 46f, 0.75f, 0.2f, 0.2f, 1f);
            }
        }

        for (int[] plant : zombotany.getPlantView()) {
            float x = cellCenterX(plant[1]);
            float y = cellY(plant[0]) + 6f;
            drawPlant(batch, plantForUnit(plant), x, y, PLANT_HEIGHT);
        }

        for (int[] zombie : zombotany.getZombieView()) {
            float x = smoothX(zombie[1]);
            float y = cellY(zombie[0]) + 6f;
            drawZombie(batch, zombieForUnit(zombie), x, y, ZOMBIE_HEIGHT);
            float ratio = Math.max(0f, Math.min(1f, zombie[2] / 1100f));
            fill(batch, x - 26f, y + ZOMBIE_HEIGHT + 6f, 52f, 6f, 0f, 0f, 0f, 0.6f);
            fill(batch, x - 25f, y + ZOMBIE_HEIGHT + 7f, 50f * ratio, 4f, 0.9f, 0.25f, 0.25f, 0.95f);
        }

        for (int i = 0; i < CHOICES.length; i++) {
            float x = 60f + i * 96f;
            float y = PACKET_Y;
            boolean holding = (i == selected);
            fill(batch, x - 4f, y - 4f, 92f, 116f, holding ? 1f : 0f, holding ? 0.9f : 0f,
                    holding ? 0.4f : 0f, holding ? 0.55f : 0.35f);
            drawRegion(batch, Backdrops.SEED_PLATE, x, y, 84f, 108f);
            drawPlant(batch, plantFor(i), x + 42f, y + 16f, 72f);
        }

        drawRegion(batch, Backdrops.SUN, 60f, SUN_Y, 54f, 54f);
    }

    @Override
    protected void buildControls(Table controls) {
        for (int lane = 1; lane <= ROWS; lane++) {
            for (int col = 1; col <= COLS; col++) {
                final int laneIndex = lane;
                final int colIndex = col;
                clickZone(cellX(col), cellY(lane), CELL_W, CELL_H, new Runnable() {
                    @Override
                    public void run() {
                        send("plant " + CHOICES[selected] + " (" + colIndex + ", " + laneIndex + ")");
                    }
                });
            }
        }

        for (int i = 0; i < CHOICES.length; i++) {
            final int index = i;
            clickZone(60f + i * 96f, PACKET_Y, 84f, 108f, new Runnable() {
                @Override
                public void run() {
                    selected = index;
                    refresh();
                }
            });
            caption(CHOICES[i] + "  " + COSTS[i], 56f + i * 96f, PACKET_Y - 24f, 92f);
        }

        Table picker = new Table();
        for (int i = 0; i < CHOICES.length; i++) {
            final int index = i;
            picker.add(controlButton(CHOICES[i] + "  " + COSTS[i], "green_small", new Runnable() {
                @Override
                public void run() {
                    selected = index;
                    refresh();
                }
            })).padRight(6f);
        }
        controls.add(picker).left().row();
        controls.add(new Label("Pick a packet, then click a tile to plant it.", game.skin(), "default"))
                .left().padTop(6f);
    }
}
