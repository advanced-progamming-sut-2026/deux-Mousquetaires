package pvz.model.enums;

public enum LevelType {
    NORMAL,
    CONVEYOR_BELT,
    LOCKED_PLANTS,
    SAVE_OUR_SEEDS,
    SAVE_THE_PLANTS,
    TIMED_WAR,
    NIGHT_OPS,
    DEAD_LINE,
    LOVE_YOUR_PLANTS,
    PLANT_WHAT_YOU_GET,
    SCORED
}
