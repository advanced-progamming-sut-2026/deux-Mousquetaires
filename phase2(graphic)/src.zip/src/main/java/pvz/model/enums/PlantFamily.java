package pvz.model.enums;

public enum PlantFamily {
    SUN_PRODUCER,
    SHOOTER,
    HOMING,
    STRIKE_THROUGH,
    LOBBER,
    EXPLOSIVE,
    MELEE,
    WALL_NUT,
    MODIFIER,
    NONE
}
