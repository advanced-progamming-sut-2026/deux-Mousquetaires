package pvz.model.enums;

public enum PlantTag {

    SHOOTER,
    SUN_PRODUCER,
    WALL,
    EXPLOSIVE,
    MELEE,
    HOMING,
    MODIFIER,
    STRIKE_THROUGH,
    LOBBER,
    MINT,

    DAY,
    NIGHT,
    SHROOM,
    RAMP_UP,
    PEA,
    ICE,
    FIRE,
    STACK,
    CHARGE,
    MAGIC,
    POISON,
    WATER,
    AOE,
    TRAP,
    MOVE_ZOMBIES,
    SUN,
    INSTANT,
    SINGLE_USE,
    CACTI_FAMILY
}
