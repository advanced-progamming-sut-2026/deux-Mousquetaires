package pvz.model.enums;

public enum RewardType {
    CURRENCY,
    UNLOCKABLE,
    INVENTORY
}
