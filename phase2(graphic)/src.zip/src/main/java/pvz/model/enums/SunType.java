package pvz.model.enums;

public enum SunType {
    NORMAL(25, 80),
    SPECIAL(100, 15),
    RADIOACTIVE(25, 5);

    private final int value;
    private final int dropChancePercent;

    SunType(int value, int dropChancePercent) {
        this.value = value;
        this.dropChancePercent = dropChancePercent;
    }
    public int getValue() {
        return value;
    }
    public int getDropChancePercent() {
        return dropChancePercent;
    }
}
