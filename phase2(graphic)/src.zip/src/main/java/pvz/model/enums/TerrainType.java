package pvz.model.enums;

public enum TerrainType {
    GRASS,
    TOMB,
    ICE_SLIP_UP,
    ICE_SLIP_DOWN,
    FROZEN,
    WATER,
    LOW_TIDE,
    NECROMANCY
}
