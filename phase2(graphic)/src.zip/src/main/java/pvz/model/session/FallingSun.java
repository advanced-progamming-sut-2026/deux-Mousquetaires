package pvz.model.session;

import pvz.model.enums.SunType;

public class FallingSun {

    public static final int FALL_TICKS = 50;

    private final int x;
    private final int y;
    private SunType type;
    private int ticksLeft = FALL_TICKS;

    public FallingSun(int x, int y, SunType type) {
        this.x = x;
        this.y = y;
        this.type = type;
    }
    public boolean tick() {
        return --ticksLeft <= 0;
    }
    public void land() {
        if (type == SunType.RADIOACTIVE) type = SunType.NORMAL;
    }

    public boolean isRadioactive() {
        return type == SunType.RADIOACTIVE;
    }

    public int getTicksLeft() {
        return ticksLeft;
    }

    public float getFallProgress() {
        float progress = 1f - (ticksLeft / (float) FALL_TICKS);
        if (progress < 0f) return 0f;
        return Math.min(progress, 1f);
    }
    public int getX() { return x; }
    public int getY() { return y; }
    public SunType getType() { return type; }
    public int getValue() { return type.getValue(); }
}
