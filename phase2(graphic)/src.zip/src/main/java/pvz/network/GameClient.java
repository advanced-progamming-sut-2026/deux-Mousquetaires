package pvz.network;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public final class GameClient {

    public interface Listener {
        void onMessage(String type, String[] fields);
        void onDisconnected();
    }

    private Socket socket;
    private PrintWriter out;
    private BufferedReader in;
    private Thread readThread;
    private volatile boolean connected;
    private final List<Listener> listeners = new CopyOnWriteArrayList<>();

    public void addListener(Listener listener) {
        listeners.add(listener);
    }

    public void removeListener(Listener listener) {
        listeners.remove(listener);
    }

    public boolean isConnected() {
        return connected;
    }

    public void connect(String host, int port) throws IOException {
        socket = new Socket(host, port);
        out = new PrintWriter(socket.getOutputStream(), true, StandardCharsets.UTF_8);
        in = new BufferedReader(new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
        connected = true;
        readThread = new Thread(this::readLoop, "pvz-net-client");
        readThread.setDaemon(true);
        readThread.start();
    }

    public void disconnect() {
        connected = false;
        try {
            if (socket != null) socket.close();
        } catch (IOException ignored) {
        }
    }

    private void readLoop() {
        try {
            String line;
            while ((line = in.readLine()) != null) {
                String[] parts = NetProtocol.decode(line);
                if (parts.length == 0) continue;
                String type = parts[0];
                String[] rest = new String[parts.length - 1];
                System.arraycopy(parts, 1, rest, 0, rest.length);
                for (Listener l : listeners) l.onMessage(type, rest);
            }
        } catch (IOException ignored) {
        } finally {
            connected = false;
            for (Listener l : listeners) l.onDisconnected();
        }
    }

    private void send(String type, String... fields) {
        if (out == null) return;
        synchronized (out) {
            out.println(NetProtocol.encode(type, fields));
            out.flush();
        }
    }

    public void register(String username, String password, String nickname, String email, String gender) {
        send(NetProtocol.C2S_REGISTER, username, password, nickname, email, gender);
    }

    public void login(String username, String password) {
        send(NetProtocol.C2S_LOGIN, username, password);
    }

    public void logout() {
        send(NetProtocol.C2S_LOGOUT);
    }

    public void requestLeaderboard() {
        send(NetProtocol.C2S_LEADERBOARD_REQUEST);
    }

    public void challenge(String targetUsername) {
        send(NetProtocol.C2S_CHALLENGE_REQUEST, targetUsername);
    }

    public void acceptChallenge() {
        send(NetProtocol.C2S_CHALLENGE_ACCEPT);
    }

    public void rejectChallenge() {
        send(NetProtocol.C2S_CHALLENGE_REJECT);
    }

    public void joinQueue() {
        send(NetProtocol.C2S_QUEUE_JOIN);
    }

    public void leaveQueue() {
        send(NetProtocol.C2S_QUEUE_LEAVE);
    }

    public void sendZombieInput(int rosterIndex, int lane) {
        send(NetProtocol.C2S_ZOMBIE_INPUT, String.valueOf(rosterIndex), String.valueOf(lane));
    }

    public void sendPlantInput(int lane, int col, boolean shooter) {
        send(NetProtocol.C2S_PLANT_INPUT, String.valueOf(lane), String.valueOf(col), shooter ? "1" : "0");
    }

    public void quitMatch() {
        send(NetProtocol.C2S_MATCH_QUIT);
    }

    public void sendReaction(String kind, int id) {
        send(NetProtocol.C2S_REACTION_SEND, kind, String.valueOf(id));
    }

    public static List<int[]> parseEntities(String csv, int fieldsPerEntity) {
        List<int[]> result = new ArrayList<>();
        if (csv == null || csv.isEmpty()) return result;
        for (String item : csv.split(NetProtocol.ITEM_SEP)) {
            if (item.isEmpty()) continue;
            String[] sub = item.split(NetProtocol.SUBITEM_SEP);
            int[] values = new int[fieldsPerEntity];
            for (int i = 0; i < fieldsPerEntity && i < sub.length; i++) {
                values[i] = Integer.parseInt(sub[i]);
            }
            result.add(values);
        }
        return result;
    }
}
