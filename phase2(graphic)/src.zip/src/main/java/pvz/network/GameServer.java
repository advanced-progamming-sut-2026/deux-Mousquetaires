package pvz.network;

import pvz.model.auth.AuthService;
import pvz.model.auth.User;
import pvz.model.enums.Gender;
import pvz.model.minigame.IZombie;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

public final class GameServer {

    private static final Path ACCOUNTS_FILE = Paths.get("server_data", "accounts.dat");

    private final int port;
    private final AuthService accounts = new AuthService();
    private final Map<String, ClientHandler> online = new ConcurrentHashMap<>();
    private final List<ClientHandler> matchQueue = new CopyOnWriteArrayList<>();
    private final ScheduledExecutorService ticker = Executors.newScheduledThreadPool(4);
    private ServerSocket serverSocket;

    public GameServer(int port) {
        this.port = port;
    }

    public static void main(String[] args) throws IOException {
        int port = args.length > 0 ? Integer.parseInt(args[0]) : NetProtocol.DEFAULT_PORT;
        GameServer server = new GameServer(port);
        server.start();
    }

    public synchronized void start() throws IOException {
        loadAccounts();
        serverSocket = new ServerSocket(port);
        System.out.println("PvZ network server listening on port " + port);
        Thread acceptThread = new Thread(this::acceptLoop, "pvz-server-accept");
        acceptThread.setDaemon(false);
        acceptThread.start();
    }

    public void stop() {
        try {
            if (serverSocket != null) serverSocket.close();
        } catch (IOException ignored) {
        }
        ticker.shutdownNow();
    }

    private void acceptLoop() {
        while (serverSocket != null && !serverSocket.isClosed()) {
            try {
                Socket socket = serverSocket.accept();
                ClientHandler handler = new ClientHandler(socket);
                Thread thread = new Thread(handler, "pvz-client-" + socket.getPort());
                thread.setDaemon(true);
                thread.start();
            } catch (IOException e) {
                if (serverSocket == null || serverSocket.isClosed()) return;
            }
        }
    }

    private synchronized void loadAccounts() {
        if (!Files.exists(ACCOUNTS_FILE)) return;
        try {
            List<String> lines = Files.readAllLines(ACCOUNTS_FILE, StandardCharsets.UTF_8);
            for (String line : lines) {
                if (line.trim().isEmpty()) continue;
                String[] f = line.split("\\|", -1);
                if (f.length < 12) continue;
                User user = new User(f[0], f[1], f[2], f[3], Gender.valueOf(f[4]));
                user.setCoins(Integer.parseInt(f[5]));
                user.setGems(Integer.parseInt(f[6]));
                user.setGamesPlayed(Integer.parseInt(f[7]));
                user.setBestMooPoints(Integer.parseInt(f[8]));
                user.setMiniGamesCompleted(Integer.parseInt(f[9]));
                user.setDailyQuestsDone(Integer.parseInt(f[10]));
                user.setOtherQuestsDone(Integer.parseInt(f[11]));
                if (f.length > 12) user.setZombiesKilled(Integer.parseInt(f[12]));
                accounts.restoreUser(user);
            }
            System.out.println("Loaded " + accounts.getAllUsers().size() + " server accounts.");
        } catch (Exception e) {
            System.out.println("Could not load server accounts: " + e.getMessage());
        }
    }

    private synchronized void saveAccounts() {
        try {
            Files.createDirectories(ACCOUNTS_FILE.getParent());
            List<String> lines = new ArrayList<>();
            for (User user : accounts.getAllUsers()) {
                lines.add(String.join("|",
                        user.getUsername(), user.getPasswordHash(), nullToEmpty(user.getEmail()),
                        nullToEmpty(user.getNickname()), user.getGender().name(),
                        String.valueOf(user.getCoins()), String.valueOf(user.getGems()),
                        String.valueOf(user.getGamesPlayed()), String.valueOf(user.getBestMooPoints()),
                        String.valueOf(user.getMiniGamesCompleted()), String.valueOf(user.getDailyQuestsDone()),
                        String.valueOf(user.getOtherQuestsDone()), String.valueOf(user.getZombiesKilled())));
            }
            Files.write(ACCOUNTS_FILE, lines, StandardCharsets.UTF_8);
        } catch (IOException e) {
            System.out.println("Could not save server accounts: " + e.getMessage());
        }
    }

    private static String nullToEmpty(String s) {
        return s == null ? "" : s;
    }

    private void broadcastLeaderboard() {
        String payload = leaderboardPayload();
        for (ClientHandler handler : online.values()) {
            handler.send(NetProtocol.encode(NetProtocol.S2C_LEADERBOARD_DATA, payload));
        }
    }

    private String leaderboardPayload() {
        List<User> users = new ArrayList<>(accounts.getAllUsers());
        users.sort((a, b) -> Integer.compare(b.getBestMooPoints(), a.getBestMooPoints()));
        StringBuilder sb = new StringBuilder();
        for (User user : users) {
            if (sb.length() > 0) sb.append(NetProtocol.ITEM_SEP);
            sb.append(user.getUsername()).append(NetProtocol.SUBITEM_SEP)
                    .append(user.getNickname() == null ? user.getUsername() : user.getNickname())
                    .append(NetProtocol.SUBITEM_SEP).append(user.getBestMooPoints())
                    .append(NetProtocol.SUBITEM_SEP).append(user.getMiniGamesCompleted())
                    .append(NetProtocol.SUBITEM_SEP).append(user.getGamesPlayed())
                    .append(NetProtocol.SUBITEM_SEP).append(user.getZombiesKilled());
        }
        return sb.toString();
    }

    private void startMatch(ClientHandler zombieSide, ClientHandler plantSide) {
        Match match = new Match(zombieSide, plantSide);
        zombieSide.match = match;
        plantSide.match = match;
        zombieSide.role = "ZOMBIE";
        plantSide.role = "PLANT";
        zombieSide.send(NetProtocol.encode(NetProtocol.S2C_MATCH_START, "ZOMBIE", plantSide.username()));
        plantSide.send(NetProtocol.encode(NetProtocol.S2C_MATCH_START, "PLANT", zombieSide.username()));
        match.future = ticker.scheduleAtFixedRate(match::tick, 1, 1, TimeUnit.SECONDS);
    }

    private final class Match {
        final ClientHandler zombieSide;
        final ClientHandler plantSide;
        final IZombie sim = new IZombie(2, true);
        volatile boolean ended;
        ScheduledFuture<?> future;

        Match(ClientHandler zombieSide, ClientHandler plantSide) {
            this.zombieSide = zombieSide;
            this.plantSide = plantSide;
            sim.start();
        }

        synchronized void tick() {
            if (ended) return;
            sim.tick();
            broadcastState();
            if (sim.isGameover()) endMatch();
        }

        void broadcastState() {
            StringBuilder plantsCsv = new StringBuilder();
            for (int[] p : sim.getPlantView()) {
                if (plantsCsv.length() > 0) plantsCsv.append(NetProtocol.ITEM_SEP);
                plantsCsv.append(p[0]).append(NetProtocol.SUBITEM_SEP).append(p[1])
                        .append(NetProtocol.SUBITEM_SEP).append(p[2]).append(NetProtocol.SUBITEM_SEP).append(p[3]);
            }
            StringBuilder zombiesCsv = new StringBuilder();
            for (int[] z : sim.getZombieView()) {
                if (zombiesCsv.length() > 0) zombiesCsv.append(NetProtocol.ITEM_SEP);
                zombiesCsv.append(z[0]).append(NetProtocol.SUBITEM_SEP).append(z[1])
                        .append(NetProtocol.SUBITEM_SEP).append(z[2]).append(NetProtocol.SUBITEM_SEP)
                        .append(z[3]).append(NetProtocol.SUBITEM_SEP).append(z[4]);
            }
            StringBuilder brains = new StringBuilder();
            for (int lane = 1; lane <= sim.getRows(); lane++) brains.append(sim.isBrainEaten(lane) ? '1' : '0');
            String state = NetProtocol.encode(NetProtocol.S2C_MATCH_STATE,
                    String.valueOf(sim.getSun()), String.valueOf(sim.getPlantSun()),
                    String.valueOf(sim.getSecondsElapsed()), String.valueOf(sim.getMatchDurationSeconds()),
                    String.valueOf(sim.getZombiesPlaced()), String.valueOf(sim.getMaxZombies()),
                    brains.toString(), plantsCsv.toString(), zombiesCsv.toString());
            zombieSide.send(state);
            plantSide.send(state);
        }

        synchronized void endMatch() {
            if (ended) return;
            ended = true;
            if (future != null) future.cancel(false);
            boolean zombieWon = sim.isWon();
            ClientHandler winner = zombieWon ? zombieSide : plantSide;
            ClientHandler loser = zombieWon ? plantSide : zombieSide;
            applyReward(winner, loser);
            winner.send(NetProtocol.encode(NetProtocol.S2C_MATCH_END, "WIN"));
            loser.send(NetProtocol.encode(NetProtocol.S2C_MATCH_END, "LOSE"));
            zombieSide.match = null;
            plantSide.match = null;
            saveAccounts();
            broadcastLeaderboard();
        }

        synchronized void forfeit(ClientHandler quitter) {
            if (ended) return;
            ended = true;
            if (future != null) future.cancel(false);
            ClientHandler winner = quitter == zombieSide ? plantSide : zombieSide;
            ClientHandler loser = quitter;
            applyReward(winner, loser);
            winner.send(NetProtocol.encode(NetProtocol.S2C_MATCH_END, "WIN"));
            loser.send(NetProtocol.encode(NetProtocol.S2C_MATCH_END, "LOSE"));
            zombieSide.match = null;
            plantSide.match = null;
            saveAccounts();
            broadcastLeaderboard();
        }

        private void applyReward(ClientHandler winner, ClientHandler loser) {
            if (winner.user != null) {
                winner.user.addCoins(200);
                winner.user.recordMiniGameCompleted();
                winner.user.recordGamePlayed(sim.getSecondsElapsed());
            }
            if (loser.user != null) {
                loser.user.recordGamePlayed(sim.getSecondsElapsed());
            }
        }
    }

    private final class ClientHandler implements Runnable {
        private final Socket socket;
        private PrintWriter out;
        private volatile User user;
        private volatile Match match;
        private volatile String role;
        private volatile String pendingChallengeFrom;

        ClientHandler(Socket socket) {
            this.socket = socket;
        }

        String username() {
            return user == null ? "?" : user.getUsername();
        }

        void send(String line) {
            if (out != null) {
                synchronized (out) {
                    out.println(line);
                    out.flush();
                }
            }
        }

        @Override
        public void run() {
            try {
                out = new PrintWriter(socket.getOutputStream(), true, StandardCharsets.UTF_8);
                BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
                String line;
                while ((line = in.readLine()) != null) {
                    handleLine(line);
                }
            } catch (IOException ignored) {
            } finally {
                disconnect();
            }
        }

        private void disconnect() {
            if (user != null) online.remove(user.getUsername().toLowerCase());
            matchQueue.remove(this);
            if (match != null) match.forfeit(this);
            try {
                socket.close();
            } catch (IOException ignored) {
            }
        }

        private void handleLine(String line) {
            String[] parts = NetProtocol.decode(line);
            if (parts.length == 0) return;
            String type = parts[0];
            switch (type) {
                case NetProtocol.C2S_REGISTER: onRegister(parts); break;
                case NetProtocol.C2S_LOGIN: onLogin(parts); break;
                case NetProtocol.C2S_LOGOUT: onLogout(); break;
                case NetProtocol.C2S_LEADERBOARD_REQUEST: send(NetProtocol.encode(NetProtocol.S2C_LEADERBOARD_DATA, leaderboardPayload())); break;
                case NetProtocol.C2S_CHALLENGE_REQUEST: onChallengeRequest(parts); break;
                case NetProtocol.C2S_CHALLENGE_ACCEPT: onChallengeAccept(); break;
                case NetProtocol.C2S_CHALLENGE_REJECT: onChallengeReject(); break;
                case NetProtocol.C2S_QUEUE_JOIN: onQueueJoin(); break;
                case NetProtocol.C2S_QUEUE_LEAVE: matchQueue.remove(this); break;
                case NetProtocol.C2S_ZOMBIE_INPUT: onZombieInput(parts); break;
                case NetProtocol.C2S_PLANT_INPUT: onPlantInput(parts); break;
                case NetProtocol.C2S_MATCH_QUIT: if (match != null) match.forfeit(this); break;
                case NetProtocol.C2S_REACTION_SEND: onReaction(parts); break;
                default: break;
            }
        }

        private void onRegister(String[] p) {
            try {
                User created = accounts.register(NetProtocol.field(p, 1), NetProtocol.field(p, 2),
                        NetProtocol.field(p, 2), NetProtocol.field(p, 3), NetProtocol.field(p, 4),
                        Gender.valueOf(NetProtocol.field(p, 5)));
                saveAccounts();
                send(NetProtocol.encode(NetProtocol.S2C_REGISTER_OK, created.getUsername()));
            } catch (Exception e) {
                send(NetProtocol.encode(NetProtocol.S2C_REGISTER_ERR, e.getMessage()));
            }
        }

        private void onLogin(String[] p) {
            User found = accounts.login(NetProtocol.field(p, 1), NetProtocol.field(p, 2), true);
            if (found == null) {
                send(NetProtocol.encode(NetProtocol.S2C_LOGIN_ERR, "Invalid username or password."));
                return;
            }
            this.user = found;
            online.put(found.getUsername().toLowerCase(), this);
            send(NetProtocol.encode(NetProtocol.S2C_LOGIN_OK, found.getUsername(), found.getNickname(),
                    String.valueOf(found.getCoins()), String.valueOf(found.getGems()),
                    String.valueOf(found.getBestMooPoints())));
        }

        private void onLogout() {
            if (user != null) online.remove(user.getUsername().toLowerCase());
            matchQueue.remove(this);
            user = null;
        }

        private void onChallengeRequest(String[] p) {
            String target = NetProtocol.field(p, 1);
            if (accounts.findByUsername(target) == null) {
                send(NetProtocol.encode(NetProtocol.S2C_CHALLENGE_INVALID, target));
                return;
            }
            ClientHandler targetHandler = online.get(target.toLowerCase());
            if (targetHandler == null || targetHandler.match != null) {
                send(NetProtocol.encode(NetProtocol.S2C_CHALLENGE_OFFLINE, target));
                return;
            }
            targetHandler.pendingChallengeFrom = username();
            targetHandler.send(NetProtocol.encode(NetProtocol.S2C_CHALLENGE_INCOMING, username()));
        }

        private void onChallengeAccept() {
            String fromName = pendingChallengeFrom;
            pendingChallengeFrom = null;
            if (fromName == null) return;
            ClientHandler challenger = online.get(fromName.toLowerCase());
            if (challenger == null) {
                send(NetProtocol.encode(NetProtocol.S2C_CHALLENGE_OFFLINE, fromName));
                return;
            }
            startMatch(challenger, this);
        }

        private void onChallengeReject() {
            String fromName = pendingChallengeFrom;
            pendingChallengeFrom = null;
            if (fromName == null) return;
            ClientHandler challenger = online.get(fromName.toLowerCase());
            if (challenger != null) challenger.send(NetProtocol.encode(NetProtocol.S2C_CHALLENGE_DECLINED, username()));
        }

        private void onQueueJoin() {
            for (ClientHandler waiting : matchQueue) {
                if (waiting != this && waiting.match == null) {
                    matchQueue.remove(waiting);
                    startMatch(waiting, this);
                    return;
                }
            }
            matchQueue.add(this);
            send(NetProtocol.encode(NetProtocol.S2C_QUEUE_WAITING));
        }

        private void onZombieInput(String[] p) {
            if (match == null || !"ZOMBIE".equals(role)) return;
            try {
                int index = Integer.parseInt(NetProtocol.field(p, 1));
                int lane = Integer.parseInt(NetProtocol.field(p, 2));
                match.sim.placeByRosterIndex(index, lane);
            } catch (NumberFormatException ignored) {
            }
        }

        private void onPlantInput(String[] p) {
            if (match == null || !"PLANT".equals(role)) return;
            try {
                int lane = Integer.parseInt(NetProtocol.field(p, 1));
                int col = Integer.parseInt(NetProtocol.field(p, 2));
                boolean shooter = "1".equals(NetProtocol.field(p, 3));
                match.sim.plantDefender(lane, col, shooter);
            } catch (NumberFormatException ignored) {
            }
        }

        private void onReaction(String[] p) {
            if (match == null) return;
            ClientHandler opponent = match.zombieSide == this ? match.plantSide : match.zombieSide;
            opponent.send(NetProtocol.encode(NetProtocol.S2C_REACTION_RECEIVE,
                    NetProtocol.field(p, 1), NetProtocol.field(p, 2), username()));
        }
    }
}
