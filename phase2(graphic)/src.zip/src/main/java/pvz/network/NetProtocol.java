package pvz.network;

public final class NetProtocol {

    private NetProtocol() {}

    public static final int DEFAULT_PORT = 5050;

    public static final String FIELD_SEP = "\u0001";
    public static final String ITEM_SEP = ";";
    public static final String SUBITEM_SEP = ",";

    public static final String C2S_REGISTER = "REGISTER";
    public static final String C2S_LOGIN = "LOGIN";
    public static final String C2S_LOGOUT = "LOGOUT";
    public static final String C2S_LEADERBOARD_REQUEST = "LEADERBOARD_REQUEST";
    public static final String C2S_CHALLENGE_REQUEST = "CHALLENGE_REQUEST";
    public static final String C2S_CHALLENGE_ACCEPT = "CHALLENGE_ACCEPT";
    public static final String C2S_CHALLENGE_REJECT = "CHALLENGE_REJECT";
    public static final String C2S_QUEUE_JOIN = "QUEUE_JOIN";
    public static final String C2S_QUEUE_LEAVE = "QUEUE_LEAVE";
    public static final String C2S_PLANT_INPUT = "PLANT_INPUT";
    public static final String C2S_ZOMBIE_INPUT = "ZOMBIE_INPUT";
    public static final String C2S_MATCH_QUIT = "MATCH_QUIT";
    public static final String C2S_REACTION_SEND = "REACTION_SEND";

    public static final String S2C_REGISTER_OK = "REGISTER_OK";
    public static final String S2C_REGISTER_ERR = "REGISTER_ERR";
    public static final String S2C_LOGIN_OK = "LOGIN_OK";
    public static final String S2C_LOGIN_ERR = "LOGIN_ERR";
    public static final String S2C_LEADERBOARD_DATA = "LEADERBOARD_DATA";
    public static final String S2C_CHALLENGE_INCOMING = "CHALLENGE_INCOMING";
    public static final String S2C_CHALLENGE_DECLINED = "CHALLENGE_DECLINED";
    public static final String S2C_CHALLENGE_OFFLINE = "CHALLENGE_OFFLINE";
    public static final String S2C_CHALLENGE_INVALID = "CHALLENGE_INVALID";
    public static final String S2C_QUEUE_WAITING = "QUEUE_WAITING";
    public static final String S2C_MATCH_START = "MATCH_START";
    public static final String S2C_MATCH_STATE = "MATCH_STATE";
    public static final String S2C_MATCH_END = "MATCH_END";
    public static final String S2C_REACTION_RECEIVE = "REACTION_RECEIVE";
    public static final String S2C_ERROR = "ERROR";

    public static String encode(String type, String... fields) {
        StringBuilder builder = new StringBuilder(type);
        for (String field : fields) {
            String safe = field == null ? "" : field.replace("\n", " ").replace("\r", " ");
            builder.append(FIELD_SEP).append(safe);
        }
        return builder.toString();
    }

    public static String[] decode(String line) {
        if (line == null) return new String[0];
        return line.split(FIELD_SEP, -1);
    }

    public static String field(String[] parts, int index) {
        return index >= 0 && index < parts.length ? parts[index] : "";
    }
}
