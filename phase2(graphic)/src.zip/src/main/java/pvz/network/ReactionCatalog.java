package pvz.network;

public final class ReactionCatalog {

    private ReactionCatalog() {}

    public static final String KIND_TEXT = "TEXT";
    public static final String KIND_EMOJI = "EMOJI";
    public static final String KIND_STICKER = "STICKER";

    public static final String TEXT_1 = "Nice try!";
    public static final String TEXT_2 = "Good luck!";
    public static final String TEXT_3 = "Watch out!";

    public static final String EMOJI_1_GLYPH = "\uD83D\uDE00";
    public static final String EMOJI_2_GLYPH = "\uD83D\uDE02";
    public static final String EMOJI_3_GLYPH = "\uD83D\uDE31";
    public static final String EMOJI_1_ASSET = "REACTIONS/EMOJI_1/EMOJI_1.PNG";
    public static final String EMOJI_2_ASSET = "REACTIONS/EMOJI_2/EMOJI_2.PNG";
    public static final String EMOJI_3_ASSET = "REACTIONS/EMOJI_3/EMOJI_3.PNG";

    public static final String STICKER_1_PAM = "REACTIONS/STICKER_1/STICKER_1.PAM";
    public static final String STICKER_2_PAM = "REACTIONS/STICKER_2/STICKER_2.PAM";
    public static final String STICKER_3_PAM = "REACTIONS/STICKER_3/STICKER_3.PAM";
    public static final String STICKER_1_LABEL = "Sticker 1";
    public static final String STICKER_2_LABEL = "Sticker 2";
    public static final String STICKER_3_LABEL = "Sticker 3";

    public static String textFor(int id) {
        if (id == 1) return TEXT_1;
        if (id == 2) return TEXT_2;
        if (id == 3) return TEXT_3;
        return "";
    }

    public static String emojiGlyphFor(int id) {
        if (id == 1) return EMOJI_1_GLYPH;
        if (id == 2) return EMOJI_2_GLYPH;
        if (id == 3) return EMOJI_3_GLYPH;
        return "";
    }

    public static String emojiAssetFor(int id) {
        if (id == 1) return EMOJI_1_ASSET;
        if (id == 2) return EMOJI_2_ASSET;
        if (id == 3) return EMOJI_3_ASSET;
        return null;
    }

    public static String stickerAssetFor(int id) {
        if (id == 1) return STICKER_1_PAM;
        if (id == 2) return STICKER_2_PAM;
        if (id == 3) return STICKER_3_PAM;
        return null;
    }

    public static String stickerLabelFor(int id) {
        if (id == 1) return STICKER_1_LABEL;
        if (id == 2) return STICKER_2_LABEL;
        if (id == 3) return STICKER_3_LABEL;
        return "";
    }
}
